import type { Point } from './routing.ts';

export function rooftopAt(point: Point, buildings: Point[][]) {
  const [x, y] = point;
  for (const ring of buildings) {
    let inside = false;
    let twiceArea = 0;
    let access = ring[0];
    let nearest = Infinity;
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const [ax, ay] = ring[j];
      const [bx, by] = ring[i];
      if ((ay > y) !== (by > y) && x < ax + (y - ay) * (bx - ax) / (by - ay)) inside = !inside;
      twiceArea += ax * by - bx * ay;
      const dx = bx - ax;
      const dy = by - ay;
      const fraction = Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy || 1)));
      const candidate: Point = [ax + dx * fraction, ay + dy * fraction];
      const distance = (x - candidate[0]) ** 2 + (y - candidate[1]) ** 2;
      if (distance >= nearest) continue;
      nearest = distance;
      access = candidate;
    }
    if (inside) return { height: Math.max(6, Math.min(18, Math.round(Math.sqrt(Math.abs(twiceArea) / 2) / 2))), access };
  }
}
