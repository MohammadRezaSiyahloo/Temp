import { cellSize, steps, type CrowdField } from './crowd-field.ts';
import type { Point } from './routing.ts';

export type Barricade = [Point, Point];

export interface ZoneGate {
  position: Point;
  post: number;
  span: Barricade;
  alertUntil: number;
  integrity: number;
  pressure: number;
  open: boolean;
  locked: boolean;
  nearbyInfected: number;
}

export const gateIntegrity = 120;
export const minBarricadeLength = 2;
export const maxBarricadeLength = 40;

export function barricadeCost([start, end]: Barricade) {
  return 45 + Math.ceil(Math.hypot(end[0] - start[0], end[1] - start[1])) * 5;
}

export function barricadeEdges(terrain: CrowdField, [start, end]: Barricade, mask = 0, gate = false) {
  const dx = end[0] - start[0];
  const dy = end[1] - start[1];
  const length = Math.hypot(dx, dy);
  const center: Point = [(start[0] + end[0]) / 2, (start[1] + end[1]) / 2];
  const edges = new Map<number, number>();
  if (length < (gate ? 0.001 : minBarricadeLength) || length > maxBarricadeLength) return edges;
  terrain.visitArea(...center, length / 2 + cellSize * 2, cell => {
    const x = terrain.x(cell) - start[0];
    const y = terrain.y(cell) - start[1];
    const side = dx * y - dy * x;
    if (side < -1e-8 || side > length * cellSize * Math.SQRT2 + 1e-8) return;
    for (const [direction, [sx, sy]] of steps.entries()) {
      if (!terrain.canStep(cell, direction, mask)) continue;
      const next = cell + sy * terrain.columns + sx;
      const nextSide = side + cellSize * (dx * sy - dy * sx);
      if (nextSide >= -1e-8) continue;
      const along = Math.max(0, side) / (side - nextSide);
      const offset = ((x + along * sx * cellSize) * dx + (y + along * sy * cellSize) * dy) / (length * length);
      if (offset < -1e-8 || offset > 1 + 1e-8) continue;
      edges.set(cell * 8 + direction, next);
      edges.set(next * 8 + 7 - direction, cell);
    }
  });
  return edges;
}

export function gateOpening(length: number) {
  return Math.min(length * 0.58, 2.8);
}

export class Fortifications {
  readonly gates: ZoneGate[] = [];
  private readonly crossings = new Map<number, { gate: ZoneGate; opening: boolean }[]>();
  private readonly terrain: CrowdField;
  private readonly center: Point;
  private readonly flow: Uint16Array;

  constructor(terrain: CrowdField, center: Point, flow: Uint16Array, barricades: readonly Barricade[]) {
    this.terrain = terrain;
    this.center = center;
    this.flow = flow;
    for (const span of barricades) this.add(span);
  }

  add(span: Barricade) {
    const { terrain, center, flow } = this;
    const edges = barricadeEdges(terrain, span);
    const [start, end] = span;
    const position: Point = [(start[0] + end[0]) / 2, (start[1] + end[1]) / 2];
    const dx = end[0] - start[0];
    const dy = end[1] - start[1];
    const protectedSide = Math.sign(dx * (center[1] - start[1]) - dy * (center[0] - start[0]));
    let post = -1;
    let best = Infinity;
    for (const cell of edges.values()) {
      const x = terrain.x(cell);
      const y = terrain.y(cell);
      if (!flow[cell] || protectedSide * (dx * (y - start[1]) - dy * (x - start[0])) < -1e-8) continue;
      const score = (x - position[0]) ** 2 + (y - position[1]) ** 2;
      if (score >= best) continue;
      best = score;
      post = cell;
    }
    if (post < 0) return false;
    const gate: ZoneGate = { position, post, span, integrity: gateIntegrity, pressure: 0, alertUntil: 0, open: false, locked: false, nearbyInfected: 0 };
    this.gates.push(gate);
    const length = Math.hypot(dx, dy);
    const half = gateOpening(length) / 2 / length;
    const opening: Barricade = [
      [position[0] - dx * half, position[1] - dy * half],
      [position[0] + dx * half, position[1] + dy * half],
    ];
    const passable = barricadeEdges(terrain, opening, 0, true);
    for (const key of edges.keys()) {
      const crossings = this.crossings.get(key) ?? [];
      crossings.push({ gate, opening: passable.has(key) });
      this.crossings.set(key, crossings);
    }
    return true;
  }

  blockingGate(cell: number, next: number) {
    const dx = next % this.terrain.columns - cell % this.terrain.columns;
    const dy = Math.floor(next / this.terrain.columns) - Math.floor(cell / this.terrain.columns);
    const direction = dy < 0 ? dx + 1 : dy > 0 ? dx + 6 : dx < 0 ? 3 : 4;
    return this.crossings.get(cell * 8 + direction)?.find(({ gate, opening }) =>
      gate.integrity > 0 && !(opening && gate.open && !gate.locked))?.gate;
  }

  allows(cell: number, next: number, pressure = true, civilian = false) {
    if (cell === next) return true;
    const dx = next % this.terrain.columns - cell % this.terrain.columns;
    const dy = Math.floor(next / this.terrain.columns) - Math.floor(cell / this.terrain.columns);
    if (Math.abs(dx) > 1 || Math.abs(dy) > 1) return true;
    const direction = dy < 0 ? dx + 1 : dy > 0 ? dx + 6 : dx < 0 ? 3 : 4;
    const crossings = this.crossings.get(cell * 8 + direction);
    if (!crossings) return true;
    let passable = true;
    for (const { gate, opening } of crossings) {
      if (gate.integrity <= 0 || (opening && gate.open && !gate.locked)) continue;
      if (pressure && !civilian) gate.pressure++;
      passable = false;
    }
    return passable;
  }

  insidePickup(cell: number, goal: number) {
    const goalX = this.terrain.x(goal), goalY = this.terrain.y(goal);
    const dx = this.terrain.x(cell) - goalX, dy = this.terrain.y(cell) - goalY;
    return this.gates.every(({ span: [[ax, ay], [bx, by]], integrity }) => {
      if (integrity <= 0) return true;
      const sx = bx - ax, sy = by - ay;
      const cross = dx * sy - dy * sx;
      if (Math.abs(cross) < 1e-8) return true;
      const travel = ((ax - goalX) * sy - (ay - goalY) * sx) / cross;
      const along = ((ax - goalX) * dy - (ay - goalY) * dx) / cross;
      return travel <= 0 || travel > 1 || along < 0 || along > 1;
    });
  }

  updateLockdown(gate: ZoneGate, count: number) {
    gate.nearbyInfected = count;
    gate.locked = gate.integrity > 0 && count >= (gate.locked ? 5 : 8);
    if (gate.locked) gate.open = false;
  }

  resolve(seconds: number, elapsed = 0) {
    for (const gate of this.gates) {
      if (gate.pressure) gate.alertUntil = elapsed + 6;
      gate.integrity = Math.max(0, gate.integrity - Math.min(5, gate.pressure) * seconds);
      if (gate.integrity <= 0) gate.locked = false;
      gate.pressure = 0;
    }
  }
}

export function barricadeGaps(terrain: CrowdField, span: Barricade, mask: number, existing: readonly Barricade[]) {
  const [a, b] = span;
  const length = Math.hypot(b[0] - a[0], b[1] - a[1]);
  if (length < minBarricadeLength || length > maxBarricadeLength) return [];
  const x = (b[0] - a[0]) / length;
  const y = (b[1] - a[1]) / length;
  const blocked = new Set(barricadeEdges(terrain, span, mask).keys());
  for (const wall of existing) {
    for (const edge of barricadeEdges(terrain, wall, mask).keys()) blocked.add(edge);
  }
  const gaps: Point[] = [];
  for (const [point, direction] of [[a, -1], [b, 1]] as const) {
    const extension: Point = [point[0] + x * direction * 2.4, point[1] + y * direction * 2.4];
    const continuation = barricadeEdges(terrain, direction < 0 ? [extension, point] : [point, extension], mask);
    let best = Infinity;
    let gap: Point | undefined;
    for (const [edge, next] of continuation) {
      if (blocked.has(edge)) continue;
      const cell = Math.floor(edge / 8);
      const middle: Point = [(terrain.x(cell) + terrain.x(next)) / 2, (terrain.y(cell) + terrain.y(next)) / 2];
      const distance = (point[0] - middle[0]) ** 2 + (point[1] - middle[1]) ** 2;
      if (distance >= best) continue;
      best = distance;
      gap = middle;
    }
    if (gap) gaps.push(gap);
  }
  return gaps;
}
