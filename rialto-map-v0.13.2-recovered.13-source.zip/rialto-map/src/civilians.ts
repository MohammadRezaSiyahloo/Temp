import type { Civilian } from './convoy.ts';
import { civilianProfiles } from './civilian-profiles.ts';
import { bites, riseDuration, type Encounter, type Zombie } from './outbreak.ts';
import type { Point } from './routing.ts';
import type { Soldier } from './defense.ts';

export const civilianCell = 64;
export const civilianFacings = 16;
const zombieProfile = {
  height: 0.96, build: 0.96, stride: 2.04, armSwing: 0.37, pace: 1,
  hairStyle: 'short', colors: ['#be6755', '#4a3434', '#a7aa80', '#322826'],
} as const;
const infantryProfile = {
  height: 1.02, build: 1.03, stride: 1.9, armSwing: 0.22, pace: 1,
  hairStyle: 'short', colors: ['#819575', '#394c3c', '#b99075', '#263c35'],
} as const;
const soldierModels = {
  infantry: infantryProfile,
  sniper: { height: 0.99, build: 0.87, stride: 1.82, armSwing: 0.15, pace: 1,
    hairStyle: 'short', colors: ['#a29b70', '#494c3e', '#bc9274', '#3b4439'] },
  medic: { height: 1.01, build: 1.02, stride: 1.83, armSwing: 0.24, pace: 1,
    hairStyle: 'short', colors: ['#688f8b', '#34494b', '#b99075', '#223a3b'] },
} as const satisfies Record<Soldier['type'], object>;
const mutantProfile = {
  height: 1.15, build: 1.46, stride: 1.85, armSwing: 0.31, pace: 1,
  hairStyle: 'short', colors: ['#895758', '#43363d', '#ac8279', '#503b43'],
} as const;
const soldierTypes = Object.keys(soldierModels) as Soldier['type'][];
const soldierPalette = civilianProfiles.length + 2;
const spriteModels = [...civilianProfiles, zombieProfile, mutantProfile, ...soldierTypes.map(type => soldierModels[type])];
export const civilianPalettes = spriteModels.length;
export const civilianAnchor = [0.5, 0.72] as const;
export const civilianPixelsPerMeter = 14;
export const civilianScale = 0.76;
const runningFrames = 20;
const waitingFrames = 4;
export const civilianFrames = runningFrames + waitingFrames;
const stanceFraction = 0.34;
const columns = 64;
const combatFacings = 8;
const attackFrames = 6;
const riseFrames = 7;
const attackFrameCount = bites.length * attackFrames;
const victimFrames = attackFrameCount + 1 + riseFrames;
const victimBase = civilianPalettes * civilianFacings * civilianFrames;
const attackerBase = victimBase + civilianProfiles.length * combatFacings * victimFrames;
const mutantAttackBase = attackerBase + combatFacings * attackFrameCount;
export const atlasFrameCount = mutantAttackBase + combatFacings * attackFrameCount;

export function civilianFrameOrigin(index: number): Point {
  return [(index % columns) * civilianCell, Math.floor(index / columns) * civilianCell];
}

const fullTurn = Math.PI * 2;
type Joint = [side: number, forward: number, height: number];

function bentKnee(hip: Joint, ankle: Joint): Joint {
  const thigh = 0.55;
  const shin = 0.52;
  const forward = ankle[1] - hip[1];
  const down = ankle[2] - hip[2];
  const length = Math.hypot(forward, down);
  const reach = Math.min(length, thigh + shin - 0.001);
  const along = (thigh * thigh - shin * shin + reach * reach) / (2 * reach);
  const bend = Math.sqrt(Math.max(0, thigh * thigh - along * along));
  return [
    (hip[0] + ankle[0]) / 2,
    hip[1] + (forward * along - down * bend) / length,
    hip[2] + (down * along + forward * bend) / length,
  ];
}

function drawPose(context: CanvasRenderingContext2D, heading: number, frame: number, model: typeof spriteModels[number]) {
  const [top, pants, skin, hair] = model.colors;
  const waiting = frame >= runningFrames;
  const phase = frame / runningFrames;
  const bob = waiting ? 0.012 : -Math.cos((phase - 0.1) * fullTurn * 2) * 0.027;
  const mutant = model === mutantProfile;
  const zombie = model === zombieProfile || mutant;
  const sniper = model === soldierModels.sniper;
  const medic = model === soldierModels.medic;
  const soldier = model === infantryProfile || sniper || medic;
  const lean = waiting ? 0.025 : (zombie ? 0.43 : 0.24) + Math.sin(phase * fullTurn * 2) * 0.036;
  const twist = waiting ? 0 : Math.cos(phase * fullTurn) * 0.032;
  const hip: Joint = [0, 0, 1.01 + bob];
  const shoulders: Joint = [twist, lean, 1.81 + bob];
  const head: Joint = [waiting ? Math.sin((frame - runningFrames) * Math.PI / 2) * 0.08 : 0, lean + 0.13, 2.11 + bob];
  const c = Math.cos(heading);
  const s = Math.sin(heading);

  function project([side, forward, height]: Joint): Point {
    side *= model.build;
    return [forward * c - side * s, forward * s + side * c - height];
  }

  function line(joints: Joint[], width: number, color: string) {
    context.beginPath();
    context.moveTo(...project(joints[0]));
    for (const joint of joints.slice(1)) context.lineTo(...project(joint));
    context.lineWidth = width;
    context.strokeStyle = color;
    context.stroke();
  }

  function disk(joint: Joint, radius: number, color: string) {
    context.beginPath();
    context.arc(...project(joint), radius, 0, fullTurn);
    context.fillStyle = color;
    context.fill();
  }

  function limb(side: number) {
    const step = (phase + (side > 0 ? 0.5 : 0)) % 1;
    const stance = step < stanceFraction;
    const swing = (step - stanceFraction) / (1 - stanceFraction);
    const modelStride = model.stride / (civilianScale * model.height);
    const reach = stanceFraction * modelStride / 2;
    const eased = swing * swing * (3 - 2 * swing);
    const footForward = waiting ? side * 0.12 : stance ? reach - step * modelStride : -reach + eased * reach * 2 - Math.sin(swing * fullTurn) * 0.08;
    const lift = waiting || stance ? 0 : Math.sin(swing * Math.PI) ** 1.2 * (0.70 - swing * 0.31);
    const shoe: Joint = [side * 0.18, footForward, lift + 0.07];
    const hipJoint: Joint = [side * 0.14, hip[1] - side * twist, hip[2]];
    const leg = [hipJoint, bentKnee(hipJoint, shoe), shoe];

    // The planted foot passes under the hip as the opposite knee and arm drive forward.
    const armSwing = waiting ? side * 0.13 : -Math.cos((step - 0.08) * fullTurn) * model.armSwing;
    const shoulder: Joint = [side * 0.27 + twist, shoulders[1] + side * twist, shoulders[2] - 0.04];
    const elbow: Joint = [side * 0.37, lean + armSwing - 0.18, 1.41 + bob];
    const hand: Joint = [side * 0.32, lean + armSwing + (zombie ? 0.35 : 0.2), 1.52 + bob + (waiting ? 0.22 : 0.07)];
    line(leg, 0.25, '#24292d');
    line(leg, 0.17, pants);
    line([shoe, [shoe[0], shoe[1] + 0.18, shoe[2]]], soldier ? 0.2 : 0.16, soldier ? '#202c2a' : '#d7d3be');
    line([shoulder, elbow, hand], 0.19, '#2b3031');
    line([shoulder, elbow, hand], 0.13, top);
    disk(hand, 0.086, skin);
  }

  context.fillStyle = '#11191ca6';
  context.beginPath();
  context.ellipse(0.05, 0.11, 0.57, 0.37, 0, 0, fullTurn);
  context.fill();
  if (zombie) {
    context.strokeStyle = '#ec826c';
    context.lineWidth = 0.13;
    context.stroke();
  }

  const farSide = c >= 0 ? -1 : 1;
  limb(farSide);
  line([hip, shoulders], 0.64 * model.build, '#252c2f');
  line([hip, shoulders], 0.52 * model.build, top);
  limb(-farSide);
  if (soldier) {
    const armor = sniper ? '#515d48' : medic ? '#2c5554' : '#273934';
    const trim = sniper ? '#b5aa78' : medic ? '#91b9ab' : '#a0ad8b';
    line([[0, 0.08, 1.21 + bob], [0, lean, 1.73 + bob]], sniper ? 0.36 : 0.5, armor);
    if (medic) {
      const bag: Joint = [farSide * -0.34, lean - 0.21, 1.45 + bob];
      line([[bag[0], bag[1], bag[2] - 0.23], [bag[0], bag[1], bag[2] + 0.26]], 0.36, '#cbdad0');
      line([[bag[0], bag[1], bag[2] - 0.13], [bag[0], bag[1], bag[2] + 0.16]], 0.078, '#a63842');
      line([[bag[0] - 0.13, bag[1], bag[2]], [bag[0] + 0.13, bag[1], bag[2]]], 0.078, '#a63842');
    } else {
      line([[-0.22, lean + 0.06, 1.38 + bob], [0.22, lean + 0.06, 1.38 + bob]], 0.14, trim);
    }
    if (medic) {
      const grip: Joint = [0.26, lean + 0.32, 1.44 + bob];
      const slide: Joint = [0.26, lean + 0.36, 1.62 + bob];
      line([grip, slide], 0.12, '#202a2b');
      line([[0.26, lean + 0.29, slide[2]], [0.26, lean + 0.57, slide[2]]], 0.13, '#202a2b');
      line([[0.26, lean + 0.37, slide[2] + 0.03], [0.26, lean + 0.53, slide[2] + 0.03]], 0.035, '#7c9691');
    } else {
      const stock: Joint = [0.26, lean - (sniper ? 0.32 : 0.2), 1.48 + bob];
      const receiver: Joint = [0.2, lean + 0.29, 1.49 + bob];
      const muzzle: Joint = [0.16, lean + (sniper ? 1.26 : 0.85), 1.48 + bob];
      line([stock, receiver, muzzle], 0.11, '#202a2b');
      line([receiver, [0.2, lean + 0.24, 1.31 + bob]], 0.12, '#202a2b');
      if (sniper) line([[0.2, lean + 0.15, 1.65 + bob], [0.2, lean + 0.46, 1.65 + bob]], 0.10, '#202a2b');
    }
    disk(head, sniper ? 0.258 : 0.285, '#253531');
    disk([head[0], head[1] - 0.03, head[2] + 0.055], sniper ? 0.22 : 0.23, medic ? '#c2d5cb' : sniper ? '#918766' : '#617664');
    line([[-0.18, head[1] + 0.12, head[2] - 0.02], [0.18, head[1] + 0.12, head[2] - 0.02]], 0.115, '#162325');
    return;
  }
  if (mutant) {
    disk([0.32, lean - 0.05, 1.78 + bob], 0.37, '#693f4c');
    disk([0.37, lean + 0.025, 1.88 + bob], 0.24, '#a06b74');
    disk([-0.28, lean, 1.69 + bob], 0.23, '#704951');
  }
  disk(head, 0.245, '#272729');
  disk(head, 0.195, skin);
  disk([head[0], head[1] - 0.07, head[2] + 0.064], model.hairStyle === 'receding' ? 0.12 : 0.16, hair);
  if (model.hairStyle === 'ponytail') {
    const swing = waiting ? 0 : Math.sin(phase * fullTurn) * 0.075;
    line([[head[0], head[1] - 0.14, head[2]], [head[0] + swing, head[1] - 0.34, head[2] - 0.23]], 0.15, hair);
  } else if (model.hairStyle === 'bun') {
    disk([head[0], head[1] - 0.23, head[2] + 0.08], 0.11, hair);
  }
}

export function drawCivilianAtlas() {
  const canvas = document.createElement('canvas');
  canvas.width = civilianCell * columns;
  canvas.height = civilianCell * Math.ceil(atlasFrameCount / columns);
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas unavailable');
  context.lineCap = 'round';
  context.lineJoin = 'round';

  for (let palette = 0; palette < civilianPalettes; palette++) {
    for (let facing = 0; facing < civilianFacings; facing++) {
      const row = palette * civilianFacings + facing;
      for (let frame = 0; frame < civilianFrames; frame++) {
        context.save();
        const [x, y] = civilianFrameOrigin(row * civilianFrames + frame);
        context.translate(x + civilianAnchor[0] * civilianCell, y + civilianAnchor[1] * civilianCell);
        const model = spriteModels[palette];
        const scale = civilianPixelsPerMeter * model.height;
        context.scale(scale, scale);
        drawPose(context, facing / civilianFacings * fullTurn, frame, model);
        context.restore();
      }
    }
  }

  for (let facing = 0; facing < combatFacings; facing++) {
    const heading = facing / combatFacings * fullTurn;
    for (let palette = 0; palette < civilianProfiles.length; palette++) {
      const start = victimBase + (palette * combatFacings + facing) * victimFrames;
      const model = civilianProfiles[palette];
      for (let frame = 0; frame < victimFrames; frame++) {
        const pose = frame < attackFrameCount
          ? reactToBite(Math.floor(frame / attackFrames), frame % attackFrames / (attackFrames - 1))
          : frame === attackFrameCount ? grounded : rise((frame - attackFrameCount - 1) / (riseFrames - 1));
        drawCombatFrame(context, start + frame, heading, model, pose, frame >= attackFrameCount + riseFrames);
      }
    }
    for (let frame = 0; frame < attackFrameCount; frame++) {
      const pose = bitePose(Math.floor(frame / attackFrames), frame % attackFrames / (attackFrames - 1));
      drawCombatFrame(context, attackerBase + facing * attackFrameCount + frame, heading, zombieProfile, pose, true);
      drawCombatFrame(context, mutantAttackBase + facing * attackFrameCount + frame, heading, mutantProfile, pose, true);
    }
  }
  return canvas;
}

// Hip, shoulders, head, then knee, foot, elbow and hand for each side.
type Puppet = [Joint, Joint, Joint, Joint, Joint, Joint, Joint, Joint, Joint, Joint, Joint];
const upright: Puppet = [
  [0, 0, 1], [0, 0.07, 1.78], [0, 0.13, 2.12],
  [-0.19, 0.18, 0.53], [-0.2, 0.22, 0.07], [-0.41, 0.14, 1.36], [-0.46, 0.36, 1.54],
  [0.19, -0.18, 0.55], [0.2, -0.22, 0.07], [0.41, -0.07, 1.37], [0.42, 0.2, 1.5],
];
const grounded: Puppet = [
  [0, 0, 0.12], [0, 0.64, 0.1], [0.05, 0.99, 0.09],
  [-0.17, -0.43, 0.09], [-0.29, -0.87, 0.06], [-0.38, 0.36, 0.08], [-0.6, 0.53, 0.06],
  [0.2, -0.48, 0.08], [0.31, -0.88, 0.06], [0.4, 0.38, 0.08], [0.57, 0.61, 0.06],
];
const kneeling: Puppet = [
  [0, -0.18, 0.57], [0, 0.39, 0.88], [0.05, 0.66, 1.02],
  [-0.2, 0.07, 0.15], [-0.25, -0.48, 0.07], [-0.36, 0.49, 0.5], [-0.39, 0.55, 0.07],
  [0.2, -0.46, 0.26], [0.2, -0.75, 0.07], [0.36, 0.55, 0.56], [0.39, 0.7, 0.1],
];
const shoulderRecoil: Puppet = [
  [0, 0, 0.95], [-0.19, 0.28, 1.63], [-0.32, 0.45, 1.94],
  [-0.24, 0.31, 0.49], [-0.32, 0.31, 0.07], [-0.57, 0.06, 1.36], [-0.25, 0.25, 1.69],
  [0.23, -0.31, 0.47], [0.22, -0.46, 0.07], [0.34, 0.27, 1.53], [0.52, 0.5, 1.71],
];
const armRecoil: Puppet = [
  [0.02, 0.02, 0.94], [0.14, 0.24, 1.69], [0.25, 0.46, 1.96],
  [-0.19, -0.24, 0.47], [-0.28, -0.47, 0.07], [-0.49, -0.26, 1.48], [-0.66, -0.48, 1.36],
  [0.28, 0.35, 0.5], [0.34, 0.41, 0.07], [0.45, 0.41, 1.47], [0.68, 0.63, 1.56],
];

function ease(progress: number) {
  const t = Math.max(0, Math.min(1, progress));
  return t * t * (3 - 2 * t);
}

function mixPose(a: Puppet, b: Puppet, t: number): Puppet {
  return a.map(([x, y, z], index): Joint => [
    x + (b[index][0] - x) * t,
    y + (b[index][1] - y) * t,
    z + (b[index][2] - z) * t,
  ]) as Puppet;
}

function reactToBite(variant: number, progress: number) {
  const collapse = bites[variant].collapse;
  const recoil = variant === 1 ? armRecoil : shoulderRecoil;
  const flinch = mixPose(upright, recoil, ease(progress / Math.min(collapse, 0.25)));
  return mixPose(flinch, grounded, ease((progress - collapse) / (1 - collapse)));
}

function rise(progress: number) {
  if (progress < 0.57) return mixPose(grounded, kneeling, ease(progress / 0.57));
  return mixPose(kneeling, upright, ease((progress - 0.57) / 0.43));
}

function bitePose(variant: number, progress: number) {
  const reach = ease(progress / 0.32) * (1 - ease((progress - 0.73) / 0.27));
  if (variant === 2) {
    const pin: Puppet = [
      [0, 0.19, 0.51], [0.01, 0.73, 0.6], [0.04, 1.01, 0.46],
      [-0.21, 0.37, 0.26], [-0.24, -0.32, 0.08], [-0.39, 0.61, 0.4], [-0.41, 0.92, 0.17],
      [0.24, 0.06, 0.16], [0.26, -0.48, 0.07], [0.31, 0.72, 0.45], [0.31, 1.04, 0.18],
    ];
    return mixPose(upright, pin, reach);
  }
  const lower = variant === 1;
  const lunge: Puppet = [
    [0, 0.17, 0.92], [0.04, 0.62, lower ? 1.38 : 1.61], [lower ? -0.22 : 0.13, 0.91, lower ? 1.26 : 1.68],
    [-0.19, 0.41, 0.48], [-0.2, 0.49, 0.07], [-0.39, 0.62, 1.31], [-0.29, 1.02, lower ? 1.18 : 1.56],
    [0.21, -0.27, 0.5], [0.24, -0.45, 0.07], [0.46, 0.58, 1.29], [0.34, 0.96, lower ? 1.22 : 1.48],
  ];
  return mixPose(upright, lunge, reach);
}

function drawCombatFrame(context: CanvasRenderingContext2D, index: number, heading: number, model: typeof spriteModels[number], pose: Puppet, infected: boolean) {
  const [x, y] = civilianFrameOrigin(index);
  context.save();
  context.translate(x + civilianAnchor[0] * civilianCell, y + civilianAnchor[1] * civilianCell);
  const scale = civilianPixelsPerMeter * model.height;
  context.scale(scale, scale);
  const [top, pants, skin, hair] = model.colors;
  const color = infected && model !== zombieProfile && model !== mutantProfile ? '#b5b58d' : skin;
  const c = Math.cos(heading);
  const s = Math.sin(heading);
  const point = ([side, forward, height]: Joint): Point => [
    forward * c - side * s * model.build, forward * s + side * c * model.build - height,
  ];
  function limb(joints: Joint[], weight: number, tint: string) {
    context.beginPath();
    context.moveTo(...point(joints[0]));
    for (const joint of joints.slice(1)) context.lineTo(...point(joint));
    context.strokeStyle = '#24292c';
    context.lineWidth = weight + 0.07;
    context.stroke();
    context.strokeStyle = tint;
    context.lineWidth = weight;
    context.stroke();
  }
  function disk(joint: Joint, size: number, tint: string) {
    context.beginPath();
    context.arc(...point(joint), size, 0, fullTurn);
    context.fillStyle = tint;
    context.fill();
  }
  const [hip, shoulders, head] = pose;
  const flat = shoulders[2] < 0.3;
  context.beginPath();
  context.ellipse(0, 0.08, flat ? 1.01 : 0.54, 0.32, flat ? heading : 0, 0, fullTurn);
  context.fillStyle = '#11191cab';
  context.fill();
  if (infected) {
    context.lineWidth = 0.12;
    context.strokeStyle = '#ec826c';
    context.stroke();
  }
  function side(offset: number, sign: number) {
    const [knee, foot, elbow, hand] = pose.slice(offset, offset + 4);
    limb([[sign * 0.13, hip[1], hip[2]], knee, foot], 0.19, pants);
    limb([foot, [foot[0], foot[1] + 0.16, foot[2]]], 0.15, '#d7d3be');
    limb([[shoulders[0] + sign * 0.23, shoulders[1], shoulders[2]], elbow, hand], 0.14, top);
    disk(hand, 0.083, color);
  }
  const far = c >= 0 ? -1 : 1;
  side(far === -1 ? 3 : 7, far);
  limb([hip, shoulders], 0.49 * model.build, top);
  side(far === -1 ? 7 : 3, -far);
  disk(head, 0.24, '#29282a');
  disk(head, 0.19, color);
  disk([head[0], head[1] - 0.07, head[2] + 0.06], 0.145, hair);
  context.restore();
}

export function encounterFrame(scene: Encounter, time: number, attacker = false) {
  const turn = attacker ? scene.heading : scene.fallHeading;
  const direction = (Math.round(turn / fullTurn * combatFacings) + combatFacings) % combatFacings;
  const sample = (progress: number, frames: number) => Math.min(frames - 1, Math.max(0, Math.floor(progress * frames)));
  const attack = scene.variant * attackFrames;
  if (attacker) {
    return (scene.attacker.mutant ? mutantAttackBase : attackerBase) + direction * attackFrameCount + attack + sample((time - scene.start) / (scene.biteEnd - scene.start), attackFrames);
  }
  const base = victimBase + (scene.victim.profile * combatFacings + direction) * victimFrames;
  if (time < scene.downAt) return base + attack + sample((time - scene.start) / (scene.downAt - scene.start), attackFrames);
  if (time < scene.riseAt) return base + attackFrameCount;
  return base + attackFrameCount + 1 + sample((time - scene.riseAt) / riseDuration, riseFrames);
}

export function civilianFrame(person: Civilian, index: number, time: number, zombie = false) {
  const glance = time - (person.glanceAt ?? -1);
  const look = !zombie && glance >= 0 && glance < 0.46
    ? Math.sin(glance / 0.46 * Math.PI) * (person.random & 1 ? 0.32 : -0.32) : 0;
  const heading = person.heading + look;
  const waiting = person.status === 'holding' || (person.status === 'sheltered' ? person.speed === 0 : person.pauseUntil > time);
  const rotation = Math.round(heading / fullTurn * civilianFacings) % civilianFacings;
  const facing = (rotation + civilianFacings) % civilianFacings;
  const mutant = zombie && (person as Zombie).mutant;
  const model = mutant ? mutantProfile : zombie ? zombieProfile : civilianProfiles[person.profile];
  const frame = waiting
    ? runningFrames + Math.floor(time * 3 + index * 1.7) % waitingFrames
    : Math.floor((person.travel / model.stride + index * 0.27) * runningFrames) % runningFrames;
  const palette = zombie ? civilianProfiles.length + (mutant ? 1 : 0) : person.profile;
  return (palette * civilianFacings + facing) * civilianFrames + frame;
}

export function soldierFrame(soldier: Soldier, index: number, time: number) {
  const facing = (Math.round(soldier.heading / fullTurn * civilianFacings) + civilianFacings) % civilianFacings;
  const model = soldierModels[soldier.type];
  const frame = soldier.speed > 0
    ? Math.floor((soldier.travel / model.stride + index * 0.27) * runningFrames) % runningFrames
    : runningFrames + Math.floor(time * 3 + index * 1.7) % waitingFrames;
  return ((soldierPalette + soldierTypes.indexOf(soldier.type)) * civilianFacings + facing) * civilianFrames + frame;
}

export function drawSoldierPreview(canvas: HTMLCanvasElement, type: Soldier['type']) {
  const context = canvas.getContext('2d');
  if (!context) return;
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.save();
  context.translate(canvas.width / 2, canvas.height * 0.83);
  context.scale(20, 20);
  context.lineCap = 'round';
  context.lineJoin = 'round';
  drawPose(context, 0.15, runningFrames, soldierModels[type]);
  context.restore();
}
