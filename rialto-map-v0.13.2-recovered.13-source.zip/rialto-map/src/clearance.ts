import type { Point } from './routing.ts';
import type { Zombie } from './outbreak.ts';
import type { Soldier } from './defense.ts';

export type ClearanceSector = { name: string; point: Point };
export const sectorRadius = 22;
export const reliefSeconds = 8;

export class Clearance {
  readonly sectors: (ClearanceSector & { remaining: number; held: number; secured: boolean })[];
  constructor(sites: readonly ClearanceSector[]) {
    this.sectors = sites.map(site => ({ ...site, remaining: 0, held: 0, secured: false }));
  }

  get secured() { return this.sectors.filter(sector => sector.secured).length; }

  update(zombies: readonly Zombie[], soldiers: readonly Soldier[], seconds: number) {
    const nearby = (point: Point, actor: { x: number; y: number }) =>
      (actor.x - point[0]) ** 2 + (actor.y - point[1]) ** 2 <= sectorRadius ** 2;
    for (const [index, sector] of this.sectors.entries()) {
      sector.remaining = zombies.filter(zombie => zombie.sector === index || nearby(sector.point, zombie)).length;
      if (sector.secured) continue;
      if (sector.remaining || !soldiers.some(soldier => soldier.state === 'patrol' && !soldier.roofHeight && nearby(sector.point, soldier))) {
        sector.held = 0;
        continue;
      }
      sector.held += seconds;
      if (sector.held + 1e-6 >= reliefSeconds) sector.secured = true;
    }
  }
}
