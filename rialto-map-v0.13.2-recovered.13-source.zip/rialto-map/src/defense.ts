import { cellSize, steps, type CrowdField } from './crowd-field.ts';
import { clearSight, localPath } from './pursuit.ts';
import { aimRunner, moveRunner, runnerTargetOpen, type RunnerMotion } from './runner-motion.ts';
import type { Outbreak, Zombie } from './outbreak.ts';
import { Fortifications, gateIntegrity, type Barricade, type ZoneGate } from './fortifications.ts';
import { random } from './spawn-planning.ts';
import type { Point } from './routing.ts';

export const evacuationRadius = 36;
export const maxSquadSize = 160;
export const infantryCost = 100;
export const sniperCost = 240;
export const medicCost = 180;
export const medicSupplies = 5;
export const boardingSeconds = 4;
export const patrolRadius = 8;

export function hiringBudget(civilians: number, infected: number) {
  return 2000 + Math.floor(civilians / 120) * 100 + Math.floor(infected / 60) * 100;
}

export function shotAccuracy(distance: number, range: number) {
  return 0.96 - 0.58 * Math.min(1, distance / range) ** 1.6;
}
export const squadSize = 4;
export const fallbackSeconds = 12;

export const weapons = {
  precision: { range: 48, interval: 1.35, magazine: 5, reload: 2.6, damage: 2 },
  pistol: { range: 9, interval: 0.7, magazine: 8, reload: 1.8, damage: 1 },
  carbine: { range: 23, interval: 0.48, magazine: 12, reload: 2.2, damage: 1 },
} as const;

export const soldierTypes = {
  sniper: { label: 'Sniper', weapon: 'precision', speed: 4.1, patrolSpeed: 0, health: 2 },
  medic: { label: 'Field medic', weapon: 'pistol', speed: 4.05, patrolSpeed: 1.75, health: 3 },
  infantry: { label: 'SWAT infantry', weapon: 'carbine', speed: 4.25, patrolSpeed: 1.8, health: 3 },
} as const satisfies Record<string, { label: string; weapon: keyof typeof weapons; speed: number; patrolSpeed: number; health: number }>;

export function deploymentUpgrade(type: keyof typeof soldierTypes) {
  return type === 'sniper' ? sniperCost - infantryCost : type === 'medic' ? medicCost - infantryCost : 0;
}

export type Deployment = { position: Point; type: keyof typeof soldierTypes; roof?: { height: number; access: Point } };
export type Soldier = RunnerMotion & {
  type: Deployment['type'];
  roofHeight: number;
  state: 'patrol' | 'fallback' | 'aboard' | 'lost';
  ammo: number;
  reloadUntil: number;
  nextShot: number;
  health: number;
  supplies: number;
  treatingUntil: number;
  returnPatrol?: number;
  rescue?: { cell: number; escort: boolean };
  patrolCenter?: number;
  patrolObstruction?: ZoneGate | null;
  path: number[];
  pathIndex: number;
  retryAt: number;
  nextWound: number;
  seed: number;
  roundsFired: number;
  aimUntil: number;
  patrolTurn: number;
};

export type Shot = { from: Point; to: Point; start: number; until: number };
type Impact = { shot: Shot; target: Zombie; damage: number; at: number; origin: Point; roofHeight: number };

export class Defense {
  readonly soldiers: Soldier[] = [];
  readonly shots: Shot[] = [];
  readonly center: Point;
  fortifications?: Fortifications;
  overrun = false;
  private exposedFor = 0;
  phase: 'defend' | 'fallback' | 'departed' = 'defend';
  eliminated = 0;
  private readonly impacts: Impact[] = [];
  readonly fallbackWindow: number;
  readonly radius: number;
  private readonly startingCount: number;
  reinforcementSpend = 0;
  get count() { return this.started ? this.soldiers.length : this.startingCount; }
  private started = false;
  private readonly seed: number;
  private readonly patrolPaths = new Map<number, number[][]>();
  private baseline?: Uint16Array;
  private rally: Uint16Array = new Uint16Array(0);
  private nextSweep = 0;
  private readonly routes = new Map<number, number[]>();
  private readonly nearby = new Map<number, Zombie[]>();
  private readonly terrain: CrowdField;
  private readonly goal: number;
  private readonly duration: number;
  private readonly barricades: readonly Barricade[];
  private readonly clearance: boolean;
  private readonly gateLockdown: boolean;
  private readonly deployments: readonly Deployment[];

  constructor(terrain: CrowdField, goal: number, duration: number, deployments: readonly Deployment[], count = squadSize, radius = evacuationRadius, seed = 0, barricades: readonly Barricade[] = [], gateLockdown = false, clearance = false) {
    this.terrain = terrain;
    this.goal = goal;
    this.duration = duration;
    this.deployments = deployments;
    this.startingCount = count;
    this.radius = radius;
    this.seed = seed;
    this.barricades = barricades;
    this.gateLockdown = gateLockdown;
    this.clearance = clearance;
    this.fallbackWindow = Math.max(fallbackSeconds, Math.ceil(radius * 0.52));
    this.center = [terrain.x(goal), terrain.y(goal)];
  }

  get aboard() { return this.soldiers.filter(soldier => soldier.state === 'aboard').length; }
  get lost() { return this.soldiers.filter(soldier => soldier.state === 'lost').length; }
  get coverage() {
    return (this.fortifications?.gates ?? []).map(gate => ({
      guards: this.active.filter(soldier => Math.hypot(soldier.x - gate.position[0], soldier.y - gate.position[1]) <= 12).length,
      integrity: Math.ceil(gate.integrity / gateIntegrity * 100),
    }));
  }

  gatesChanged() {
    this.routes.clear();
    this.patrolPaths.clear();
  }

  orderPatrol(indices: Iterable<number>, point: Point, mask: number, rescue = false, returnAfterRescue = false) {
    if (this.phase !== 'defend') return { assigned: 0, blocked: 0, point: undefined };
    const center = this.terrain.nearest(point, mask, undefined, 6);
    if (center < 0) return { assigned: 0, blocked: 0, point: undefined };
    let assigned = 0;
    let blocked = 0;
    for (const index of indices) {
      const soldier = this.soldiers[index];
      if (!soldier || soldier.roofHeight || soldier.state !== 'patrol') continue;
      const start = soldier.target >= 0 ? soldier.target : soldier.cell;
      const path = this.route(start, center, mask);
      soldier.returnPatrol = rescue && returnAfterRescue
        ? soldier.rescue ? soldier.returnPatrol ?? start : soldier.patrolCenter ?? start
        : undefined;
      soldier.rescue = rescue ? { cell: center, escort: false } : undefined;
      soldier.patrolCenter = center;
      soldier.patrolObstruction = start !== center && !path.length ? this.findObstruction(start, center, mask) : undefined;
      if (soldier.patrolObstruction !== undefined) blocked++;
      soldier.path = path;
      soldier.pathIndex = 0;
      soldier.retryAt = 0;
      assigned++;
    }
    return { assigned, blocked, point: [this.terrain.x(center), this.terrain.y(center)] as Point };
  }

  get active() { return this.soldiers.filter(soldier => soldier.state !== 'aboard' && soldier.state !== 'lost'); }

  start(mask: number, flow: Uint16Array, baseline = flow) {
    if (this.started) return;
    this.started = true;
    this.baseline = baseline;
    this.preparePerimeter(baseline);
    this.replan(mask, flow);
    for (let index = 0; index < this.startingCount; index++) {
      const deployment = this.deployments[index];
      const placed = deployment ? this.terrain.nearest(deployment.roof?.access ?? deployment.position,
        mask, baseline, deployment.roof ? 15 : 3) : -1;
      this.addSoldier(placed >= 0 ? deployment : deployment && { type: deployment.type, position: this.center },
        placed >= 0 ? placed : this.goal);
    }
  }

  canReinforce(elapsed: number) {
    return this.started && !this.clearance && this.phase !== 'departed' && !this.overrun && this.count < maxSquadSize
      && elapsed < this.duration - boardingSeconds;
  }

  reinforce(deployment: Deployment, mask: number, elapsed: number, credits: number) {
    const cost = infantryCost + deploymentUpgrade(deployment.type);
    if (!this.canReinforce(elapsed) || credits < cost) return false;
    const cell = this.deploymentCell(deployment, mask);
    if (cell < 0 || !this.rally[cell]) return false;
    this.addSoldier(deployment, cell);
    this.reinforcementSpend += cost;
    return true;
  }

  private deploymentCell(deployment: Deployment, mask: number) {
    if (deployment.roof) return this.terrain.nearest(deployment.roof.access, mask, this.baseline, 15);
    const cell = this.terrain.cell(...deployment.position);
    return this.terrain.open(cell, mask) && this.baseline?.[cell] ? cell : -1;
  }

  private addSoldier(deployment: Deployment | undefined, cell: number) {
    const index = this.soldiers.length;
    const type = deployment?.type ?? 'infantry';
    const unit = soldierTypes[type];
    const roofHeight = type === 'sniper' ? deployment?.roof?.height ?? 0 : 0;
    const x = roofHeight && deployment ? deployment.position[0] : this.terrain.x(cell);
    const y = roofHeight && deployment ? deployment.position[1] : this.terrain.y(cell);
    const soldier: Soldier = {
      type, roofHeight, cell, x, y, target: -1, targetX: x, targetY: y, heading: (index % 4 - 2) * Math.PI / 2,
      vx: 0, vy: 0, speed: 0, travel: 0, ammo: weapons[unit.weapon].magazine, reloadUntil: 0, nextShot: 0,
      health: unit.health, supplies: type === 'medic' ? medicSupplies : 0, treatingUntil: 0, state: 'patrol',
      path: [], pathIndex: 0, retryAt: 0, nextWound: 0, seed: this.seed ^ Math.imul(index + 1, 0x9e3779b1),
      roundsFired: 0, aimUntil: 0, patrolTurn: index,
    };
    this.soldiers.push(soldier);
  }

  preparePerimeter(baseline: Uint16Array) {
    this.fortifications ??= new Fortifications(this.terrain, this.center, baseline, this.barricades);
  }

  inside(x: number, y: number) {
    return (x - this.center[0]) ** 2 + (y - this.center[1]) ** 2 <= this.radius ** 2;
  }

  replan(mask: number, flow: Uint16Array) {
    this.rally = flow;
    this.routes.clear();
    this.patrolPaths.clear();
    for (const soldier of this.active) {
      soldier.path = [];
      soldier.pathIndex = 0;
      soldier.retryAt = 0;
      soldier.patrolObstruction = undefined;
      const actual = this.terrain.cell(soldier.x, soldier.y);
      if (soldier.target >= 0 && this.terrain.open(actual, mask)
        && (!runnerTargetOpen(soldier, this.terrain, mask)
          || (actual === soldier.cell && this.fortifications?.allows(soldier.cell, soldier.target, false) === false))) {
        aimRunner(soldier, this.terrain, soldier.cell, mask);
      }
      if (soldier.state === 'patrol' && soldier.patrolCenter !== undefined) {
        const start = soldier.target >= 0 ? soldier.target : soldier.cell;
        if (soldier.rescue?.escort) continue;
        soldier.path = this.route(start, soldier.patrolCenter, mask);
        if (!soldier.path.length && start !== soldier.patrolCenter) {
          soldier.patrolObstruction = this.findObstruction(start, soldier.patrolCenter, mask);
        }
      }
    }
  }

  tick(elapsed: number, seconds: number, mask: number, outbreak: Outbreak) {
    const before = this.fortifications?.gates.map(gate => gate.integrity > 0 && gate.open && !gate.locked || gate.integrity <= 0).join();
    this.fortifications?.resolve(seconds, elapsed);
    if (!this.clearance && !this.overrun) {
      const occupied = outbreak.zombies.some(zombie => this.rally[this.terrain.cell(zombie.x, zombie.y)] === 1);
      this.exposedFor = occupied ? this.exposedFor + seconds : 0;
      this.overrun = this.exposedFor >= 3;
    }
    let pending = 0;
    for (const impact of this.impacts) {
      if (impact.at > elapsed) {
        this.impacts[pending++] = impact;
        continue;
      }
      const { shot, target } = impact;
      if (target.health !== 0 && (target.x - shot.to[0]) ** 2 + (target.y - shot.to[1]) ** 2 <= 1.6 ** 2
        && this.hasSight(impact.origin, impact.roofHeight, target, mask)) {
        outbreak.decals.hit([target.x, target.y], shot.from, elapsed);
        if (outbreak.hit(target, impact.damage)) this.eliminated++;
      }
    }
    this.impacts.length = pending;
    if (!this.clearance && elapsed >= this.duration - this.fallbackWindow) this.phase = 'fallback';
    while (this.shots.length && this.shots[0].until <= elapsed) this.shots.shift();
    const fire = elapsed >= this.nextSweep;
    if (fire) {
      this.nextSweep = elapsed + 0.12;
      this.nearby.clear();
      for (const zombie of outbreak.zombies) {
        const key = this.bucket(zombie.x, zombie.y);
        const occupants = this.nearby.get(key);
        if (occupants) occupants.push(zombie);
        else this.nearby.set(key, [zombie]);
      }
    }
    if (fire && this.gateLockdown) this.scanGates(mask);
    if (before !== this.fortifications?.gates.map(gate => gate.integrity > 0 && gate.open && !gate.locked || gate.integrity <= 0).join()) this.gatesChanged();
    for (const soldier of this.active) {
      if (!this.clearance && soldier.state !== 'fallback' && (this.phase === 'fallback'
        || this.rally[soldier.cell] * cellSize * 1.55 / soldierTypes[soldier.type].speed + boardingSeconds + 2 >= this.duration - elapsed)) {
        if (soldier.roofHeight) {
          soldier.roofHeight = 0;
          soldier.x = this.terrain.x(soldier.cell);
          soldier.y = this.terrain.y(soldier.cell);
          soldier.aimUntil = elapsed + 1;
        }
        soldier.state = 'fallback';
        soldier.rescue = undefined;
        soldier.path = [];
      }
      if (elapsed >= soldier.aimUntil && elapsed >= soldier.treatingUntil && (soldier.type !== 'sniper' || soldier.state === 'fallback' || soldier.patrolCenter !== undefined)) this.move(soldier, elapsed, seconds, mask);
      if (soldier.reloadUntil && elapsed >= soldier.reloadUntil) {
        soldier.reloadUntil = 0;
        soldier.ammo = weapons[soldierTypes[soldier.type].weapon].magazine;
      }
      if (fire && soldier.state !== 'aboard' && elapsed >= soldier.treatingUntil) {
        const candidates = this.targets(soldier.x, soldier.y, this.range(soldier));
        this.fire(soldier, elapsed, mask, candidates);
        if (!soldier.roofHeight) this.checkContact(soldier, elapsed, mask, candidates);
      }
    }
  }

  private move(soldier: Soldier, elapsed: number, seconds: number, mask: number) {
    const unit = soldierTypes[soldier.type];
    const pace = soldier.state !== 'patrol' || (soldier.rescue && !soldier.rescue.escort)
      || (this.clearance && soldier.patrolCenter !== undefined
        && (this.terrain.x(soldier.patrolCenter) - soldier.x) ** 2 + (this.terrain.y(soldier.patrolCenter) - soldier.y) ** 2 > patrolRadius ** 2) ? unit.speed
      : soldier.rescue?.escort ? 2.7 : unit.patrolSpeed || 1.8;
    soldier.speed = pace * this.terrain.paceFactor(soldier.cell) * (soldier.health < unit.health ? 0.72 : 1);
    let remaining = soldier.speed * seconds;
    while (remaining > 0.0001) {
      if (soldier.target < 0) {
        if (soldier.state === 'fallback' && Math.hypot(soldier.x - this.center[0], soldier.y - this.center[1]) <= 6 && this.rally[soldier.cell] === 1) {
          if (elapsed >= this.duration - boardingSeconds) soldier.state = 'aboard';
          soldier.speed = 0;
          return;
        }
        const localMask = this.terrain.open(soldier.cell, mask) ? mask : 0;
        const next = soldier.state === 'patrol' ? this.patrolStep(soldier, elapsed, localMask) : this.rallyStep(soldier, localMask);
        if (next < 0) {
          soldier.speed = 0;
          return;
        }
        aimRunner(soldier, this.terrain, next, mask);
        if (this.fortifications?.gates.length && soldier.curve) soldier.curve.length = 0;
      }
      if (soldier.target !== soldier.cell && this.terrain.cell(soldier.x, soldier.y) === soldier.cell
        && !this.fortifications?.allows(soldier.cell, soldier.target, false) && this.fortifications) {
        soldier.path = [];
        aimRunner(soldier, this.terrain, soldier.cell, mask);
      }
      remaining -= moveRunner(soldier, remaining, 10);
      if (soldier.x !== soldier.targetX || soldier.y !== soldier.targetY) return;
      soldier.cell = soldier.target;
      soldier.target = -1;
    }
  }

  private rallyStep(soldier: Soldier, mask: number) {
    const flow = this.rally;
    let best = -Infinity;
    let target = -1;
    for (const [direction, [dx, dy]] of steps.entries()) {
      const next = soldier.cell + dy * this.terrain.columns + dx;
      if (!flow[next] || (flow[soldier.cell] && flow[next] >= flow[soldier.cell]) || !this.terrain.canStep(soldier.cell, direction, mask)
        || this.fortifications?.allows(soldier.cell, next, false) === false) continue;
      const score = -flow[next] + (dx * soldier.vx + dy * soldier.vy) * 0.25;
      if (score > best) { best = score; target = next; }
    }
    return target;
  }

  private scanGates(mask: number) {
    const forts = this.fortifications;
    if (!forts) return;
    for (const gate of forts.gates) {
      if (gate.integrity <= 0) continue;
      const [[x, y], [endX, endY]] = gate.span;
      const dx = endX - x;
      const dy = endY - y;
      const side = Math.sign(dx * (this.terrain.y(gate.post) - y) - dy * (this.terrain.x(gate.post) - x))
        || Math.sign(dx * (this.center[1] - y) - dy * (this.center[0] - x)) || 1;
      let count = 0;
      for (const zombie of this.targets(...gate.position, 12)) {
        if ((dx * (zombie.y - y) - dy * (zombie.x - x)) * side >= 0
          || Math.hypot(zombie.x - gate.position[0], zombie.y - gate.position[1]) > 12) continue;
        if (clearSight(this.terrain, gate.post, this.terrain.cell(zombie.x, zombie.y), mask)) count++;
      }
      forts.updateLockdown(gate, count);
    }
  }

  private route(start: number, end: number, mask: number) {
    const key = (start * this.terrain.cells.length + end) * 16 + mask;
    let path = this.routes.get(key);
    if (!path) {
      path = localPath(this.terrain, start, end, mask, cell => !!this.baseline?.[cell], 24000, 1200,
        (from, to) => this.fortifications?.allows(from, to, false) ?? true);
      if (this.routes.size >= 1024) this.routes.clear();
      this.routes.set(key, path);
    }
    return path;
  }

  patrolView(soldier: Soldier) {
    const point = (cell: number): Point => [this.terrain.x(cell), this.terrain.y(cell)];
    return {
      center: soldier.patrolCenter === undefined ? undefined : point(soldier.patrolCenter),
      rescue: soldier.rescue,
      obstruction: soldier.patrolObstruction?.position,
      blocked: soldier.patrolObstruction !== undefined,
      path: [[soldier.x, soldier.y] as Point,
        ...(soldier.target >= 0 ? [point(soldier.target)] : []),
        ...soldier.path.slice(soldier.pathIndex).map(point)],
    };
  }

  private findObstruction(start: number, end: number, mask: number) {
    if (!this.fortifications?.gates.length) return null;
    const path = localPath(this.terrain, start, end, mask, cell => !!this.baseline?.[cell], 24000, 1200);
    let from = start;
    for (const next of path) {
      const gate = this.fortifications.blockingGate(from, next);
      if (gate) return gate;
      from = next;
    }
    return null;
  }

  private patrolStep(soldier: Soldier, elapsed: number, mask: number) {
    if (soldier.pathIndex < soldier.path.length) return soldier.path[soldier.pathIndex++];
    if (elapsed < soldier.retryAt) return -1;
    soldier.retryAt = elapsed + 0.85;
    if (soldier.rescue?.escort) {
      if (this.rally[soldier.cell] > 1) return this.rallyStep(soldier, mask);
      if (this.rally[soldier.cell] === 1) {
        soldier.rescue = undefined;
        soldier.patrolCenter = soldier.returnPatrol ?? this.goal;
        soldier.returnPatrol = undefined;
      } else return -1;
    }
    const post = soldier.patrolCenter ?? soldier.cell;
    const radius = soldier.rescue ? 0.7 : soldier.patrolCenter === undefined ? 18 : patrolRadius;
    const distance = Math.hypot(soldier.x - this.terrain.x(post), soldier.y - this.terrain.y(post));
    const route = distance > radius || soldier.patrolObstruction !== undefined ? this.route(soldier.cell, post, mask) : [];
    if (route.length) {
      soldier.patrolObstruction = undefined;
      soldier.path = route;
      soldier.pathIndex = 1;
      return route[0];
    }
    if (distance > radius) {
      if (soldier.patrolObstruction === undefined) soldier.patrolObstruction = this.findObstruction(soldier.cell, post, mask);
      return -1;
    }
    if (soldier.patrolObstruction !== undefined && soldier.cell !== post) return -1;
    soldier.patrolObstruction = undefined;
    if (soldier.rescue) return -1;
    const options = this.roamingPaths(soldier.cell, post, radius, mask);
    if (!options.length) return -1;
    const seed = soldier.seed + ++soldier.patrolTurn * 91;
    const heading = random(seed) * 2 * Math.PI;
    let best = -Infinity;
    for (const path of options) {
      const end = path.at(-1)!;
      const dx = this.terrain.x(end) - soldier.x;
      const dy = this.terrain.y(end) - soldier.y;
      const score = dx * Math.cos(heading) + dy * Math.sin(heading) + random(seed ^ end);
      if (score <= best) continue;
      best = score;
      soldier.path = path;
    }
    soldier.pathIndex = 1;
    return soldier.path[0];
  }

  private roamingPaths(start: number, post: number, radius: number, mask: number) {
    const key = ((start * this.terrain.cells.length + post) * 16 + mask) * 4 + (radius === patrolRadius ? 0 : 1);
    const cached = this.patrolPaths.get(key);
    if (cached) return cached;
    const queue = [start];
    const parents = new Map<number, number>([[start, -1]]);
    const x = this.terrain.x(post);
    const y = this.terrain.y(post);
    const sectors = new Map<number, { cell: number; distance: number }>();
    let nearest = Infinity;
    let fallback = -1;
    for (let index = 0; index < queue.length && index < 480; index++) {
      const cell = queue[index];
      const distance = (this.terrain.x(cell) - x) ** 2 + (this.terrain.y(cell) - y) ** 2;
      if (cell !== start && distance < nearest) {
        nearest = distance;
        fallback = cell;
      }
      if (index >= 42 && distance <= radius ** 2
        && Math.hypot(this.terrain.x(cell) - this.terrain.x(start), this.terrain.y(cell) - this.terrain.y(start)) > 2.4) {
        const dx = this.terrain.x(cell) - this.terrain.x(start);
        const dy = this.terrain.y(cell) - this.terrain.y(start);
        const sector = Math.round(Math.atan2(dy, dx) / (Math.PI / 4));
        const displacement = dx * dx + dy * dy;
        if (displacement > (sectors.get(sector)?.distance ?? 0)) sectors.set(sector, { cell, distance: displacement });
      }
      for (const [direction, [dx, dy]] of steps.entries()) {
        const next = cell + dy * this.terrain.columns + dx;
        if (parents.has(next) || !this.rally[next] || !this.terrain.canStep(cell, direction, mask) || this.fortifications?.allows(cell, next, false) === false) continue;
        parents.set(next, cell);
        queue.push(next);
      }
    }
    const destinations = [...sectors.values()].map(({ cell }) => cell);
    if (!destinations.length && fallback >= 0) destinations.push(fallback);
    const paths = destinations.map(destination => {
      const path: number[] = [];
      for (let cell = destination; cell !== start; cell = parents.get(cell)!) path.push(cell);
      return path.reverse();
    });
    if (this.patrolPaths.size >= 1024) this.patrolPaths.clear();
    this.patrolPaths.set(key, paths);
    return paths;
  }

  private bucket(x: number, y: number) {
    return Math.floor(x / 24) + Math.floor(y / 24) * 4096;
  }

  private targets(worldX: number, worldY: number, range: number) {
    const candidates: Zombie[] = [];
    for (let y = Math.floor((worldY - range) / 24); y <= Math.floor((worldY + range) / 24); y++) {
      for (let x = Math.floor((worldX - range) / 24); x <= Math.floor((worldX + range) / 24); x++) {
        for (const zombie of this.nearby.get(x + y * 4096) ?? []) candidates.push(zombie);
      }
    }
    return candidates;
  }

  private range(soldier: Soldier) {
    return weapons[soldierTypes[soldier.type].weapon].range + soldier.roofHeight * 2;
  }

  private hasSight(origin: Point, height: number, target: Zombie, mask: number) {
    const end = this.terrain.cell(target.x, target.y);
    if (!height) return clearSight(this.terrain, this.terrain.cell(...origin), end, mask);
    // Leave the source roof before checking the street-level sightline.
    const dx = target.x - origin[0];
    const dy = target.y - origin[1];
    const samples = Math.max(1, Math.ceil(Math.hypot(dx, dy) / 0.3));
    for (let index = 0; index <= samples; index++) {
      const cell = this.terrain.cell(origin[0] + dx * index / samples, origin[1] + dy * index / samples);
      if (this.terrain.open(cell, mask)) return clearSight(this.terrain, cell, end, mask);
    }
    return false;
  }

  private fire(soldier: Soldier, elapsed: number, mask: number, candidates: Zombie[]) {
    if (soldier.reloadUntil || soldier.nextShot > elapsed) return;
    const weapon = weapons[soldierTypes[soldier.type].weapon];
    const origin = this.terrain.cell(soldier.x, soldier.y);
    let target: Zombie | undefined;
    const maxRange = this.range(soldier);
    let range = maxRange ** 2;
    for (const zombie of candidates) {
      const distance = (zombie.x - soldier.x) ** 2 + (zombie.y - soldier.y) ** 2;
      if (distance >= range || !this.hasSight([soldier.x, soldier.y], soldier.roofHeight, zombie, mask)) continue;
      target = zombie;
      range = distance;
    }
    if (!target) return;
    const angle = Math.atan2(target.y - soldier.y, target.x - soldier.x);
    const turn = Math.atan2(Math.sin(angle - soldier.heading), Math.cos(angle - soldier.heading));
    if (Math.abs(turn) > 0.16) {
      soldier.heading += Math.max(-0.72, Math.min(0.72, turn));
      soldier.speed = 0;
      soldier.aimUntil = elapsed + 0.17;
      return;
    }
    soldier.heading = angle;
    soldier.speed = 0;
    soldier.aimUntil = elapsed + 0.22;
    const roll = random(soldier.seed ^ Math.imul(++soldier.roundsFired, 0x85ebca6b));
    const hits = roll < shotAccuracy(Math.sqrt(range), maxRange);
    const offset = hits ? 0 : (roll < 0.8 ? -1 : 1) * (1.4 + Math.sqrt(range) * 0.09);
    const to: Point = [target.x - Math.sin(angle) * offset, target.y + Math.cos(angle) * offset];
    // Clip a missed tracer at the first blocked patch of ground.
    if (!hits && !soldier.roofHeight) {
      const dx = to[0] - soldier.x;
      const dy = to[1] - soldier.y;
      const samples = Math.max(1, Math.ceil(Math.hypot(dx, dy) / 0.6));
      let previous = origin;
      for (let i = 1; i <= samples; i++) {
        const cell = this.terrain.cell(soldier.x + dx * i / samples, soldier.y + dy * i / samples);
        if (!this.terrain.touches(previous, cell, mask)) {
          to[0] = soldier.x + dx * (i - 1) / samples;
          to[1] = soldier.y + dy * (i - 1) / samples;
          break;
        }
        previous = cell;
      }
    }
    const muzzleReach = soldier.type === 'medic' ? 0.37 : 0.63;
    const muzzle: Point = [soldier.x + Math.cos(angle) * muzzleReach, soldier.y + Math.sin(angle) * muzzleReach];
    const shot = { from: muzzle, to, start: elapsed, until: elapsed + 0.15 };
    this.shots.push(shot);
    if (hits) this.impacts.push({ shot, target, damage: weapon.damage, at: elapsed + 0.075, origin: [soldier.x, soldier.y], roofHeight: soldier.roofHeight });
    soldier.ammo--;
    soldier.nextShot = elapsed + weapon.interval;
    if (!soldier.ammo) soldier.reloadUntil = elapsed + weapon.reload;
  }

  private checkContact(soldier: Soldier, elapsed: number, mask: number, candidates: Zombie[]) {
    if (soldier.nextWound > elapsed) return;
    const cell = this.terrain.cell(soldier.x, soldier.y);
    const grabbed = candidates.some(zombie => !zombie.attack && (zombie.x - soldier.x) ** 2 + (zombie.y - soldier.y) ** 2 <= 0.9 ** 2
      && this.terrain.touches(cell, this.terrain.cell(zombie.x, zombie.y), mask)
      && (this.fortifications?.allows(this.terrain.cell(zombie.x, zombie.y), cell, false) ?? true));
    if (!grabbed) return;
    soldier.health--;
    soldier.nextWound = elapsed + 0.85;
    if (!soldier.health) soldier.state = 'lost';
  }

  depart() {
    if (this.phase === 'departed') return;
    for (const soldier of this.active) soldier.state = 'lost';
    this.shots.length = 0;
    this.impacts.length = 0;
    this.phase = 'departed';
  }
}
