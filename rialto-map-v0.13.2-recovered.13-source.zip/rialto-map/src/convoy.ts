import { Clearance, type ClearanceSector } from './clearance.ts';
import { barricadeCost, type Barricade } from './fortifications.ts';
import { cellSize, steps, type CrowdField } from './crowd-field.ts';
import { civilianProfiles } from './civilian-profiles.ts';
import { Outbreak, type OutbreakRules } from './outbreak.ts';
import type { CrossingId, Point, Route, StreetGraph } from './routing.ts';
import { random, scatterCells, spawnNear, splitPopulation, type SpawnLayout } from './spawn-planning.ts';
import { clearSight, type RoutePlan } from './pursuit.ts';
import { aimRunner, moveRunner, runnerTargetOpen, type TurnCurve } from './runner-motion.ts';
import { Defense, soldierTypes, type Deployment, type Soldier } from './defense.ts';

export const helicopterArrivalSeconds = 18;
export const civilianBoardingSeconds = 12;

export type Airlift = {
  point: Point;
  opensAt: number;
  closesAt: number;
  capacity: number;
  boarded: number;
  sectors: Map<number, number>;
  departed: boolean;
  aborted: boolean;
};

export type ConvoyStatus = 'ready' | 'moving' | 'holding' | 'arrived' | 'finished';

export interface Civilian {
  x: number;
  y: number;
  heading: number;
  targetHeading?: number;
  travel: number;
  status: Exclude<ConvoyStatus, 'finished'> | 'caught' | 'infected' | 'sheltered' | 'lost';
  cell: number;
  target: number;
  targetX: number;
  targetY: number;
  vx: number;
  vy: number;
  pace: number;
  profile: number;
  speed: number;
  release: number;
  pauseUntil: number;
  nextPause: number;
  random: number;
  stepsTaken: number;
  escape?: RoutePlan;
  checkEscapeAt?: number;
  resumeAt?: number;
  panicUntil?: number;
  glanceAt?: number;
  curve?: TurnCurve;
  companion?: Civilian;
  following?: Civilian;
  socialPause?: boolean;
  sector: number;
  stranded?: boolean;
  injured?: boolean;
  stumbled?: boolean;
  escorted?: boolean;
  escort?: Soldier;
}

export interface SpawnPlan {
  barricades?: Barricade[];
  gateLockdown?: boolean;
  soldiers?: Deployment[];
  hired?: number;
  roundSeconds?: number;
  zoneRadius?: number;
  civilians?: SpawnLayout;
  zombies?: SpawnLayout;
  zombieCount?: number;
  rescueGroups?: boolean;
  clearanceSectors?: readonly ClearanceSector[];
}

export class EvacuationGroup {
  readonly people: Civilian[];
  readonly initialPopulation: number;
  elapsed = 0;
  liveBarricadeSpend = 0;
  evacuated = 0;
  waiting = 0;
  assisted = 0;
  treated = 0;
  readonly evacuatedSectors = new Map<number, number>();
  private nextSupport = 0;
  private readonly patients: Civilian[] = [];
  private readonly treatments = new Map<Soldier, { civilian?: Civilian; soldier?: Soldier }>();
  private readonly rescueTargets = new Map<Soldier, Civilian>();
  civilianAboard = 0;
  readonly aircraft: Airlift[] = [];
  private nextCrowdScan = 0;
  private readonly crowdGroups = new Map<number, Civilian[]>();

  get landingPads() { return this.aircraft.map(flight => flight.point); }
  get boardingOpen() { return this.aircraft.some(flight => this.canBoard(flight)); }
  private boardingRoutes: Map<number, number>[] = [];
  private readonly gateQueues = new Map<number, number>();
  private nextQueueScan = 0;
  shelterLosses = 0;
  stranded = 0;
  status: ConvoyStatus = 'ready';
  routes: Route[];
  readonly outbreak?: Outbreak;
  readonly defense?: Defense;
  readonly clearance?: Clearance;
  private readonly terrain: CrowdField;
  private readonly graph: StreetGraph;
  private readonly starts: number[];
  private readonly end: number;
  private readonly goal: number;
  private readonly baseSpeed: number;
  private readonly baseline: Uint16Array;
  private flow: Uint16Array;
  private barricadeFlow?: Uint16Array;
  private alternate?: Uint16Array;
  private alternateMask = 0;
  private mask: number;
  private readonly occupancy: Uint16Array | Map<number, number>;

  constructor(terrain: CrowdField, graph: StreetGraph, start: number, end: number, closed: ReadonlySet<CrossingId>, count: number, speed: number, seed = Math.floor(Math.random() * 0x100000000), outbreak?: OutbreakRules, spawns?: SpawnPlan) {
    this.terrain = terrain;
    this.occupancy = count >= 2048 ? new Uint16Array(terrain.cells.length) : new Map();
    this.graph = graph;
    this.starts = Array.isArray(spawns?.civilians)
      ? spawns.civilians.flatMap(point => {
        const node = graph.nearest(point);
        return node === undefined ? [] : [node];
      })
      : spawns?.civilians === 'random' ? [] : [start];
    this.end = end;
    this.baseSpeed = speed;
    this.goal = terrain.nearest(graph.nodes[end]);
    this.baseline = terrain.openFlow(this.goal);
    this.mask = terrain.mask(closed);
    this.flow = this.evacuationFlow();
    this.people = this.spawn(count, seed, graph.nodes[start], spawns?.civilians);
    if (outbreak) {
      this.linkFamilies();
      if (spawns?.rescueGroups) this.prepareRescueGroups();
    }
    this.routes = this.planRoutes(closed);
    if (outbreak) {
      if (spawns?.clearanceSectors) this.clearance = new Clearance(spawns.clearanceSectors);
      this.outbreak = new Outbreak(terrain, outbreak, this.baseline, spawns?.zombies, spawns?.zombieCount, this.mask, seed);
      if (spawns?.soldiers) {
        this.defense = new Defense(terrain, this.goal, outbreak.duration, spawns.soldiers, spawns.hired, spawns.zoneRadius, seed, spawns.barricades, spawns.gateLockdown, !!this.clearance);
        this.defense.preparePerimeter(this.baseline);
        this.refreshBarricadeFlow();
      }
    }
    this.clearance?.update(this.outbreak?.zombies ?? [], [], 0);
    this.initialPopulation = this.people.length + (this.outbreak?.zombies.length ?? 0);
  }

  private spawn(count: number, runSeed: number, start: Point, layout?: SpawnLayout): Civilian[] {
    let cells: number[];
    const sectors: number[] = [];
    if (layout === 'random') {
      cells = scatterCells(this.terrain, this.baseline, this.mask, count, runSeed);
    } else if (layout) {
      const allocation = splitPopulation(count, layout.length);
      const used = new Set<number>();
      const nearby = new Uint16Array(this.terrain.cells.length);
      cells = layout.flatMap((point, index) => {
        const size = allocation[index];
        const radius = size <= 12 ? 23 : Math.min(295, 27 + Math.sqrt(size) * 1.55);
        const group = spawnNear(this.terrain, this.baseline, this.mask, point, size, radius, runSeed + index, used, nearby);
        for (const _ of group) sectors.push(index);
        return group;
      });
    } else {
      cells = this.defaultSpawnCells(start, count, runSeed);
    }
    const profiles = civilianProfiles.flatMap((profile, index) => Array<number>(profile.spawnWeight).fill(index));
    for (let index = profiles.length - 1; index > 0; index--) {
      const pick = Math.floor(random(runSeed ^ Math.imul(index, 0x27d4eb2d)) * (index + 1));
      [profiles[index], profiles[pick]] = [profiles[pick], profiles[index]];
    }
    return cells.map((cell, index) => {
      const seed = Math.imul(index + 1, 0x9e3779b1) ^ runSeed;
      const x = this.terrain.x(cell);
      const y = this.terrain.y(cell);
      const heading = random(seed + 1) * Math.PI * 2;
      const profile = profiles[index % profiles.length];
      const pace = (0.6 + (random(seed ^ 0x42872e13) + random(seed ^ 0x16f371bb)) * 0.41) * civilianProfiles[profile].pace;
      this.occupy(cell, 1);
      return {
        x, y, heading, travel: 0, status: 'ready', cell, target: -1, targetX: x, targetY: y,
        vx: 0, vy: 0, pace, profile, speed: speedAtRest,
        release: index ? random(seed + 3) * 2.15 : 0,
        pauseUntil: 0, nextPause: 5 + random(seed + 4) * 19,
        random: seed, stepsTaken: 0, sector: sectors[index] ?? 0,
      };
    });
  }

  private crowdKey(x: number, y: number) {
    return Math.floor(x / 5) + Math.floor(y / 5) * this.terrain.columns;
  }

  private linkFamilies() {
    const adults = new Map<number, Civilian[]>();
    for (const person of this.people) {
      if (person.profile > 1) continue;
      const key = this.crowdKey(person.x, person.y);
      const group = adults.get(key);
      if (group) group.push(person);
      else adults.set(key, [person]);
    }
    for (const person of this.people) {
      if (person.profile !== 2 && person.profile !== 3) continue;
      const key = this.crowdKey(person.x, person.y);
      let nearest: Civilian | undefined;
      let best = 6 ** 2;
      for (let row = -1; row <= 1; row++) {
        for (let col = -1; col <= 1; col++) {
          const nearby = adults.get(key + row * this.terrain.columns + col) ?? [];
          for (const adult of nearby.slice(0, 24)) {
            const distance = (adult.x - person.x) ** 2 + (adult.y - person.y) ** 2;
            if (adult.companion || distance >= best || Math.abs(this.baseline[adult.cell] - this.baseline[person.cell]) > 12) continue;
            nearest = adult;
            best = distance;
          }
        }
      }
      if (nearest) {
        person.companion = nearest;
        nearest.companion = person;
      }
    }
  }

  private updateCrowd() {
    if (this.elapsed < this.nextCrowdScan) return;
    this.nextCrowdScan = this.elapsed + 0.65;
    this.crowdGroups.clear();
    for (const person of this.people) {
      if (person.status !== 'moving') continue;
      const key = this.crowdKey(person.x, person.y);
      const group = this.crowdGroups.get(key);
      if (group) group.push(person);
      else this.crowdGroups.set(key, [person]);
    }
    const field = this.barricadeFlow ?? this.flow;
    for (const person of this.people) {
      if (person.status !== 'moving') continue;
      person.following = undefined;
      const companion = person.companion;
      person.socialPause = companion?.status === 'moving' && field[companion.cell] > field[person.cell]
        && field[companion.cell] - field[person.cell] < 14 && Math.hypot(companion.x - person.x, companion.y - person.y) > 2.8;
      if (companion?.status === 'moving' || (person.panicUntil ?? 0) > this.elapsed) continue;
      const key = this.crowdKey(person.x, person.y);
      if ((this.crowdGroups.get(key)?.length ?? 0) > 2) continue;
      let best = 8 ** 2;
      for (let row = -1; row <= 1; row++) {
        for (let col = -1; col <= 1; col++) {
          const group = this.crowdGroups.get(key + row * this.terrain.columns + col);
          if (!group || group.length < 3) continue;
          for (const leader of group.slice(0, 5)) {
            const distance = (leader.x - person.x) ** 2 + (leader.y - person.y) ** 2;
            const ahead = field[person.cell] - field[leader.cell];
            if (distance >= best || ahead <= 0 || ahead > 16) continue;
            person.following = leader;
            best = distance;
          }
        }
      }
    }
  }

  private defaultSpawnCells([x, y]: Point, count: number, runSeed: number) {
    const origin = this.terrain.nearest([x, y], 0, this.baseline, 32);
    if (origin < 0) return [];
    const candidates = [origin];
    const radius = count <= 12 ? 23 : Math.min(295, 27 + Math.sqrt(count) * 1.55);
    this.terrain.visitArea(x, y, radius, (cell, distance) => {
      if (cell === origin || this.baseline[cell] < 2) return;
      if (count <= 12 && (distance < 9 || Math.abs(this.baseline[cell] - this.baseline[origin]) > 85)) return;
      candidates.push(cell);
    });
    return Array.from({ length: count }, (_, index) => {
      const seed = Math.imul(index + 1, 0x9e3779b1) ^ runSeed;
      const slot = index % candidates.length;
      const pick = slot + Math.floor(random(seed) * (candidates.length - slot));
      [candidates[slot], candidates[pick]] = [candidates[pick], candidates[slot]];
      return candidates[slot];
    });
  }

  private occupy(cell: number, amount: number) {
    if (this.occupancy instanceof Uint16Array) {
      this.occupancy[cell] += amount;
      return;
    }
    const count = (this.occupancy.get(cell) ?? 0) + amount;
    if (count) this.occupancy.set(cell, count);
    else this.occupancy.delete(cell);
  }

  private load(cell: number) {
    return this.occupancy instanceof Uint16Array ? this.occupancy[cell] : (this.occupancy.get(cell) ?? 0);
  }

  private planRoutes(closed: ReadonlySet<CrossingId>) {
    return this.people.length ? this.starts.flatMap(start => this.graph.route(start, this.end, closed) ?? []) : [];
  }

  get route() { return this.routes[0] ?? null; }

  get canDispatch() {
    if (this.clearance) return !!this.defense && !!this.outbreak?.zombies.length;
    return this.people.length > 0 && (this.routes.length > 0 || this.outbreak !== undefined
      || this.people.some(person => this.flow[person.cell] > 0));
  }

  trails(): Point[][] {
    return this.routes.map(route => route.nodes.map(node => this.graph.nodes[node]));
  }

  dispatch() {
    if (this.status === 'ready' && this.canDispatch) {
      this.defense?.start(this.mask, this.barricadeFlow ?? this.flow, this.baseline);
      this.status = 'moving';
    }
  }

  private evacuationFlow() {
    if (!this.mask) return this.baseline;
    if (!this.alternate || this.alternateMask !== this.mask) {
      this.alternate = this.terrain.flow(this.goal, this.mask, this.alternate);
      this.alternateMask = this.mask;
    }
    return this.alternate;
  }

  replan(closed: ReadonlySet<CrossingId>) {
    this.mask = this.terrain.mask(closed);
    this.flow = this.evacuationFlow();
    this.refreshBarricadeFlow();
    this.routes = this.planRoutes(closed);
    this.outbreak?.gatesChanged(this.mask);
    this.defense?.replan(this.mask, this.barricadeFlow ?? this.flow);
    if (this.aircraft.length) this.buildBoardingRoutes();
    if (this.status === 'ready' || this.status === 'arrived' || this.status === 'finished') return;
    this.stranded = 0;
    let continuing = false;
    for (const person of this.people) {
      if (person.status === 'arrived' || person.status === 'infected' || person.status === 'caught' || person.status === 'sheltered' || person.status === 'lost') continue;
      person.escape = undefined;
      person.checkEscapeAt = undefined;
      person.resumeAt = undefined;
      const actual = this.terrain.cell(person.x, person.y);
      if (!this.flow[actual]) this.stranded++;
      if (person.target >= 0 && person.target !== person.cell
        && this.terrain.open(actual, this.mask) && !runnerTargetOpen(person, this.terrain, this.mask)) {
        this.occupy(person.target, -1);
        aimRunner(person, this.terrain, person.cell, this.mask);
      }
      if (person.status === 'holding' && !person.stranded) person.status = 'moving';
      continuing = true;
    }
    if (continuing) this.status = 'moving';
  }

  private chooseTarget(person: Civilian) {
    const { cell } = person;
    // A runner already inside a closing gate may finish that crossing.
    const mask = this.terrain.open(cell, this.mask) ? this.mask : 0;
    const flow = this.barricadeFlow ?? (mask && this.flow[cell] ? this.flow : this.baseline);
    const distance = flow[cell];
    if (distance <= 1) return -1;
    const planned = this.outbreak?.escapeStep(person, this.elapsed, mask, flow) ?? -1;
    if (planned >= 0 && this.civilianPasses(cell, planned)) return planned;
    if (planned >= 0) person.escape = undefined;
    const separation = this.outbreak?.separation(cell) ?? 23;
    const threatened = separation < 23;
    const preference = Math.floor(random(person.random) * steps.length);
    const [biasX, biasY] = steps[preference];
    const maySidestep = this.load(cell) > 1 && distance > 0;
    const jam = this.load(cell) >= 3;
    const jammedForward = jam && steps.some(([dx, dy], direction) => {
      const next = cell + dy * this.terrain.columns + dx;
      return flow[next] > 0 && flow[next] < distance && this.load(next) >= 4
        && this.terrain.canStep(cell, direction, mask) && this.civilianPasses(cell, next);
    });
    const forwardX = person.vx * 0.5 + Math.cos(person.heading) * 0.5;
    const forwardY = person.vy * 0.5 + Math.sin(person.heading) * 0.5;
    const escort = person.escort?.rescue?.escort && person.escort.state === 'patrol' ? person.escort : undefined;
    const companion = escort ?? (person.companion?.status === 'moving' ? person.companion : person.following);
    const cohesion = !threatened && companion ? Math.hypot(companion.x - person.x, companion.y - person.y) : 0;
    let best = -Infinity;
    let target = -1;
    for (let direction = 0; direction < steps.length; direction++) {
      const [dx, dy] = steps[direction];
      const next = cell + dy * this.terrain.columns + dx;
      const progress = distance - flow[next];
      const space = threatened ? this.outbreak!.separation(next) : 23;
      const escape = threatened ? space - separation : 0;
      if (!flow[next] || (progress < 0 && escape <= 0 && !(jammedForward && progress === -1 && this.load(next) <= 1)) || (!progress && !maySidestep && escape <= 0)
        || (space <= 4 && escape < 0)
        || !this.terrain.canStep(cell, direction, mask) || !this.civilianPasses(cell, next)) continue;
      const diagonal = dx && dy ? Math.SQRT1_2 : 1;
      const ahead = (dx * forwardX + dy * forwardY) * diagonal;
      const drift = (dx * biasX + dy * biasY) * diagonal;
      const occupied = Math.min(5, this.load(next));
      // Keep the exit draining when a queue has nowhere else to go.
      const crowdCost = flow[next] === 1 ? 0 : occupied * (jammedForward ? 1.75 : 1.22) + Math.max(0, occupied - 1) * 1.1;
      const jitter = random(person.random + next) * 0.16;
      const following = cohesion > 1.6 && cohesion < 8
        ? (cohesion - Math.hypot(companion!.x - this.terrain.x(next), companion!.y - this.terrain.y(next))) * 1.65 : 0;
      const score = progress * 1.42 + ahead * 1.7 + drift * 0.28 - crowdCost + jitter + following
        + escape * (separation <= 13 ? 2.4 : 0.9) - Math.max(0, 10 - space) * 0.45;
      if (score <= best) continue;
      best = score;
      target = next;
    }
    return target;
  }

  placeLiveBarricade(span: Barricade, credits: number) {
    const cost = barricadeCost(span);
    if ((this.status !== 'moving' && this.status !== 'holding') || credits < cost
      || this.defense?.phase === 'departed' || !this.defense?.fortifications?.add(span)) return false;
    this.liveBarricadeSpend += cost;
    this.barricadeChanged();
    return true;
  }

  deployReinforcement(deployment: Deployment, credits: number) {
    if (this.status !== 'moving' && this.status !== 'holding') return false;
    if (this.clearance) return false;
    return this.defense?.reinforce(deployment, this.mask, this.elapsed, credits) ?? false;
  }

  orderPatrol(indices: Iterable<number>, point: Point) {
    return this.defense?.orderPatrol(indices, point, this.mask);
  }

  private prepareRescueGroups() {
    const groups = new Map<number, Civilian[]>();
    for (const person of this.people) {
      const group = groups.get(person.sector);
      if (group) group.push(person);
      else groups.set(person.sector, [person]);
    }
    for (const group of groups.values()) {
      const anchor = group[0];
      const nearby = group.filter(person => Math.hypot(person.x - anchor.x, person.y - anchor.y) <= 10);
      const size = Math.max(1, Math.ceil(nearby.length * 0.6));
      for (const [index, person] of nearby.slice(0, size).entries()) {
        person.stranded = true;
        if (index % 3 === 0) {
          person.injured = true;
          this.patients.push(person);
        }
      }
    }
  }

  get rescueMarkers() {
    const groups = new Map<number, { point: Point; count: number; injured: number }>();
    for (const person of this.people) {
      if (!person.stranded || (person.status !== 'ready' && person.status !== 'holding')) continue;
      const group = groups.get(person.sector);
      if (group) {
        group.count++;
        if (person.injured) group.injured++;
      } else groups.set(person.sector, { point: [person.x, person.y], count: 1, injured: person.injured ? 1 : 0 });
    }
    return [...groups.values()];
  }

  orderRescue(indices: Iterable<number>, point: Point, radius = 16, returnAfterRescue = false) {
    let distance = radius;
    let target: Civilian | undefined;
    for (const person of this.people) {
      if (!this.isTreatable(person) && !(person.status === 'ready' && person.stranded)) continue;
      if (person.status === 'sheltered') continue;
      const meters = Math.hypot(person.x - point[0], person.y - point[1]);
      if (meters >= distance) continue;
      distance = meters;
      target = person;
    }
    if (!target || !this.defense) return undefined;
    const selected = [...indices];
    const result = this.defense.orderPatrol(selected, [target.x, target.y], this.mask, true, returnAfterRescue);
    for (const index of selected) {
      const soldier = this.defense.soldiers[index];
      if (soldier?.rescue) this.rescueTargets.set(soldier, target);
    }
    return result;
  }

  private canAssist(a: { x: number; y: number }, b: { x: number; y: number }, radius: number) {
    if ((a.x - b.x) ** 2 + (a.y - b.y) ** 2 > radius ** 2) return false;
    const start = this.terrain.cell(a.x, a.y);
    const end = this.terrain.cell(b.x, b.y);
    if (!clearSight(this.terrain, start, end, this.mask)) return false;
    const meters = Math.hypot(a.x - b.x, a.y - b.y);
    const samples = Math.ceil(meters / (cellSize / 3));
    let previous = start;
    for (let i = 1; i <= samples; i++) {
      const cell = this.terrain.cell(a.x + (b.x - a.x) * i / samples, a.y + (b.y - a.y) * i / samples);
      if (!this.civilianPasses(previous, cell)) return false;
      previous = cell;
    }
    return true;
  }

  private supportCivilians() {
    if (!this.defense || this.elapsed < this.nextSupport) return;
    this.nextSupport = this.elapsed + 0.35;
    const troops = this.defense.active;
    for (const [medic, target] of this.treatments) {
      if (this.elapsed < medic.treatingUntil) continue;
      this.treatments.delete(medic);
      const { civilian, soldier } = target;
      if (medic.state === 'lost' || medic.state === 'aboard') continue;
      if (civilian?.injured && this.isTreatable(civilian) && this.canAssist(medic, civilian, 2.4)) civilian.injured = false;
      else if (soldier && soldier.state !== 'lost' && soldier.state !== 'aboard'
        && soldier.health < soldierTypes[soldier.type].health && this.canAssist(medic, soldier, 2.4)) soldier.health++;
      else continue;
      medic.supplies--;
      this.treated++;
    }
    const field = this.barricadeFlow ?? this.flow;
    for (const soldier of troops) {
      if (soldier.roofHeight || soldier.state !== 'patrol') continue;
      if (soldier.type === 'medic' && soldier.supplies && !this.treatments.has(soldier)
        && this.outbreak!.separation(soldier.cell) > 5) {
        const civilian = this.patients.find(person => person.injured && this.isTreatable(person) && this.canAssist(soldier, person, 2.1));
        const wounded = civilian ? undefined : troops.find(unit => !unit.roofHeight && unit.health < soldierTypes[unit.type].health
          && this.canAssist(soldier, unit, 2.1));
        if (civilian || wounded) {
          soldier.treatingUntil = this.elapsed + 1.1;
          if (civilian) civilian.pauseUntil = Math.max(civilian.pauseUntil, soldier.treatingUntil + 0.35);
          this.treatments.set(soldier, { civilian, soldier: wounded });
        }
      }
      if (!soldier.rescue || soldier.rescue.escort || this.treatments.has(soldier)) continue;
      const target = this.rescueTargets.get(soldier);
      if (target?.status === 'moving' && !target.escorted && this.terrain.open(target.cell, this.mask)
        && (target.x - this.terrain.x(soldier.rescue.cell)) ** 2 + (target.y - this.terrain.y(soldier.rescue.cell)) ** 2 > 8 ** 2) {
        this.defense.orderPatrol([this.defense.soldiers.indexOf(soldier)], [target.x, target.y], this.mask, true, soldier.returnPatrol !== undefined);
      }
      if ((soldier.x - this.terrain.x(soldier.rescue.cell)) ** 2 + (soldier.y - this.terrain.y(soldier.rescue.cell)) ** 2 > 3 ** 2) continue;
      if (!field[soldier.cell]) continue;
      let reached = false;
      for (const person of this.people) {
        if ((person.status !== 'holding' && person.status !== 'moving') || (person.escort?.rescue?.escort && person.escort.state === 'patrol') || !field[person.cell] || !this.canAssist(soldier, person, 10)) continue;
        if (!person.escorted) this.assisted++;
        person.escorted = true;
        if (!person.escort?.rescue?.escort || person.escort.state !== 'patrol') person.escort = soldier;
        person.stranded = false;
        person.status = 'moving';
        person.pauseUntil = 0;
        reached = true;
      }
      if (reached) {
        soldier.rescue.escort = true;
        soldier.path = [];
        soldier.pathIndex = 0;
      }
    }
  }

  private isTreatable(person: Civilian) {
    return person.status === 'holding' || person.status === 'moving' || person.status === 'sheltered';
  }

  private refreshBarricadeFlow() {
    const forts = this.defense?.fortifications;
    if (!forts?.gates.some(gate => gate.integrity > 0)) {
      this.barricadeFlow = undefined;
      return;
    }
    this.barricadeFlow = this.terrain.flow(this.goal, this.mask, this.barricadeFlow,
      (from, to) => forts.allows(from, to, false), cell => forts.insidePickup(cell, this.goal));
  }

  barricadeChanged() {
    this.refreshBarricadeFlow();
    this.defense?.replan(this.mask, this.barricadeFlow ?? this.flow);
    if (this.aircraft.length) this.buildBoardingRoutes();
  }

  private civilianPasses(cell: number, target: number) {
    return this.defense?.fortifications?.allows(cell, target, false, true) ?? true;
  }

  private advance(person: Civilian, seconds: number) {
    if (person.target >= 0 && this.terrain.cell(person.x, person.y) === person.cell
      && !this.civilianPasses(person.cell, person.target)) {
      this.occupy(person.target, -1);
      aimRunner(person, this.terrain, person.cell, this.mask);
      person.escape = undefined;
    }
    const panic = (person.panicUntil ?? 0) > this.elapsed;
    if (panic) {
      person.pauseUntil = 0;
      if (!person.stumbled && !person.injured && this.outbreak!.separation(person.cell) < 4 && random(person.random ^ 0x17ad) < 0.14) {
        person.injured = true;
        person.stumbled = true;
        this.patients.push(person);
      }
    }
    if (person.pauseUntil > this.elapsed) return;
    const density = Math.max(1, this.load(person.cell), person.target < 0 ? 0 : this.load(person.target));
    const space = 1 / (1 + Math.min(7, density - 1) * 0.19);
    const groupPace = (!panic && person.socialPause ? 0.64 : 1) * (person.injured ? 0.57 : 1);
    const targetSpeed = this.baseSpeed * person.pace * this.terrain.paceFactor(person.cell) * space * groupPace;
    person.speed = Math.max(person.speed - seconds * 5, Math.min(targetSpeed, person.speed + seconds * 3.4));
    let remaining = seconds * person.speed;
    while (remaining > 0.0001) {
      if (person.target < 0) {
        if ((this.barricadeFlow ?? this.flow)[person.cell] === 1) {
          if (this.defense) {
            person.status = this.defense.overrun ? 'lost' : 'sheltered';
            if (person.status === 'lost') {
              this.occupy(person.cell, -1);
              this.shelterLosses++;
            } else this.waiting++;
            person.speed = 0;
          } else {
            this.occupy(person.cell, -1);
            person.status = 'arrived';
            this.evacuated++;
          }
          return;
        }
        if (!panic && this.elapsed >= person.nextPause && this.flow[person.cell]) {
          const hesitation = random(person.random + person.stepsTaken);
          person.pauseUntil = this.elapsed + 0.15 + hesitation * 0.28;
          person.nextPause = this.elapsed + 9 + hesitation * 18;
          person.speed *= 0.45;
          return;
        }
        const target = this.chooseTarget(person);
        if (target < 0) {
          person.status = 'holding';
          person.speed = speedAtRest;
          person.resumeAt = this.elapsed + 0.45;
          return;
        }
        const load = this.load(target);
        if (!panic && load >= 4 && this.flow[target] > 1 && load > this.load(person.cell)) {
          person.pauseUntil = this.elapsed + 0.12 + random(person.random + person.stepsTaken) * 0.12;
          person.speed *= 0.55;
          return;
        }
        aimRunner(person, this.terrain, target, this.mask);
        this.occupy(target, 1);
      }
      if (this.defense?.fortifications?.gates.length && person.curve) person.curve.length = 0;
      remaining -= moveRunner(person, remaining, 11);
      if (person.x !== person.targetX || person.y !== person.targetY) return;
      if (person.cell !== person.target) this.occupy(person.cell, -1);
      person.cell = person.target;
      person.target = -1;
      person.stepsTaken++;
    }
  }

  tick(seconds: number) {
    if (seconds <= 0 || this.status === 'ready' || this.status === 'arrived' || this.status === 'finished') return;
    if (!this.outbreak) {
      this.step(seconds);
      return;
    }
    if (this.elapsed >= this.outbreak.duration - 0.0001) {
      this.depart();
      this.elapsed += seconds;
      this.outbreak.advanceEncounters(this.elapsed);
      if (!this.outbreak.encounters.size) this.status = 'finished';
      return;
    }
    // Keep pursuit and collision sampling consistent when a browser frame runs long.
    let remaining = Math.min(seconds, this.outbreak.duration - this.elapsed);
    while (remaining > 0.0001) {
      const dt = Math.min(remaining, 0.055);
      this.step(dt);
      if ((this.status as ConvoyStatus) === 'finished') return;
      remaining -= dt;
    }
    if (this.elapsed >= this.outbreak.duration - 0.0001) {
      this.depart();
      if (!this.outbreak.encounters.size) this.status = 'finished';
    }
  }

  get gateQueueCounts() { return this.gateQueues; }

  private prepareBoarding() {
    if (this.aircraft.length || this.defense?.overrun) return;
    const field = this.barricadeFlow ?? this.flow;
    const cells = [this.goal];
    for (const offset of [-1, 1, 2, -2]) {
      const cell = this.terrain.nearest([this.terrain.x(this.goal) + offset * 4, this.terrain.y(this.goal) + (offset === 2 ? 3 : 0)], this.mask, field, 3);
      if (field[cell] !== 1 || cells.some(other => Math.hypot(this.terrain.x(other) - this.terrain.x(cell), this.terrain.y(other) - this.terrain.y(cell)) < 2.2)) continue;
      cells.push(cell);
      if (cells.length === 3) break;
    }
    const duration = this.outbreak!.duration;
    const capacity = Math.max(8, Math.ceil(this.people.length * 0.72 / Math.max(2, cells.length)));
    const add = (cell: number, opensAt: number, closesAt: number) => this.aircraft.push({
      point: [this.terrain.x(cell), this.terrain.y(cell)], opensAt, closesAt, capacity,
      boarded: 0, sectors: new Map(), departed: false, aborted: false,
    });
    add(cells[1] ?? cells[0], duration - civilianBoardingSeconds, duration - 6);
    add(cells[0], duration - 6, duration);
    if (cells[2] !== undefined) add(cells[2], duration - 6, duration);
    this.buildBoardingRoutes();
  }

  private buildBoardingRoutes() {
    const field = this.barricadeFlow ?? this.flow;
    this.boardingRoutes = this.aircraft.map(({ point }) => {
      const pad = this.terrain.cell(...point);
      const route = new Map<number, number>();
      if (!this.terrain.open(pad, this.mask) || field[pad] !== 1) return route;
      route.set(pad, pad);
      const queue = [pad];
      for (let index = 0; index < queue.length; index++) {
        const cell = queue[index];
        for (const [direction, [dx, dy]] of steps.entries()) {
          const next = cell + dy * this.terrain.columns + dx;
          if (field[next] !== 1 || route.has(next) || !this.terrain.canStep(cell, direction, this.mask)
            || !this.civilianPasses(next, cell)) continue;
          route.set(next, cell);
          queue.push(next);
        }
      }
      return route;
    });
  }

  private sampleGateQueues() {
    if (this.elapsed < this.nextQueueScan) return;
    this.nextQueueScan = this.elapsed + 0.5;
    const gates = this.defense?.fortifications?.gates;
    if (!gates?.length) return;
    this.gateQueues.clear();
    for (const [index, gate] of gates.entries()) {
      if (!gate.locked) continue;
      const [[x, y], [endX, endY]] = gate.span;
      const dx = endX - x, dy = endY - y;
      const side = Math.sign(dx * (this.terrain.y(gate.post) - y) - dy * (this.terrain.x(gate.post) - x))
        || Math.sign(dx * (this.defense!.center[1] - y) - dy * (this.defense!.center[0] - x)) || 1;
      let count = 0;
      for (const person of this.people) {
        if (person.status !== 'holding' && person.status !== 'moving') continue;
        if ((person.x - gate.position[0]) ** 2 + (person.y - gate.position[1]) ** 2 > 8 ** 2) continue;
        if ((dx * (person.y - y) - dy * (person.x - x)) * side < 0) count++;
      }
      this.gateQueues.set(index, count);
    }
  }

  private canBoard(flight: Airlift) {
    return !flight.departed && !flight.aborted && flight.boarded < flight.capacity
      && this.elapsed >= flight.opensAt && this.elapsed < flight.closesAt;
  }

  private updateAircraft() {
    for (const flight of this.aircraft) {
      if (flight.departed || flight.aborted) continue;
      if (this.defense?.overrun && !flight.boarded) flight.aborted = true;
      else if (this.defense?.overrun || this.elapsed >= flight.closesAt - 0.0001) {
        flight.departed = true;
        this.evacuated += flight.boarded;
        for (const [sector, count] of flight.sectors) this.evacuatedSectors.set(sector, (this.evacuatedSectors.get(sector) ?? 0) + count);
      }
    }
  }

  private depart() {
    if (!this.defense || this.defense.phase === 'departed') return;
    this.defense.depart();
    this.updateAircraft();
  }

  private shiftSheltered(person: Civilian, seconds: number) {
    const boarding = this.boardingOpen;
    if (person.target >= 0 && this.terrain.cell(person.x, person.y) === person.cell
      && !this.civilianPasses(person.cell, person.target)) {
      this.occupy(person.target, -1);
      aimRunner(person, this.terrain, person.cell, this.mask);
    }
    if (boarding && person.target < 0) {
      const first = (person.random >>> 0) % Math.max(1, this.boardingRoutes.length);
      let next: number | undefined;
      let flight: Airlift | undefined;
      for (let index = 0; index < this.boardingRoutes.length; index++) {
        const slot = (first + index) % this.boardingRoutes.length;
        const candidate = this.aircraft[slot];
        if (!this.canBoard(candidate)) continue;
        const step = this.boardingRoutes[slot].get(person.cell);
        if (step === undefined || !this.civilianPasses(person.cell, step)) continue;
        flight = candidate;
        next = step;
        break;
      }
      if (flight && next === person.cell) {
        this.occupy(person.cell, -1);
        person.status = 'arrived';
        flight.boarded++;
        flight.sectors.set(person.sector, (flight.sectors.get(person.sector) ?? 0) + 1);
        this.civilianAboard++;
        this.waiting--;
        return;
      }
      if (next !== undefined) {
        aimRunner(person, this.terrain, next, this.mask);
        this.occupy(next, 1);
      }
    }
    if (person.target < 0) {
      if (this.elapsed < person.pauseUntil) return;
      person.pauseUntil = this.elapsed + 0.8 + random(person.random + person.stepsTaken) * 2;
      const field = this.barricadeFlow ?? this.flow;
      let best = -Infinity;
      let target = -1;
      for (const [direction, [dx, dy]] of steps.entries()) {
        const next = person.cell + dy * this.terrain.columns + dx;
        if (field[next] !== 1 || !this.terrain.canStep(person.cell, direction, this.mask) || !this.civilianPasses(person.cell, next)) continue;
        const safety = this.outbreak?.separation(next) ?? 23;
        const score = safety * 0.5 - this.load(next) * 1.8 + random(person.random ^ next ^ person.stepsTaken);
        if (score <= best) continue;
        best = score;
        target = next;
      }
      if (target < 0) return;
      aimRunner(person, this.terrain, target, this.mask);
      this.occupy(target, 1);
    }
    person.speed = (boarding ? 2.6 : 1.25) * (person.injured ? 0.65 : 1);
    if (this.defense?.fortifications?.gates.length && person.curve) person.curve.length = 0;
    moveRunner(person, person.speed * seconds, 8);
    if (person.x !== person.targetX || person.y !== person.targetY) return;
    this.occupy(person.cell, -1);
    person.cell = person.target;
    person.target = -1;
    person.stepsTaken++;
    person.speed = 0;
  }

  private step(seconds: number) {
    this.elapsed += seconds;
    if (!this.outbreak && this.status === 'holding') return;
    if (!this.clearance && this.defense && this.outbreak && this.elapsed >= this.outbreak.duration - helicopterArrivalSeconds) this.prepareBoarding();
    this.updateAircraft();
    const defenders = this.defense?.active.filter(soldier => !soldier.roofHeight).map(soldier => [soldier.x, soldier.y] as Point);
    this.outbreak?.sense(this.people, this.elapsed, this.mask, this.flow, defenders);
    if (this.outbreak) this.updateCrowd();
    this.supportCivilians();
    let moving = false;
    for (const person of this.people) {
      if (person.status === 'ready') {
        const time = this.elapsed - person.release;
        if (time > 0) person.status = person.stranded ? 'holding' : 'moving';
        else moving = true;
      }
      if (person.status === 'holding' && person.stranded && (person.panicUntil ?? 0) > this.elapsed) person.stranded = false;
      if (person.status === 'holding' && !person.stranded && ((person.panicUntil ?? 0) > this.elapsed
        || (this.outbreak && (this.barricadeFlow ?? this.flow)[person.cell] && this.elapsed >= (person.resumeAt ?? 0)))) person.status = 'moving';
      if (person.status === 'sheltered') {
        this.shiftSheltered(person, seconds);
        continue;
      }
      if (person.status !== 'moving') continue;
      this.advance(person, Math.min(seconds, this.elapsed - person.release));
      moving ||= person.status === 'moving';
    }
    this.outbreak?.tick(this.people, this.elapsed, seconds, this.mask, this.baseline, this.flow, person => {
      if (person.target >= 0 && person.target !== person.cell) this.occupy(person.target, -1);
      this.occupy(person.cell, -1);
      if (person.status === 'sheltered') this.waiting--;
      person.status = 'caught';
    }, this.defense?.fortifications);
    if (this.defense && this.outbreak) {
      const previousLocks = this.defense.fortifications?.gates.map(gate => `${gate.locked}:${gate.open}:${gate.integrity <= 0}`).join();
      const wasOverrun = this.defense.overrun;
      this.defense.tick(this.elapsed, seconds, this.mask, this.outbreak);
      if (previousLocks !== undefined && previousLocks !== this.defense.fortifications?.gates.map(gate => `${gate.locked}:${gate.open}:${gate.integrity <= 0}`).join()) this.barricadeChanged();
      this.sampleGateQueues();
      if (this.clearance) {
        this.clearance.update(this.outbreak.zombies, this.defense.soldiers, seconds);
        if (this.clearance.secured === this.clearance.sectors.length || this.defense.active.length === 0
          || this.elapsed >= this.outbreak.duration - 0.0001) {
          this.status = 'finished';
          return;
        }
      }
      if (!wasOverrun && this.defense.overrun) {
        this.updateAircraft();
        for (const person of this.people) {
          if (person.status !== 'sheltered') continue;
          if (person.target >= 0 && person.target !== person.cell) this.occupy(person.target, -1);
          this.occupy(person.cell, -1);
          person.status = 'lost';
          this.waiting--;
          this.shelterLosses++;
        }
      }
    }
    if (!this.defense && this.outbreak && !this.outbreak.encounters.size && this.evacuated + this.outbreak.infected === this.people.length) this.status = 'finished';
    else if (!this.defense && this.evacuated === this.people.length) this.status = 'arrived';
    else if (this.defense) this.status = 'moving';
    else if (!moving && !this.outbreak?.encounters.size) this.status = 'holding';
    else this.status = 'moving';
  }
}

const speedAtRest = 0.45;
