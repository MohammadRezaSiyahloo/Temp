export function soundSiren(context: AudioContext) {
  const time = context.currentTime;
  const gain = context.createGain();
  const filter = context.createBiquadFilter();
  const oscillator = context.createOscillator();
  oscillator.type = 'triangle';
  filter.frequency.value = 950;
  gain.gain.setValueAtTime(0.001, time);
  gain.gain.exponentialRampToValueAtTime(0.055, time + 0.25);
  gain.gain.exponentialRampToValueAtTime(0.001, time + 2.7);
  oscillator.frequency.setValueAtTime(350, time);
  oscillator.frequency.linearRampToValueAtTime(740, time + 1);
  oscillator.frequency.linearRampToValueAtTime(370, time + 2.7);
  oscillator.connect(filter).connect(gain).connect(context.destination);
  oscillator.onended = () => {
    oscillator.disconnect();
    filter.disconnect();
    gain.disconnect();
  };
  oscillator.start(time);
  oscillator.stop(time + 2.8);
}
