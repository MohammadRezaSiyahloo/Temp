# Rialto

A browser outbreak and evacuation prototype set in Venice. Guide civilians out of Rialto as infected runners spread through the district.

## Play

Open `play.html` from the source archive in a browser. The map and fonts are bundled in the file. The bottom command bar stays available in the browser window and fullscreen. Open **Bridges** to close or reopen crossings, **Deploy** to place troops or barricades, **Setup** to change the scenario before dispatch, or **Report** for the mission objective and results.

**Rialto outbreak** starts with 24 civilians and eight infected near the market. Dispatch the civilians to start the extraction clock. The infected immediately pursue nearby civilians on reachable ground at up to 4.75 m/s on flat streets. When two infected spot the same runner, one can keep chasing while the other flanks and tries to intercept them farther along the route. Civilians look ahead for infected, take detours when they can, and backtrack when the way ahead is too dangerous. Close or reopen a bridge to change the routes available to both groups. By default, the starting zombie count scales at roughly one per four civilians, with a minimum of eight and enough to fill the configured spawn points. Set a manual count under **Setup → Starting zombies**, or select **Use auto** to restore scaling.

Runners slow and yield when an alley or bridge approach fills. They carry their momentum through turns where there is room. Nearby survivors can pick up on the panic and glance around as they react. Infected chasing a specific survivor can check a nearby opening after losing sight of them.

Each starting infected has a 2% chance of being a mutant, rising to 8% in **Rialto after dark**. Mutants are larger and slower, and have seven health instead of two. The infected use shoulder bites, arm grabs, and tackles. Caught civilians fall, stay down for about three seconds, and rise before they can join the chase. The results count civilians evacuated, infected, and left behind.

Choose **Evacuation drill** for the original civilian-only route from Rialto Market to Piazza San Marco.

In **Rialto outbreak**, use **Deploy** to recruit SWAT infantry. The scenario starts with four hired troops and a budget based on civilian and starting infected counts. **Hire max** spends the remaining credits on infantry. Each deployment pin places one soldier, and unassigned troops start at extraction. Open **Setup** to set population, spawn points, round length, or extraction radius before dispatch.

Infantry stop and face visible infected before firing. Use **Draw barricade** under **Deploy** and click both sides of a street to buy a gate and concrete barricade along that span. The preview shows the price. Before dispatch, **Undo barricade** refunds the most recent placement. Barricades and infantry share credits. All ground units use an open gate or go around the ends. Under maximum sustained infected pressure a full-strength barricade holds for about 24 simulation seconds before collapsing into passable rubble. Ground troops roam freely from their deployment. During the defense phase, toggle **Patrol orders**, drag a box around troops, and click a walkable patrol point. Selected troops patrol within 8 m of that point until you redirect them or fallback begins. The overlay shows their paths and flags a barricade that blocks an assigned route. Infected can survive the first hit, and shots are less reliable at longer distances. Soldiers fall back to the transport before the round ends, with more time allowed for larger zones. Civilians wait for staggered helicopter pickups. The first wave leaves six seconds before the last, and each aircraft shows its remaining seats and boarding time. A sustained infected presence at the center overruns the pickup and kills the waiting group. Use the 1×, 2×, and 4× controls to change simulation speed.

The default outbreak leaves 1,600 credits after the four starting troops. Barricade previews flag nearby walkable space beyond either endpoint. Open **Map options** and toggle **Guard coverage** to see nearby troops and gate integrity. After extraction, open **Report** and use **Replay same outbreak** to reuse the starting seed and bridge settings and compare results.

Click a barricade's **Closed** or **Open** control to swing its steel gate. The opening admits ground units while the concrete wings still block them. A closed or locked gate blocks passage until opened or breached.
Enable **Lock gates under heavy zombie pressure** before dispatch. An intact gate locks when at least eight infected are spotted within 12 m on its outside approach. Civilians must wait or find another way. The lockdown lifts below five nearby infected. A locked gate reports nearby infected, civilians outside, and the nearest unlocked gate by straight-line distance. Helicopters arrive 18 seconds before departure. In the final 12 seconds, civilians at pickup move to available boarding points while soldiers cover them. Only boarded civilians count as evacuated when the aircraft lift off.

Choose **Sniper** under **Deployment unit** to upgrade a troop for 140 additional credits. Deploy on connected streets or on a roof with nearby street access. Roof elevations are estimated from building footprints and increase the sniper's range. Snipers hold their deployment until fallback.

Confirmed bullet hits leave directional spatters, and bite collapses leave larger dark pools at close zoom. Decals fade over time. At pickup, civilians spread out and shift away from nearby danger. Returning soldiers hold and defend the pickup until the last four seconds, when they can board.

Infantry and weapon definitions live in `src/defense.ts`. Deployments reference a unit type, and each unit type references a weapon definition.

- Drag to pan. Scroll or use the map controls to zoom out to the city and lagoon.
- Use **Street view** to zoom in on a runner or the pickup point. Use **Fit route in view** to see the full evacuation route.
- Use **Fullscreen map** to expand the map. Click the same button or press **Esc** to return.
- Click a crossing on the map or in the sidebar to close or reopen it.
- Toggle **Crowd density** in the map controls to highlight civilian clusters. Darker orange marks the most crowded areas.
- In **Spawn plan**, choose **Place** for civilians or zombies and click walkable ground for each point. The first custom point replaces the presets. Click a pin while placing to remove it, and choose **Done** to finish.
- The population is split as evenly as possible across the points, with extra individuals assigned to the earliest points. **Starting zombies** sets the total for the infected.
- Choose **Random** for either population to scatter individuals across walkable ground. Reset keeps the layout and creates a new run.
- Use **Set evacuation** to move the extraction point.
- Choose a **Crowd size** from 12 to 20,000. Larger crowds start over a wider area around the pickup.
- Press **Dispatch group** to release the civilians. They react at different times, move around buildings and other runners, and count as evacuated on arrival. Civilians cut off from the exit wait for an open route.
- Use the route icon in the map controls to fit the active route in view.

The scenario is a single-player exercise. Civilians have individually assigned running speeds and distinct adult, child, and older-adult models. About two-thirds of the crowd is adult men and women, with the remaining third split between children and older adults. They accelerate from rest and slow on mapped stairs and bridge approaches. Travel time depends on each person’s route and pace.

## Develop

Use Node.js 22.18 or newer.

```sh
npm ci
npm run dev
npm test
npm run build
```

`npm run build:offline` generates a self-contained file at `offline/index.html`.

React handles the controls. PixiJS renders the map and animated civilians, with a Canvas fallback. Both renderers share the character frames in `src/civilians.ts`. The street graph provides the planning preview. Civilians use a shared navigation field across open ground with building, canal, and gate collision. Each runner steers locally, and PixiJS batches the visible characters from one sprite sheet. Scenario settings live in `data/rialto-outbreak.json` and `data/rialto-scenario.json`.

In runs with 6,000 or more agents, a slow render frame can advance at most 55 ms of simulation. This keeps the map responsive under load and can make the extraction clock run slower than real time.

## Map data

© [OpenStreetMap contributors](https://www.openstreetmap.org/copyright). The bundled data is derived from OpenStreetMap and is available under the [Open Database License](https://opendatacommons.org/licenses/odbl/1-0/). Surrounding geometry comes from [OpenFreeMap](https://openfreemap.org/) and [OpenMapTiles](https://openmaptiles.org/). Map credits appear below the game.

`data/venice.json` bundles the projected geometry and pedestrian graph for the playable district. To regenerate it, download OpenStreetMap XML for longitude 12.3195–12.3435 and latitude 45.428–45.447 in smaller bounding boxes. Use west-to-east tiles of 0.008 degrees and latitude boundaries 45.428, 45.433, 45.438, 45.443 and 45.447. Include [way 1526861508 with its nodes](https://api.openstreetmap.org/api/0.6/way/1526861508/full) to complete the Bacino San Marco polygon. Run the importer with the extracts in west-to-east, south-to-north order.

```sh
python3 scripts/import_osm.py data/venice.json extracts/*.xml
```

`data/venice-overview.json` contains surrounding terrain. To regenerate it, save the OpenFreeMap vector tiles at zoom 14 for x 8751–8755 and y 5863–5867 as `x-y.pbf`. The [TileJSON endpoint](https://tiles.openfreemap.org/planet/latest) supplies the tile URL template.

```sh
node scripts/import_overview.mjs tiles data/venice.json data/venice-overview.json
```

The scenario is fictional and controls three named Grand Canal crossings inside the playable district.

During an outbreak, red and blue emergency lights reflect on the canals, while rotor wash kicks up dust and loose paper at the pickup. Use **Emergency sirens** in the map controls to enable sound. In the crowd, nearby adults and children may pair up, isolated civilians can follow groups, and runners can peel away from a jam.

### Live operations

After dispatch, open **Deploy**, choose an illustrated unit card, and click a connected street. Snipers can also use rooftops with street access. Infantry costs 100 credits, a medic costs 180, and a sniper costs 240. Reinforcements close during final boarding. Use **Draw barricade** to place a gate during the round. Both purchases draw from the same remaining budget. Use the same **Deploy** menu in fullscreen.

### Rescue and medical support

After dispatch, choose **Rescue orders** from the command bar, drag a box around ground troops, and click a civilian group. Troops try to reach the group and escort nearby civilians toward the pickup. Stranded groups in the Venice scenarios are marked on the map. A rescue order pulls troops away from their current patrol.

Choose **Field medic** from the **Deploy** menu before placing a soldier. It costs 80 credits to upgrade an infantry slot. A medic has a short-range pistol for self-defense and carries five treatments and automatically helps reachable injured civilians and wounded troops when there is room to stop. Injured civilians and wounded troops move more slowly until treated.

### Venice missions

- **Rialto after dark** asks you to evacuate half the night market crowd, including a stranded group you can rescue.
- **Reopen Rialto** starts with the bridge closed. Reopen it before the first helicopter departs and evacuate at least one civilian.
- **Both banks of the Grand Canal** asks you to evacuate at least one civilian from each bank. The objective panel tracks each bank separately.

### District Clearance and squads

Select **District Clearance** in **Setup**. Your eight-person squad has six minutes to clear Rialto Market, Campo San Polo, and San Marco in any order. Infected remain assigned to their starting sector even if they leave its boundary. Once a sector is clear, keep a ground unit inside the marked area for eight uninterrupted seconds. Relief then takes over and the squad can move on.

During a round, select ground troops and open **Squads** to save or recall up to three groups. With the game focused, **Shift+1–3** saves a selection and **1–3** recalls it. In evacuation missions, enable **Resume previous patrol after rescue** before giving a rescue order. The squad resumes its patrol after reaching pickup.
