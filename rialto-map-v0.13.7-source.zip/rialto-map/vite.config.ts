import { defineConfig } from 'vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

export default defineConfig(({ mode }) => ({
  base: './',
  plugins: mode === 'offline' ? [viteSingleFile()] : [],
  build: {
    assetsInlineLimit: mode === 'offline' ? 100_000 : 4096,
  },
}));
