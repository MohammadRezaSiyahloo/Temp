"""Convert OpenStreetMap XML extracts for central Venice into renderer and routing data."""
import argparse
import json
from collections import defaultdict
from pathlib import Path
from xml.etree import ElementTree

WEST, SOUTH, EAST, NORTH = 12.3195, 45.428, 12.3435, 45.447
LON_METERS, LAT_METERS = 78200, 111130
WIDTH = round((EAST - WEST) * LON_METERS)
HEIGHT = round((NORTH - SOUTH) * LAT_METERS)
BRIDGES = {
    "Ponte di Rialto": "rialto",
    "Ponte degli Scalzi": "scalzi",
    "Ponte dell'Accademia": "accademia",
}
WALKABLE = {"pedestrian", "footway", "steps", "path", "residential", "service", "living_street"}
DISTRICTS = [
    ("Santa Croce", 12.3248, 45.4394),
    ("San Polo", 12.3299, 45.4377),
    ("Cannaregio", 12.3298, 45.4416),
    ("Castello", 12.3425, 45.4384),
    ("San Marco", 12.3364, 45.4344),
    ("Dorsoduro", 12.3242, 45.4332),
]
LANDMARKS = [
    ("Mercato di Rialto", 12.33387, 45.43902),
    ("Campo San Polo", 12.33025, 45.43724),
    ("Piazza San Marco", 12.3376, 45.43403),
    ("Campo Santa Margherita", 12.32325, 45.43412),
    ("Santa Maria della Salute", 12.3345, 45.4309),
    ("La Fenice", 12.3339, 45.4338),
]

def tags(element):
    return {tag.get("k"): tag.get("v") for tag in element.findall("tag")}


def project(lon, lat):
    return [round((lon - WEST) * LON_METERS, 1), round((NORTH - lat) * LAT_METERS, 1)]


def in_bounds(point):
    return 0 <= point[0] <= WIDTH and 0 <= point[1] <= HEIGHT


def visible(points):
    xs, ys = zip(*points)
    return min(xs) <= WIDTH and max(xs) >= 0 and min(ys) <= HEIGHT and max(ys) >= 0


def join_rings(parts):
    remaining = [part[:] for part in parts if len(part) >= 2]
    rings = []
    while remaining:
        ring = remaining.pop()
        while ring[0] != ring[-1]:
            for index, part in enumerate(remaining):
                if ring[-1] == part[0]:
                    ring.extend(part[1:])
                elif ring[-1] == part[-1]:
                    ring.extend(part[-2::-1])
                elif ring[0] == part[-1]:
                    ring = part[:-1] + ring
                elif ring[0] == part[0]:
                    ring = part[:0:-1] + ring
                else:
                    continue
                remaining.pop(index)
                break
            else:
                break
        if len(ring) >= 4 and ring[0] == ring[-1]:
            rings.append(ring)
    return rings


def parse(paths):
    nodes, ways, relations = {}, {}, {}
    for path in paths:
        for _, element in ElementTree.iterparse(path, events=("end",)):
            kind, identifier = element.tag, element.get("id")
            if kind == "node":
                nodes[identifier] = project(float(element.get("lon")), float(element.get("lat")))
            elif kind == "way":
                ways[identifier] = ([nd.get("ref") for nd in element.findall("nd")], tags(element))
            elif kind == "relation":
                relations[identifier] = (
                    [(m.get("type"), m.get("ref"), m.get("role")) for m in element.findall("member")],
                    tags(element),
                )
            else:
                continue
            element.clear()
    return nodes, ways, relations


def build(paths):
    nodes, ways, relations = parse(paths)
    water, parks, buildings, plazas, streets, bridge_lines, bridge_decks, stairs = [], [], [], [], [], [], [], []
    bridge_points = defaultdict(list)
    graph_nodes, edges, edge_keys = {}, [], set()

    def points(refs):
        if all(ref in nodes for ref in refs):
            return [nodes[ref] for ref in refs]
        return []

    for refs, t in ways.values():
        shape = points(refs)
        if len(shape) < 2 or not visible(shape):
            continue
        closed = len(refs) >= 4 and refs[0] == refs[-1]
        building = t.get("building") not in (None, "no")
        if closed:
            if t.get("natural") == "water" or t.get("waterway") == "riverbank":
                water.append(shape)
            elif t.get("building") == "bridge":
                bridge_decks.append(shape)
            elif building:
                buildings.append(shape)
            elif t.get("leisure") in {"park", "garden"} or t.get("landuse") in {"grass", "forest"}:
                parks.append(shape)
            elif t.get("highway") == "pedestrian" and t.get("area") == "yes":
                plazas.append(shape)

        if t.get("highway") not in WALKABLE or t.get("area") == "yes" or building:
            continue
        if t.get("indoor") == "yes" or t.get("foot") in {"no", "private"}:
            continue
        if t.get("access") in {"no", "private"} and t.get("foot") not in {"yes", "designated"}:
            continue
        if t.get("highway") == "steps":
            stairs.append(shape)
        is_bridge = t.get("bridge") not in (None, "no")
        bridge = BRIDGES.get(t.get("name")) if is_bridge else None
        if is_bridge:
            bridge_lines.append(shape)
        else:
            streets.append(shape)
        if bridge:
            bridge_points[bridge].extend(shape)
        for a, b in zip(refs, refs[1:]):
            if a == b or not in_bounds(nodes[a]) or not in_bounds(nodes[b]):
                continue
            key = (*sorted((a, b)), bridge)
            if key in edge_keys:
                continue
            edge_keys.add(key)
            for ref in (a, b):
                if ref not in graph_nodes:
                    graph_nodes[ref] = len(graph_nodes)
            edge = [graph_nodes[a], graph_nodes[b]]
            edges.append(edge + [bridge] if bridge else edge)

    for members, t in relations.values():
        if t.get("type") != "multipolygon" or t.get("water") == "lagoon":
            continue
        if t.get("natural") == "water":
            layer = water
        elif t.get("building") not in (None, "no"):
            layer = buildings
        elif t.get("leisure") in {"park", "garden"}:
            layer = parks
        else:
            continue
        for ring in join_rings([ways[ref][0] for kind, ref, role in members
                                if kind == "way" and role in {"outer", ""} and ref in ways]):
            shape = points(ring)
            if shape and visible(shape):
                layer.append(shape)

    crossings = []
    for name, identifier in BRIDGES.items():
        samples = bridge_points[identifier]
        if not samples:
            raise ValueError(f"Missing crossing {name}")
        xs, ys = zip(*samples)
        position = [round((min(xs) + max(xs)) / 2, 1), round((min(ys) + max(ys)) / 2, 1)]
        crossings.append({"id": identifier, "name": name, "position": position})

    return {
        "size": [WIDTH, HEIGHT],
        "projection": {"origin": [WEST, NORTH], "metersPerDegree": [LON_METERS, LAT_METERS]},
        "terrain": {"water": water, "parks": parks, "buildings": buildings, "plazas": plazas,
                    "streets": streets, "bridges": bridge_lines, "bridgeDecks": bridge_decks, "stairs": stairs},
        "labels": {
            "districts": [[name, *project(lon, lat)] for name, lon, lat in DISTRICTS],
            "landmarks": [[name, *project(lon, lat)] for name, lon, lat in LANDMARKS],
        },
        "nodes": [nodes[ref] for ref in graph_nodes],
        "edges": edges,
        "crossings": crossings,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("extracts", type=Path, nargs="+")
    args = parser.parse_args()
    data = build(args.extracts)
    args.output.write_text(json.dumps(data, separators=(",", ":"), ensure_ascii=False) + "\n", encoding="utf-8")
