import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { gunzipSync } from 'node:zlib';
import { VectorTile } from '@mapbox/vector-tile';
import { PbfReader } from 'pbf';
import polygonClipping from 'polygon-clipping';

const [tileDirectory, corePath, outputPath] = process.argv.slice(2);
if (!tileDirectory || !corePath || !outputPath) {
  console.error('Usage: node scripts/import_overview.mjs <tiles-directory> <venice.json> <output.json>');
  process.exit(1);
}

const core = JSON.parse(readFileSync(corePath, 'utf8'));
const { origin, metersPerDegree } = core.projection;
const [coreWidth, coreHeight] = core.size;
const zoom = 14;
const places = new Set(['Giudecca', 'Murano', 'Lido', 'Sant’Elena', "Sant'Elena", 'Tronchetto', 'San Michele', 'Sacca Fisola']);
const overview = { bounds: [], water: [], parks: [], buildings: [], streets: [], bridges: [], labels: [] };
const waterTiles = [];
const labels = new Set();
const bounds = [Infinity, Infinity, -Infinity, -Infinity];

function project([lon, lat]) {
  return [
    Math.round((lon - origin[0]) * metersPerDegree[0]),
    Math.round((origin[1] - lat) * metersPerDegree[1]),
  ];
}

function tileCorner(x, y) {
  const n = 2 ** zoom;
  return project([x / n * 360 - 180, Math.atan(Math.sinh(Math.PI * (1 - 2 * y / n))) * 180 / Math.PI]);
}

function convertLine(line) {
  const points = [];
  for (const coordinate of line) {
    const point = project(coordinate);
    const last = points.at(-1);
    if (!last || last[0] !== point[0] || last[1] !== point[1]) points.push(point);
  }
  return points;
}

function outsideCore(points) {
  return points.some(([x, y]) => x <= 0 || y <= 0 || x >= coreWidth || y >= coreHeight);
}

for (const file of readdirSync(tileDirectory).sort()) {
  const match = /^(\d+)-(\d+)\.pbf$/.exec(file);
  if (!match) continue;
  const x = Number(match[1]);
  const y = Number(match[2]);
  let bytes = readFileSync(join(tileDirectory, file));
  if (bytes[0] === 0x1f && bytes[1] === 0x8b) bytes = gunzipSync(bytes);
  const tile = new VectorTile(new PbfReader(bytes));
  const [left, top] = tileCorner(x, y);
  const [right, bottom] = tileCorner(x + 1, y + 1);
  bounds[0] = Math.min(left, bounds[0]);
  bounds[1] = Math.min(top, bounds[1]);
  bounds[2] = Math.max(right, bounds[2]);
  bounds[3] = Math.max(bottom, bounds[3]);
  const water = [];

  for (const layerName of ['water', 'landcover', 'landuse', 'building', 'transportation', 'place']) {
    const layer = tile.layers[layerName];
    if (!layer) continue;
    for (let i = 0; i < layer.length; i++) {
      const feature = layer.feature(i);
      const properties = feature.properties;
      if (layerName === 'place' && !places.has(properties.name)) continue;
      if (layerName === 'landcover' && !['grass', 'wood', 'wetland'].includes(properties.class)) continue;
      if (layerName === 'landuse' && !['park', 'cemetery', 'recreation_ground'].includes(properties.class)) continue;
      if (layerName === 'transportation' && (properties.brunnel === 'tunnel' || properties.class === 'ferry')) continue;
      const { geometry } = feature.toGeoJSON(x, y, zoom);
      if (!geometry) continue;
      if (geometry.type === 'Point' && layerName === 'place' && !labels.has(properties.name)) {
        overview.labels.push([properties.name, ...project(geometry.coordinates)]);
        labels.add(properties.name);
      }
      if (geometry.type === 'LineString' || geometry.type === 'MultiLineString') {
        const lines = geometry.type === 'LineString' ? [geometry.coordinates] : geometry.coordinates;
        const layer = properties.brunnel === 'bridge' ? overview.bridges : overview.streets;
        for (const line of lines.map(convertLine)) {
          if (line.length >= 2 && outsideCore(line)) layer.push(line);
        }
      }
      if (geometry.type === 'Polygon' || geometry.type === 'MultiPolygon') {
        const polygons = geometry.type === 'Polygon' ? [geometry.coordinates] : geometry.coordinates;
        for (const polygon of polygons) {
          const [outer, ...holes] = polygon.map(convertLine);
          if (outer.length < 4) continue;
          if (layerName === 'water') {
            water.push([outer, ...holes.filter(ring => ring.length >= 4)]);
          } else if (outsideCore(outer)) {
            (layerName === 'building' ? overview.buildings : overview.parks).push(outer);
          }
        }
      }
    }
  }
  if (water.length) waterTiles.push(polygonClipping.union(...water));
}

if (!waterTiles.length) throw new Error('No water geometry found in the supplied tiles.');
overview.bounds = bounds;
const [left, top, right, bottom] = bounds;
const chart = [[[left, top], [right, top], [right, bottom], [left, bottom], [left, top]]];
overview.water = polygonClipping.intersection(polygonClipping.union(...waterTiles), chart)
  .map(polygon => polygon.map(ring => ring.map(point => point.map(value => Math.round(value * 10) / 10))));
writeFileSync(outputPath, JSON.stringify(overview) + '\n');
