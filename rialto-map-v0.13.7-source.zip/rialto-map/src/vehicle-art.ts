const groundArt = {
  jeep: new URL('./assets/hmmwv.webp', import.meta.url).href,
  carrier: new URL('./assets/stryker.webp', import.meta.url).href,
  tank: new URL('./assets/abrams.webp', import.meta.url).href,
};

export const aircraftArt = {
  strike: new URL('./assets/f16.webp', import.meta.url).href,
  gunRun: new URL('./assets/a10.webp', import.meta.url).href,
  helicopter: new URL('./assets/uh60.webp', import.meta.url).href,
};

const sprites: Partial<Record<keyof typeof groundArt, HTMLImageElement>> = {};
let loaded: Promise<void> | undefined;

export function loadVehicleArt() {
  return loaded ??= Promise.all(Object.entries(groundArt).map(([type, url]) => new Promise<void>(resolve => {
    const image = new Image();
    image.onload = () => { sprites[type as keyof typeof groundArt] = image; resolve(); };
    image.onerror = () => resolve();
    image.src = url;
  }))).then(() => {});
}

export function vehicleVisualScale(type: string) {
  return type === 'jeep' ? 1.8 : type === 'carrier' ? 2.1 : type === 'tank' ? 2.4 : 1;
}

export function drawVehicleArt(context: CanvasRenderingContext2D, heading: number, type: string) {
  const sprite = sprites[type as keyof typeof groundArt];
  if (!sprite) return false;
  const width = type === 'jeep' ? 3 : type === 'carrier' ? 3.65 : 4.2;
  const height = width * sprite.naturalHeight / sprite.naturalWidth;
  context.rotate(heading);
  context.beginPath();
  context.ellipse(-width * .04, .09, width * .44, height * .44, 0, 0, Math.PI * 2);
  context.fillStyle = '#15202088';
  context.fill();
  context.drawImage(sprite, -width / 2, -height / 2, width, height);
  return true;
}
