import type { CrossingId, Point, Venice } from './routing.ts';

// Cells cover walkable ground. Gate bits sit on top of that ground mask.
export const cellSize = 0.6;
const ground = 1;
const gates: Record<CrossingId, number> = { rialto: 2, scalzi: 4, accademia: 8 };
const bridge = gates.rialto | gates.scalzi | gates.accademia;
const stairs = 16;
const bridgeRadius = 2.25;
export const steps = [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1]] as const;

export class CrowdField {
  readonly columns: number;
  readonly parks: Venice['terrain']['parks'];
  readonly cells: Uint8Array;
  private readonly rows: number;
  private readonly queue: Uint32Array;
  private readonly walls: Uint8Array;
  private readonly connections: Uint8Array;
  private readonly nearbyGates: Uint8Array;
  private readonly offsets: number[];
  private baseline?: { goal: number; field: Uint16Array };

  constructor(data: Venice, overviewWater: Point[][][]) {
    this.columns = Math.ceil(data.size[0] / cellSize) + 2;
    this.rows = Math.ceil(data.size[1] / cellSize) + 2;
    this.cells = new Uint8Array(this.columns * this.rows);
    this.walls = new Uint8Array(this.cells.length);
    this.offsets = steps.map(([dx, dy]) => dy * this.columns + dx);
    const terrain = data.terrain;
    this.parks = terrain.parks;
    this.polygon([[0, 0], [data.size[0], 0], data.size, [0, data.size[1]]], true);
    for (const [water, ...islands] of overviewWater) {
      this.polygon(water, false);
      for (const island of islands) this.polygon(island, true);
    }
    for (const canal of terrain.water) this.polygon(canal, false);
    for (const deck of terrain.bridgeDecks) this.polygon(deck, true);
    for (const bridge of terrain.bridges) this.line(bridge, bridgeRadius, ground);
    for (const building of terrain.buildings) {
      this.polygon(building, false);
      this.line(building, 0.13, 0);
      this.markWalls(building);
    }
    for (const [a, b, crossing] of data.edges) {
      if (crossing) this.line([data.nodes[a], data.nodes[b]], 3.8, gates[crossing]);
    }
    for (const stair of terrain.stairs) this.line(stair, 2.1, stairs);
    let walkable = 0;
    this.connections = new Uint8Array(this.cells.length);
    this.nearbyGates = new Uint8Array(this.cells.length);
    for (let cell = 0; cell < this.cells.length; cell++) {
      if (!this.open(cell)) continue;
      walkable++;
      const gate = this.cells[cell] & bridge;
      if (gate) for (const offset of this.offsets) this.nearbyGates[cell + offset] |= gate;
      let links = 0;
      for (let direction = 0; direction < steps.length; direction++) {
        if (!(this.walls[cell] & (1 << direction)) && this.stepGroundOpen(cell, direction, 0)) links |= 1 << direction;
      }
      this.connections[cell] = links;
    }
    this.queue = new Uint32Array(walkable);
  }

  mask(closed: ReadonlySet<CrossingId>) {
    let mask = 0;
    for (const crossing of closed) mask |= gates[crossing];
    return mask;
  }

  cell(x: number, y: number) {
    const column = Math.floor(x / cellSize) + 1;
    const row = Math.floor(y / cellSize) + 1;
    if (column < 1 || row < 1 || column >= this.columns - 1 || row >= this.rows - 1) return -1;
    return row * this.columns + column;
  }

  x(cell: number) {
    return (cell % this.columns - 0.5) * cellSize;
  }

  y(cell: number) {
    return (Math.floor(cell / this.columns) - 0.5) * cellSize;
  }

  open(cell: number, mask = 0) {
    return (this.cells[cell] & (ground | mask)) === ground;
  }

  paceFactor(cell: number) {
    const surface = this.cells[cell];
    return surface & stairs ? 0.76 : surface & bridge ? 0.91 : 1;
  }

  canStep(cell: number, direction: number, mask: number) {
    return (this.connections[cell] & (1 << direction)) !== 0
      && (!(this.nearbyGates[cell] & mask) || this.stepGroundOpen(cell, direction, mask));
  }

  private stepGroundOpen(cell: number, direction: number, mask: number) {
    const [dx, dy] = steps[direction];
    return this.open(cell + this.offsets[direction], mask)
      && (!dx || !dy || (this.open(cell + dx, mask) && this.open(cell + dy * this.columns, mask)));
  }

  hasTurnSpace(start: number, end: number, mask: number) {
    if (!this.open(start, mask) || !this.open(end, mask) || this.walls[start] || this.walls[end]) return false;
    const dx = end % this.columns - start % this.columns;
    if (!dx || end - start === dx) return true;
    const side = start + dx;
    const other = end - dx;
    return this.open(side, mask) && this.open(other, mask) && !this.walls[side] && !this.walls[other];
  }

  openFlow(goal: number) {
    if (this.baseline?.goal !== goal) this.baseline = { goal, field: this.flow(goal, 0) };
    return this.baseline.field;
  }

  localFlow(sources: Iterable<number>, mask: number, radius: number, result: Uint16Array) {
    result.fill(0);
    const queue = this.queue;
    let tail = 0;
    for (const source of sources) {
      if (result[source] || !this.open(source, mask)) continue;
      result[source] = 1;
      queue[tail++] = source;
    }
    for (let head = 0; head < tail; head++) {
      const cell = queue[head];
      if (result[cell] >= radius) continue;
      const checkGate = this.nearbyGates[cell] & mask;
      for (let links = this.connections[cell]; links; links &= links - 1) {
        const direction = 31 - Math.clz32(links & -links);
        const next = cell + this.offsets[direction];
        if (result[next] || (checkGate && !this.stepGroundOpen(cell, direction, mask))) continue;
        result[next] = result[cell] + 1;
        queue[tail++] = next;
      }
    }
  }

  touches(a: number, b: number, mask: number) {
    if (!this.open(a, mask) || !this.open(b, mask)) return false;
    if (a === b) return true;
    const dx = b % this.columns - a % this.columns;
    const dy = Math.floor(b / this.columns) - Math.floor(a / this.columns);
    if (Math.abs(dx) > 1 || Math.abs(dy) > 1) return false;
    const direction = dy < 0 ? dx + 1 : dy > 0 ? dx + 6 : dx < 0 ? 3 : 4;
    return this.canStep(a, direction, mask);
  }

  nearest([x, y]: Point, mask = 0, field?: Uint16Array, radius = 15) {
    const origin = this.cell(x, y);
    if (origin < 0) return -1;
    if (this.open(origin, mask) && (!field || field[origin])) return origin;
    let closest = -1;
    let best = radius * radius;
    this.visitArea(x, y, radius, (cell, metersSquared) => {
      if (metersSquared >= best || !this.open(cell, mask) || (field && !field[cell])) return;
      closest = cell;
      best = metersSquared;
    });
    return closest;
  }

  visitArea(x: number, y: number, radius: number, visit: (cell: number, metersSquared: number) => void) {
    const minX = Math.max(1, Math.floor((x - radius) / cellSize) + 1);
    const minY = Math.max(1, Math.floor((y - radius) / cellSize) + 1);
    const maxX = Math.min(this.columns - 2, Math.floor((x + radius) / cellSize) + 1);
    const maxY = Math.min(this.rows - 2, Math.floor((y + radius) / cellSize) + 1);
    for (let row = minY; row <= maxY; row++) {
      const dy = (row - 0.5) * cellSize - y;
      for (let col = minX; col <= maxX; col++) {
        const dx = (col - 0.5) * cellSize - x;
        const distance = dx * dx + dy * dy;
        if (distance <= radius * radius) visit(row * this.columns + col, distance);
      }
    }
  }

  flow(goal: number, mask: number, result: Uint16Array = new Uint16Array(this.cells.length),
    allows?: (from: number, to: number) => boolean, inPickup?: (cell: number) => boolean) {
    result.fill(0);
    if (!this.open(goal, mask)) return result;
    const queue = this.queue;
    queue[0] = goal;
    result[goal] = 1;
    let tail = 1;
    const goalX = this.x(goal);
    const goalY = this.y(goal);
    for (let head = 0; head < tail; head++) {
      const cell = queue[head];
      const checkGate = this.nearbyGates[cell] & mask;
      for (let links = this.connections[cell]; links; links &= links - 1) {
        const direction = 31 - Math.clz32(links & -links);
        const next = cell + this.offsets[direction];
        if (result[next] || (checkGate && !this.stepGroundOpen(cell, direction, mask)) || allows?.(next, cell) === false) continue;
        const x = this.x(next) - goalX;
        const y = this.y(next) - goalY;
        if (x * x + y * y > 36 || inPickup?.(next) === false) continue;
        result[next] = 1;
        queue[tail++] = next;
      }
    }
    for (let head = 0; head < tail; head++) {
      const cell = queue[head];
      const distance = result[cell] + 1;
      const checkGate = this.nearbyGates[cell] & mask;
      for (let links = this.connections[cell]; links; links &= links - 1) {
        const direction = 31 - Math.clz32(links & -links);
        const next = cell + this.offsets[direction];
        if (result[next] || (checkGate && !this.stepGroundOpen(cell, direction, mask)) || allows?.(next, cell) === false) continue;
        result[next] = distance;
        queue[tail++] = next;
      }
    }
    return result;
  }

  private markWalls(points: Point[]) {
    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
      const [ax, ay] = points[j];
      const [bx, by] = points[i];
      const sx = bx - ax;
      const sy = by - ay;
      if (!sx && !sy) continue;
      const minX = Math.max(1, Math.floor(Math.min(ax, bx) / cellSize));
      const maxX = Math.min(this.columns - 2, Math.ceil(Math.max(ax, bx) / cellSize) + 1);
      const minY = Math.max(1, Math.floor(Math.min(ay, by) / cellSize));
      const maxY = Math.min(this.rows - 2, Math.ceil(Math.max(ay, by) / cellSize) + 1);
      for (let row = minY; row <= maxY; row++) {
        const y = (row - 0.5) * cellSize - ay;
        for (let col = minX; col <= maxX; col++) {
          const cell = row * this.columns + col;
          if (!this.open(cell)) continue;
          const x = (col - 0.5) * cellSize - ax;
          for (let direction = 4; direction < steps.length; direction++) {
            const [dx, dy] = steps[direction];
            const next = cell + dy * this.columns + dx;
            if (!this.open(next)) continue;
            const vx = dx * cellSize;
            const vy = dy * cellSize;
            const det = vx * sy - vy * sx;
            if (!det) continue;
            const t = (y * sx - x * sy) / det;
            const u = (vx * y - vy * x) / det;
            if (t < 0 || t > 1 || u < 0 || u > 1) continue;
            this.walls[cell] |= 1 << direction;
            this.walls[next] |= 1 << (7 - direction);
          }
        }
      }
    }
  }

  private polygon(points: Point[], walkable: boolean) {
    let top = Infinity;
    let bottom = -Infinity;
    for (const [, y] of points) {
      top = Math.min(top, y);
      bottom = Math.max(bottom, y);
    }
    const first = Math.max(1, Math.ceil(top / cellSize + 0.5));
    const last = Math.min(this.rows - 2, Math.floor(bottom / cellSize + 0.5));
    const intersections: number[] = [];
    for (let row = first; row <= last; row++) {
      const y = (row - 0.5) * cellSize;
      intersections.length = 0;
      for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
        const [a, b] = [points[j], points[i]];
        if ((a[1] > y) !== (b[1] > y)) intersections.push(a[0] + (y - a[1]) / (b[1] - a[1]) * (b[0] - a[0]));
      }
      intersections.sort((a, b) => a - b);
      for (let i = 0; i + 1 < intersections.length; i += 2) {
        const left = Math.max(1, Math.ceil(intersections[i] / cellSize + 0.5));
        const right = Math.min(this.columns - 2, Math.floor(intersections[i + 1] / cellSize + 0.5));
        if (left <= right) this.cells.fill(walkable ? ground : 0, row * this.columns + left, row * this.columns + right + 1);
      }
    }
  }

  private line(points: Point[], radius: number, value: number) {
    const radiusSquared = radius * radius;
    for (let i = 1; i < points.length; i++) {
      const [x, y] = points[i - 1];
      const [ex, ey] = points[i];
      const dx = ex - x;
      const dy = ey - y;
      const lengthSquared = dx * dx + dy * dy || 1;
      const minX = Math.max(1, Math.ceil((Math.min(x, ex) - radius) / cellSize + 0.5));
      const maxX = Math.min(this.columns - 2, Math.floor((Math.max(x, ex) + radius) / cellSize + 0.5));
      const minY = Math.max(1, Math.ceil((Math.min(y, ey) - radius) / cellSize + 0.5));
      const maxY = Math.min(this.rows - 2, Math.floor((Math.max(y, ey) + radius) / cellSize + 0.5));
      for (let row = minY; row <= maxY; row++) {
        const py = (row - 0.5) * cellSize - y;
        for (let col = minX; col <= maxX; col++) {
          const px = (col - 0.5) * cellSize - x;
          const t = Math.max(0, Math.min(1, (px * dx + py * dy) / lengthSquared));
          const ox = px - t * dx;
          const oy = py - t * dy;
          if (ox * ox + oy * oy > radiusSquared) continue;
          const cell = row * this.columns + col;
          this.cells[cell] = value ? this.cells[cell] | value : 0;
        }
      }
    }
  }
}
