import { aircraftArt, vehicleVisualScale } from './vehicle-art.ts';
import { facingOffset } from './sprite-heading.ts';
import { escortFlight, supportDuration, supportImpact, supportTypes, type SupportRun, type SupportType } from './air-support.ts';
import type { GroundFire } from './ground-fire.ts';
import { useEffect, useId, useMemo, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { Application, Graphics, Particle, ParticleContainer, Rectangle, Sprite, Texture } from 'pixi.js';
import { drawAtlas, limitCamera, type Camera, type Overview } from './cartography.ts';
import {
  atlasFrameCount, civilianAnchor, civilianCell, civilianCellHeight, civilianFrame, civilianFrameOrigin,
  civilianPixelsPerMeter, civilianScale, drawCivilianAtlases, encounterFrame, framesPerAtlas, soldierFrame,
} from './civilians.ts';
import { soundImpact, soundSiren } from './siren.ts';
import { reliefSeconds, sectorRadius, type Clearance } from './clearance.ts';
import { Icon } from './icons.tsx';
import type { Airlift, EvacuationGroup } from './convoy.ts';
import type { CrossingId, Point, Venice } from './routing.ts';
import { barricadeCost, gateIntegrity, gateOpening, maxBarricadeLength, minBarricadeLength } from './fortifications.ts';
import type { Barricade, ZoneGate } from './fortifications.ts';
import { patrolRadius, vehicleWidth, type Defense, type Deployment, type Shot } from './defense.ts';

type SpawnMarker = { position: Point; count: number; removable: boolean };

type Props = {
  data: Venice;
  overview: Overview;
  closed: ReadonlySet<CrossingId>;
  selection: 'civilians' | 'zombies' | 'soldiers' | 'barricade' | 'end' | 'support' | null;
  deployments?: Deployment[];
  zoneRadius: number;
  gates?: readonly ZoneGate[];
  barricadeStart: Point | null;
  barricadeCredits: number;
  inspectGaps: (span: Barricade) => Point[];
  coverage?: { guards: number; integrity: number }[];
  canCommand: boolean;
  evacuatedPassengers: number;
  aircraft: readonly Airlift[];
  elapsed: number;
  defense?: Defense;
  clearance?: Clearance;
  supportRuns: readonly SupportRun[];
  supportStart: Point | null;
  supportType: SupportType;
  groundFires?: readonly GroundFire[];
  outbreakActive: boolean;
  night: boolean;
  rescueMarkers: EvacuationGroup['rescueMarkers'];
  gateQueues: ReadonlyMap<number, number>;
  defensePhase?: 'defend' | 'fallback' | 'departed';
  civilianSpawns: SpawnMarker[];
  zombieSpawns: SpawnMarker[];
  end: Point;
  onPlace: (point: Point) => void;
  onCancelPlacement: () => void;
  placementMessage?: string;
  onToggleGate: (index: number) => void;
  onCrossing: (id: CrossingId) => void;
  onRemoveSpawn: (kind: 'civilians' | 'zombies' | 'soldiers', index: number) => void;
  frame: (seconds: number) => EvacuationGroup;
  hud: ReactNode;
  commandBar: (orders: ReactNode) => ReactNode;
};

const project = ([x, y]: Point, camera: Camera): Point => [
  (x - camera.x) * camera.zoom + camera.width / 2,
  (y - camera.y) * camera.zoom + camera.height / 2,
];
const unproject = ([x, y]: Point, camera: Camera): Point => [
  (x - camera.width / 2) / camera.zoom + camera.x,
  (y - camera.height / 2) / camera.zoom + camera.y,
];

function bulletTrace(shot: Shot, elapsed: number, camera: Camera) {
  const age = elapsed - shot.start;
  const progress = Math.min(1, age / (shot.shell ? .24 : .075));
  const tail = Math.max(0, progress - (shot.shell ? .22 : .07));
  const [x, y] = project(shot.from, camera);
  const dx = (shot.to[0] - shot.from[0]) * camera.zoom;
  const dy = (shot.to[1] - shot.from[1]) * camera.zoom;
  return { x, y, headX: x + dx * progress, headY: y + dy * progress,
    tailX: x + dx * tail, tailY: y + dy * tail, flash: elapsed - shot.start < 0.032,
    angle: Math.atan2(dy, dx), flashSize: Math.max(1, Math.min(4, camera.zoom * 0.7)) * (shot.shell ? 2 : 1),
    shellImpact: shot.shell && age >= .24 ? age - .24 : undefined };
}

function BarricadeModel({ gate, camera, index }: { gate: ZoneGate; camera: Camera; index: number }) {
  const [[x, y], [endX, endY]] = gate.span.map(point => project(point, camera));
  const length = Math.hypot(endX - x, endY - y);
  const angle = Math.atan2(endY - y, endX - x) * 180 / Math.PI;
  const depth = Math.max(3.4, camera.zoom * 1.05);
  const opening = gateOpening(length / camera.zoom) * camera.zoom;
  const wing = (length - opening) / 2;
  const breached = gate.integrity <= 0;
  const seams = Math.floor(wing / Math.max(5, camera.zoom * 1.6));
  const fragments = Math.max(3, Math.min(28, Math.floor(length / Math.max(4, camera.zoom))));
  if (breached) return <g className="zone-gate breached" transform={`translate(${x} ${y}) rotate(${angle})`}>
    <title>Barricade {index + 1} collapsed · passage clear</title>
    {Array.from({ length: fragments }, (_, piece) => {
      const center = (piece + 0.5) * length / fragments;
      const shift = (piece % 2 ? -1 : 1) * depth * 1.15;
      const width = length / fragments * 0.68;
      return <rect key={piece} className="blockade-debris" x={center - width / 2} y={shift - depth / 3}
        width={width} height={depth * 0.6} transform={`rotate(${piece % 2 ? -28 : 33} ${center} ${shift})`} />;
    })}
  </g>;
  return <g className={`zone-gate ${breached ? 'breached' : ''}`} transform={`translate(${x} ${y}) rotate(${angle})`}>
    <title>Barricade {index + 1} · {Math.ceil(gate.integrity / gateIntegrity * 100)}%</title>
    <path className="blockade-shadow" d={`M0 2 H${wing} M${wing + opening} 2 H${length}`} strokeWidth={depth + 2} />
    {[0, wing + opening].map((offset, side) => <g key={side} transform={`translate(${offset} 0)`}>
      <rect className="blockade-concrete" y={-depth / 2} width={wing} height={depth} rx={0.8} />
      <path className="blockade-cap" d={`M0 ${-depth * 0.22} H${wing}`} strokeWidth={depth * 0.26} />
      {Array.from({ length: seams }, (_, panel) => {
        const joint = (panel + 1) * wing / (seams + 1);
        return <line key={panel} className="blockade-seam" x1={joint} x2={joint} y1={-depth / 2} y2={depth / 2} />;
      })}
    </g>)}
    <g transform={`translate(${wing} 0)`}>
      {[0, 1].map(side => {
        const half = opening / 2;
        const hinge = side * opening;
        const direction = side ? -1 : 1;
        return <g key={side} transform={`translate(${hinge} 0) rotate(${gate.open ? direction * 82 : 0}) scale(${direction} 1)`}>
          <rect className="blockade-door" y={-depth / 2} width={half} height={depth} rx={0.6} />
          <path className="blockade-brace" d={`M0 ${depth * 0.34} L${half} ${-depth * 0.34}`} />
          <path className="gate-reflector" d={`M${half * 0.65} 0 H${half * 0.91}`} />
        </g>;
      })}
      {[0, opening].map(post => <rect key={post} className="blockade-post" x={post - depth / 3}
        y={-depth * 0.72} width={depth * 0.66} height={depth * 1.44} rx={0.6} />)}
    </g>
  </g>;
}

function initialView(width: number, height: number): Camera {
  return {
    x: 1200,
    y: 995,
    zoom: Math.max(width / 680, height / 530),
    width,
    height,
  };
}

const runnerScale = civilianScale / civilianPixelsPerMeter;
const densityColors = [0xffbd65, 0xf17d39] as const;

function crowdDensity(group: EvacuationGroup) {
  const tiles = new Map<string, { x: number; y: number; count: number }>();
  for (const person of group.people) {
    if (person.status !== 'moving' && person.status !== 'holding' && person.status !== 'sheltered') continue;
    const key = `${Math.floor(person.x / 8)},${Math.floor(person.y / 8)}`;
    const tile = tiles.get(key);
    if (tile) tile.count++;
    else tiles.set(key, { x: person.x, y: person.y, count: 1 });
  }
  return Array.from(tiles.values()).filter(tile => tile.count >= 4);
}

const dotColors = [
  ['Civilian', '#ffe08a'], ['Infected', '#ff645c'], ['Mutant', '#ff8bfa'],
  ['Infantry', '#77e3a9'], ['Sniper', '#76c7ff'], ['Medic', '#ffffff'], ['Vehicle', '#d1b6ff'],
] as const;

function drawDotAtlas() {
  const canvas = document.createElement('canvas');
  canvas.width = dotColors.length * 12;
  canvas.height = 12;
  const context = canvas.getContext('2d')!;
  dotColors.forEach(([, color], index) => {
    context.beginPath();
    context.arc(index * 12 + 6, 6, index === 2 || index === 6 ? 4.6 : 3.7, 0, Math.PI * 2);
    context.fillStyle = color;
    context.fill();
    context.strokeStyle = '#192421';
    context.lineWidth = 1;
    context.stroke();
  });
  return canvas;
}

const markerSize = 24;

function drawInfectedMarkers() {
  const canvas = document.createElement('canvas');
  canvas.width = markerSize * 2;
  canvas.height = markerSize;
  const context = canvas.getContext('2d')!;
  for (const mutant of [false, true]) {
    const x = markerSize * (mutant ? 1.5 : .5);
    const y = markerSize / 2;
    context.beginPath();
    if (mutant) {
      context.moveTo(x, y - 7);
      context.lineTo(x + 10, y);
      context.lineTo(x, y + 7);
      context.lineTo(x - 10, y);
      context.closePath();
    } else {
      context.ellipse(x, y, 8, 4.8, 0, 0, Math.PI * 2);
    }
    context.fillStyle = '#251218d9';
    context.fill();
    context.strokeStyle = '#160e13';
    context.lineWidth = 5;
    context.stroke();
    context.strokeStyle = dotColors[mutant ? 2 : 1][1];
    context.lineWidth = 2.5;
    context.stroke();
  }
  return canvas;
}

function infectedMarkerSize(zoom: number) {
  return Math.max(12, Math.min(32, zoom * 2.4));
}

function forEachRunner(group: EvacuationGroup, camera: Camera, dots: boolean, draw: (x: number, y: number, frame: number, scale?: number, rotation?: number, infectedMarker?: number) => void) {
  const [left, top] = unproject([-20, -20], camera);
  const [right, bottom] = unproject([camera.width + 20, camera.height + 20], camera);
  for (const scene of group.outbreak?.encounters ?? []) {
    const { x, y } = scene.victim;
    if (x < left || x > right || y < top || y > bottom) continue;
    draw(x, y, dots ? 0 : encounterFrame(scene, group.elapsed));
  }
  for (let index = 0; index < group.people.length; index++) {
    const person = group.people[index];
    if (person.status !== 'moving' && person.status !== 'holding' && person.status !== 'sheltered') continue;
    if (person.x < left || person.x > right || person.y < top || person.y > bottom) continue;
    draw(person.x, person.y, dots ? 0 : civilianFrame(person, index, group.elapsed));
  }
  const zombies = group.outbreak?.zombies ?? [];
  group.defense?.soldiers.forEach((soldier, index) => {
    if (soldier.state === 'aboard' || soldier.state === 'lost' || soldier.carrier !== undefined || soldier.x < left || soldier.x > right || soldier.y < top || soldier.y > bottom) return;
    if (dots) {
      draw(soldier.x, soldier.y, soldier.type === 'infantry' ? 3 : soldier.type === 'sniper' ? 4 : soldier.type === 'medic' ? 5 : 6);
      return;
    }
    draw(soldier.x, soldier.y, soldierFrame(soldier, index, group.elapsed), vehicleVisualScale(soldier.type),
      soldier.hullHeading === undefined ? 0 : facingOffset(soldier.hullHeading));
  });
  for (let index = 0; index < zombies.length; index++) {
    const zombie = zombies[index];
    if (zombie.x < left || zombie.x > right || zombie.y < top || zombie.y > bottom) continue;
    const attack = zombie.attack;
    if (dots) {
      draw(zombie.x, zombie.y, zombie.mutant ? 2 : 1);
      continue;
    }
    if (!attack) {
      draw(zombie.x, zombie.y, civilianFrame(zombie, index, group.elapsed, true), 1, 0, Number(!!zombie.mutant));
      continue;
    }
    const progress = (group.elapsed - attack.start) / (attack.biteEnd - attack.start);
    const reach = Math.sin(Math.PI * Math.max(0, Math.min(1, progress))) * 0.34;
    draw(zombie.x + (attack.victim.x - zombie.x) * reach, zombie.y + (attack.victim.y - zombie.y) * reach,
      encounterFrame(attack, group.elapsed, true), 1, 0, Number(!!zombie.mutant));
  }
}

function drawRoutes(layer: Graphics, trails: Point[][]) {
  layer.clear();
  if (trails.length) {
    for (const [color, width] of [[0x142023, 8], [0xf9c878, 3]]) {
      for (const trail of trails) {
        layer.moveTo(...trail[0]);
        for (const point of trail.slice(1)) layer.lineTo(...point);
      }
      layer.stroke({ color, width, cap: 'round', join: 'round' });
    }
  }
}

function BombImpact({ x, y, age, size }: { x: number; y: number; age: number; size: number }) {
  if (age > 2.6) return null;
  const flash = Math.max(0, 1 - age * 2.8);
  const smoke = Math.max(0, 1 - age / 2.6);
  return <g className="bomb-impact" transform={`translate(${x} ${y})`}>
    <ellipse className="blast-scorch" rx={size * .62} ry={size * .42} opacity={smoke * .5} />
    <circle className="blast-ring" r={size * (.25 + Math.min(age, .8) * 1.64)} opacity={Math.max(0, .75 - age)} />
    {Array.from({length: 10}, (_, index) => {
      const angle = index * 2.4;
      const distance = size * (.12 + age * .48) * (.65 + (index % 4) * .16);
      const px = Math.cos(angle) * distance;
      const py = Math.sin(angle) * distance * .64;
      return <g key={index}>
        <circle className="blast-smoke" cx={px + age * 11} cy={py - age * 17} r={size * (.11 + age * .12)} opacity={smoke * .73} />
        <circle className="blast-fire" cx={px} cy={py} r={size * (.22 + (index % 3) * .06)} opacity={flash} />
        {age < .65 && <line className="blast-debris" x1={px * .9} y1={py * .9} x2={px * 2.4} y2={py * 2.4} opacity={1 - age / .65} />}
      </g>;
    })}
    <circle className="blast-core" r={size * .25} opacity={flash} />
  </g>;
}

function AirSupportOverlay({ runs, clock, camera }: { runs: readonly SupportRun[]; clock: { current: number }; camera: Camera }) {
  const [elapsed, setElapsed] = useState(clock.current);
  useEffect(() => {
    let request = 0;
    function animate() {
      setElapsed(clock.current);
      request = requestAnimationFrame(animate);
    }
    animate();
    return () => cancelAnimationFrame(request);
  }, [clock]);
  return <svg className="air-support-overlay" width={camera.width} height={camera.height} aria-hidden="true">
    {runs.map(run => {
      const [x, y] = project(run.point, camera);
      const time = elapsed - run.impactAt;
      if (run.type === 'helicopter') {
        const duration = supportDuration(run.type);
        const orbit = Math.max(18, 16 * camera.zoom);
        const flight = escortFlight(time, supportTypes.helicopter.delay, duration, orbit, x, y - 16, camera.width);
        const hx = flight.x, hy = flight.y;
        const target = run.lastTarget && project(run.lastTarget, camera);
        return <g key={run.impactAt}>
          <circle className="support-target" cx={x} cy={y} r={45 * camera.zoom} />
          <text className="support-countdown" x={x} y={y - 18} textAnchor="middle">{time < 0 ? `UH-60 inbound · ${Math.ceil(-time)}s` : time <= duration ? 'UH-60 on station' : 'UH-60 departing'}</text>
          {target && time >= 0 && time <= duration + .3 && time % 1 < .35 &&
            <path className="gun-run-traces" d={`M${hx - 4},${hy}L${target[0]},${target[1]}M${hx + 4},${hy}L${target[0] + 3},${target[1]}`} />}
          <g className="support-helicopter" transform={`translate(${hx} ${hy}) rotate(${flight.heading})`}>
            <image href={aircraftArt.helicopter} x="-35" y="-29" width="70" height="58" />
            <g className="evac-heli-rotor"><path d="M-24 0H24M0-24V24" /></g>
          </g>
        </g>;
      }
      const [dx, dy] = run.axis ?? [1, 0];
      const angle = Math.atan2(dy, dx) * 180 / Math.PI;
      const lane = (run.length ?? 28) * camera.zoom;
      const jetSpeed = (Math.hypot(camera.width, camera.height) + 180) / supportTypes[run.type].delay;
      const jetX = x + dx * time * jetSpeed;
      const jetY = y + dy * time * jetSpeed - 8;
      return <g key={run.impactAt}>
        {run.type === 'strike' ? time < 0
          ? <circle className="support-target" cx={x} cy={y} r={Math.max(8, supportTypes.strike.radius * camera.zoom)} />
          : <BombImpact x={x} y={y} age={time} size={Math.max(22, 11 * camera.zoom)} />
          : time < 0 ? <rect className="support-target" x={x - lane / 2} y={y - 2.5 * camera.zoom} width={lane} height={5 * camera.zoom} rx={3} transform={`rotate(${angle} ${x} ${y})`} />
          : <g className="cannon-effects">
            {Array.from({ length: run.pulses }, (_, pulse) => {
              const age = time - pulse * supportTypes.gunRun.interval + .105;
              if (age < 0 || age > .52) return null;
              const [px, py] = project(supportImpact(run, pulse), camera);
              const reach = Math.min(1, age / .105);
              const release = (pulse * supportTypes.gunRun.interval - .105) * jetSpeed + 32;
              const fromX = x + dx * release;
              const fromY = y + dy * release - 8;
              return <g key={pulse} opacity={1 - age / .55}>
                {age < .18 && <line className="cannon-tracer" x1={fromX + (px - fromX) * Math.max(0, reach - .42)}
                  y1={fromY + (py - fromY) * Math.max(0, reach - .42)} x2={fromX + (px - fromX) * reach}
                  y2={fromY + (py - fromY) * reach} />}
                {age > .10 && <>
                  <ellipse className="cannon-dust" cx={px + age * 8} cy={py - age * 6} rx={2 + age * 12} ry={1.5 + age * 7} />
                  <path className="cannon-spark" d={`M${px - 3} ${py - 3}l3 3 4 -5m-4 5 6 2`} />
                </>}
              </g>;
            })}
          </g>}
        {time < 0 && <text className="support-countdown" x={x} y={y - 14} textAnchor="middle">
          {run.type === 'gunRun' ? '30 mm cannon' : 'Bomb strike'} · {Math.ceil(-time)}s
        </text>}
        <g className="support-jet" transform={`translate(${jetX} ${jetY}) rotate(${angle})`}>
          <image href={aircraftArt[run.type]} x="-45" y="-43" width="90" height="86" />
          <path className="jet-trail" d="M-30 0H-75" />
        </g>
      </g>;
    })}
  </svg>;
}

function SupportAim({ start, cursor, type, camera }: {
  start: Point; cursor: Point | null; type: SupportType; camera: Camera;
}) {
  const [x, y] = project(start, camera);
  const [endX, endY] = project(cursor ?? start, camera);
  const length = Math.hypot(endX - x, endY - y);
  const angle = Math.atan2(endY - y, endX - x) * 180 / Math.PI;
  return <svg className="air-support-overlay" width={camera.width} height={camera.height} aria-hidden="true">
    <circle className="support-target" cx={x} cy={y} r={type === 'strike' ? supportTypes.strike.radius * camera.zoom : 5} />
    {length > 4 && <g className="support-aim" transform={`translate(${x} ${y}) rotate(${angle})`}>
      <line x2={length} />
      <path d={`M${length - 9} -5 L${length} 0 L${length - 9} 5`} />
    </g>}
  </svg>;
}

function GroundFires({ fires, elapsed, camera }: { fires: readonly GroundFire[]; elapsed: number; camera: Camera }) {
  return <svg className="air-support-overlay ground-fires" width={camera.width} height={camera.height} aria-hidden="true">
    {fires.map(({ point, start, until, radius }) => {
      const [x, y] = project(point, camera);
      const size = Math.max(3, radius * camera.zoom);
      if (x < -size || y < -size || x > camera.width + size || y > camera.height + size) return null;
      return <g key={`${point.join(',')}:${start}`} transform={`translate(${x} ${y}) scale(${size / 12})`}
        opacity={Math.max(0, Math.min(1, (until - elapsed) / 2))}>
        <ellipse className="fire-scorch" rx="12" ry="7" />
        <circle className="fire-smoke" cx="2" cy="-8" r="5" />
        <path className="fire-flame" d="M-10 2Q-14-2-9-8Q-9-3-5-4Q-7-8 0-15Q-2-10 2-7Q5-5 5-2Q9-5 8-8Q14-4 10 2Q4 8-4 6Z" />
        <path className="fire-core" d="M-5 3Q-6 0 0-6Q-1-2 3-1Q7 1 4 5Q-2 7-5 3Z" />
      </g>;
    })}
  </svg>;
}

function EvacuationFlight({ passengers, aircraft, elapsed, camera, departed }: {
  passengers: number; aircraft: readonly Airlift[]; elapsed: number; camera: Camera; departed: boolean;
}) {
  return <div className="evac-flight" role="group"
    aria-label={departed ? `Helicopters extracting ${passengers} people` : 'Helicopters arriving at pickup'}>
    {aircraft.map((flight, index) => {
      if (flight.aborted || (!flight.departed && elapsed < flight.opensAt - 3)) return null;
      const [left, top] = project(flight.point, camera);
      const departureHeading = Math.atan2(-185 - index * 30, 90 + index * 70) * 180 / Math.PI;
      const phase = flight.departed ? 'departing' : elapsed < flight.opensAt ? 'approaching' : 'boarding';
      return (
      <div key={index} className={`airlift-pad ${phase}`} style={{left, top}}>
      <div className="evac-aircraft" style={{
        '--launch-delay': `${index * 0.1}s`,
        '--launch-x': '0px',
        '--launch-y': '0px',
        '--flight-x': `${90 + index * 70}px`,
        '--flight-y': `${-185 - index * 30}px`,
      } as CSSProperties}>
        <div className="rotor-wash" />
        <div className="rotor-debris" aria-hidden="true">
          {Array.from({length: 8}, (_, i) => <i key={i} style={{
            '--debris-angle': `${i * 45 + index * 17}deg`, '--debris-delay': `${i * -0.17}s`,
          } as CSSProperties} />)}
        </div>
        <svg viewBox="-40 -40 80 80" className="evac-helicopter" aria-hidden="true">
          <ellipse className="evac-heli-shadow" cx="7" cy="8" rx="16" ry="25" />
          <g className={phase === 'departing' ? 'evac-departure-heading' : undefined}
            transform={`rotate(${phase === 'departing' ? -90 : departureHeading + 180})`}
            style={{ '--departure-heading': `${departureHeading}deg` } as CSSProperties}>
            <image href={aircraftArt.helicopter} x="-39" y="-33" width="78" height="66" />
          </g>
          <g className="evac-heli-rotor">
            <circle r="28" />
            <path d="M-29 0h58M0-29v58" />
          </g>
        </svg>
      </div>
      {phase !== 'departing' && <span className="airlift-label">
        {phase === 'approaching' ? `Aircraft ${index + 1} inbound` : `Aircraft ${index + 1} · ${flight.capacity - flight.boarded} seats · ${Math.max(0, Math.ceil(flight.closesAt - elapsed))}s`}
      </span>}
      </div>
      );
    })}
  </div>;
}

function CanalLights({ camera, data, overview }: { camera: Camera; data: Venice; overview: Overview }) {
  const id = useId();
  const rings = useMemo(() => [...overview.water, ...data.terrain.water.map(ring => [ring])]
    .map(rings => rings.map(ring => 'M' + ring.map(point => point.join(',')).join('L') + 'Z').join('')), [data, overview]);
  const offset = project([0, 0], camera);
  const visible = data.crossings.filter(({ position }) => {
    const [x, y] = project(position, camera);
    return x > -60 && y > -60 && x < camera.width + 60 && y < camera.height + 60;
  });
  if (!visible.length || camera.zoom < 1.5) return null;
  return <svg className="canal-emergency" width={camera.width} height={camera.height} aria-hidden="true">
    <defs>
      <clipPath id={id}><g transform={`translate(${offset.join(' ')}) scale(${camera.zoom})`}>
        {rings.map((ring, i) => <path key={i} d={ring} clipRule="evenodd" />)}
      </g></clipPath>
      <radialGradient id={id + '-red'}><stop stopColor="#fa6246" stopOpacity=".62" /><stop offset="1" stopColor="#fa6246" stopOpacity="0" /></radialGradient>
      <radialGradient id={id + '-blue'}><stop stopColor="#88bbff" stopOpacity=".58" /><stop offset="1" stopColor="#88bbff" stopOpacity="0" /></radialGradient>
    </defs>
    {visible.map(({ id: crossing, position }, index) => {
      const [x, y] = project(position, camera);
      const radius = Math.min(85, camera.zoom * 19);
      return <g key={crossing} style={{ '--pulse-offset': `${index * -0.77}s` } as CSSProperties}>
        <g clipPath={`url(#${id})`}>
          <ellipse className="emergency-red" cx={x - 5} cy={y} rx={radius} ry={radius * .56} fill={`url(#${id}-red)`} />
          <ellipse className="emergency-blue" cx={x + 6} cy={y} rx={radius} ry={radius * .65} fill={`url(#${id}-blue)`} />
        </g>
        <circle className="emergency-red" cx={x - 3} cy={y} r="2" fill="#ff8a6e" />
        <circle className="emergency-blue" cx={x + 3} cy={y} r="2" fill="#99cfff" />
      </g>;
    })}
  </svg>;
}

function PatrolOverlay({ patrols, camera }: {
  patrols: ReturnType<Defense['patrolView']>[]; camera: Camera;
}) {
  const centers = new Map<string, Point>();
  const obstructions = new Map<string, Point>();
  for (const { center, obstruction } of patrols) {
    if (center) centers.set(center.join(','), center);
    if (obstruction) obstructions.set(obstruction.join(','), obstruction);
  }
  return <svg className="patrol-overlay" width={camera.width} height={camera.height} role="img" aria-label="Selected troop routes and patrol areas">
    {[...centers].map(([key, center]) => {
      const [x, y] = project(center, camera);
      return <g key={key}><circle className="patrol-area" cx={x} cy={y} r={patrolRadius * camera.zoom} />
        <path className="patrol-cross" d={`M${x - 5},${y}h10m-5,-5v10`} /></g>;
    })}
    {patrols.map(({ path }, index) => {
      if (path.length < 2) return null;
      const [x, y] = project(path.at(-1)!, camera);
      return <g key={index}><polyline className="patrol-path" points={path.map(point => project(point, camera).join(',')).join(' ')} />
        <circle className="patrol-destination" cx={x} cy={y} r={3} /></g>;
    })}
    {[...obstructions].map(([key, point]) => {
      const [x, y] = project(point, camera);
      return <g key={key} className="patrol-obstruction" transform={`translate(${x} ${y - 20})`}>
        <circle r="9" /><path d="M-3 -3l6 6m0 -6l-6 6" /><title>Patrol route blocked by barricade</title>
      </g>;
    })}
  </svg>;
}

export function MapView(props: Props) {
  const { data, overview, closed, selection, civilianSpawns, zombieSpawns, end, deployments, defensePhase, canCommand, evacuatedPassengers, aircraft, elapsed, defense, clearance, supportRuns, supportStart, supportType, groundFires, outbreakActive, night, rescueMarkers, gateQueues, zoneRadius, gates, barricadeStart, barricadeCredits, inspectGaps, coverage, onPlace, onCancelPlacement, placementMessage, onToggleGate, onCrossing, onRemoveSpawn, hud, commandBar } = props;
  const [commandMode, setCommandMode] = useState<'patrol' | 'rescue' | null>(null);
  const [selectedTroops, setSelectedTroops] = useState<number[]>([]);
  const [selectionBox, setSelectionBox] = useState<[Point, Point]>();
  const [commandMessage, setCommandMessage] = useState('');
  const selectionDrag = useRef<Point | undefined>(undefined);
  const selectedRef = useRef<number[]>([]);
  const [squads, setSquads] = useState<number[][]>([[], [], []]);
  const [returnAfterRescue, setReturnAfterRescue] = useState(false);
  useEffect(() => {
    setSquads([[], [], []]);
    setReturnAfterRescue(false);
  }, [defense]);

  function useSquad(slot: number, save: boolean) {
    if (!canCommand || !defense) return;
    const available = (indices: number[]) => indices.filter(index => {
      const soldier = defense.soldiers[index];
      return soldier?.state === 'patrol' && soldier.carrier === undefined;
    });
    const troops = available(save ? selectedRef.current : squads[slot]);
    if (!troops.length) {
      setCommandMode(mode => mode ?? 'patrol');
      setCommandMessage(save ? 'Select ground troops before saving a squad.' : `Squad ${slot + 1} has no available troops.`);
      return;
    }
    if (save) setSquads(groups => groups.map((group, index) => index === slot ? troops : group));
    else {
      selectedRef.current = troops;
      setSelectedTroops(troops);
    }
    setCommandMode(mode => mode ?? 'patrol');
    setCommandMessage(`Squad ${slot + 1} ${save ? 'saved' : 'selected'} · ${troops.length} troops`);
  }

  useEffect(() => {
    const panel = map.current;
    function onSquadKey(event: globalThis.KeyboardEvent) {
      if (!canCommand || event.repeat || event.altKey || event.metaKey || event.ctrlKey) return;
      if (event.target instanceof Element && event.target.closest('input, select, textarea, [contenteditable], [role=combobox]')) return;
      const match = /^(?:Digit|Numpad)([1-3])$/.exec(event.code);
      if (!match || !panel?.contains(document.activeElement)) return;
      event.preventDefault();
      useSquad(Number(match[1]) - 1, event.shiftKey);
    }
    document.addEventListener('keydown', onSquadKey);
    return () => document.removeEventListener('keydown', onSquadKey);
  });
  useEffect(() => {
    if (canCommand && !selection) return;
    setCommandMode(null);
    setSelectedTroops([]);
    selectedRef.current = [];
    setCommandMessage('');
  }, [canCommand, selection]);
  const [showCoverage, setShowCoverage] = useState(false);
  const [supportCursor, setSupportCursor] = useState<Point | null>(null);
  const [barricadeCursor, setBarricadeCursor] = useState<Point | null>(null);
  const [dots, setDots] = useState(() => {
    try { return localStorage.getItem('rialto-dots') === 'true'; } catch { return false; }
  });
  const dotsMode = useRef(dots);
  const [tilt, setTilt] = useState(0);
  const angleRef = useRef(0);
  const [following, setFollowing] = useState<number>();
  const followedUnit = following === undefined ? undefined : defense?.soldiers[following];
  const [camera, setCamera] = useState(() => initialView(1000, 700));
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(false);
  const [showDensity, setShowDensity] = useState(false);
  const densityEnabled = useRef(false);
  const [screen, setScreen] = useState<'window' | 'native' | 'viewport'>('window');
  const map = useRef<HTMLDivElement>(null);
  const world = useRef<HTMLDivElement>(null);
  const flightClock = useRef(0);
  const surface = useRef<HTMLDivElement>(null);
  const fallback = useRef<HTMLCanvasElement>(null);
  const view = useRef(camera);
  const latest = useRef(props);
  const [, refreshPatrols] = useState(0);
  const showPatrols = canCommand && commandMode !== null && selectedTroops.length > 0;
  useEffect(() => {
    if (!showPatrols) return;
    const timer = window.setInterval(() => refreshPatrols(value => value + 1), 150);
    return () => window.clearInterval(timer);
  }, [showPatrols]);
  const [soundOn, setSoundOn] = useState(false);
  const audio = useRef<AudioContext | undefined>(undefined);
  useEffect(() => () => { void audio.current?.close(); }, []);
  useEffect(() => {
    const context = audio.current;
    if (!outbreakActive || !soundOn || !context) return;
    soundSiren(context);
    const timer = window.setInterval(() => soundSiren(context), 13500);
    return () => window.clearInterval(timer);
  }, [outbreakActive, soundOn]);

  const heardSlams = useRef(new WeakMap<ZoneGate, number>());
  useEffect(() => {
    const context = audio.current;
    for (const gate of gates ?? []) {
      if (gate.slamAt === undefined || heardSlams.current.get(gate) === gate.slamAt || elapsed - gate.slamAt > 1) continue;
      heardSlams.current.set(gate, gate.slamAt);
      if (soundOn && context) soundImpact(context);
    }
  }, [elapsed, gates, soundOn]);

  async function toggleSound() {
    if (soundOn) {
      setSoundOn(false);
      await audio.current?.suspend();
      return;
    }
    try {
      audio.current ??= new AudioContext();
      await audio.current.resume();
      setSoundOn(true);
    } catch {
      setSoundOn(false);
    }
  }

  const patrols = showPatrols && defense ? selectedTroops.flatMap(index => {
    const soldier = defense.soldiers[index];
    return soldier?.state === 'patrol' ? [defense.patrolView(soldier)] : [];
  }) : [];
  const blockedPatrols = patrols.filter(patrol => patrol.blocked).length;
  const drag = useRef<{ origin: Point; x: number; y: number; moved: boolean } | null>(null);

  function update(camera: Camera) {
    const next = limitCamera(camera, overview.bounds);
    view.current = next;
    setCamera(next);
  }

  useEffect(() => {
    setFollowing(undefined);
  }, [defense]);

  useEffect(() => {
    if (!followedUnit) return;
    const timer = window.setInterval(() => {
      if (followedUnit.state === 'lost' || followedUnit.state === 'aboard' || followedUnit.carrier !== undefined) {
        setFollowing(undefined);
        return;
      }
      const camera = view.current;
      const x = followedUnit.x + Math.cos(followedUnit.heading) * 4;
      const y = followedUnit.y + Math.sin(followedUnit.heading) * 4;
      if (Math.hypot(x - camera.x, y - camera.y) > .25) update({ ...camera, x, y });
    }, 80);
    return () => window.clearInterval(timer);
  }, [followedUnit, overview]);

  function toggleDots() {
    dotsMode.current = !dotsMode.current;
    setDots(dotsMode.current);
    try { localStorage.setItem('rialto-dots', String(dotsMode.current)); } catch { /* File view can block storage. */ }
  }

  function zoom(factor: number, point?: Point) {
    const current = view.current;
    const nextZoom = limitCamera({ ...current, zoom: current.zoom * factor }, overview.bounds).zoom;
    const target: Point = point ?? [current.width / 2, current.height / 2];
    const [x, y] = unproject(target, current);
    update({
      ...current,
      zoom: nextZoom,
      x: x - (target[0] - current.width / 2) / nextZoom,
      y: y - (target[1] - current.height / 2) / nextZoom,
    });
  }

  async function toggleFullscreen() {
    const panel = map.current;
    if (!panel) return;
    if (screen === 'viewport') {
      setScreen('window');
    } else if (document.fullscreenElement === panel) {
      await document.exitFullscreen();
    } else {
      try {
        await panel.requestFullscreen();
      } catch {
        setScreen('viewport');
      }
    }
  }

  useEffect(() => {
    const panel = map.current;
    if (!panel) return;
    function dismiss(event: PointerEvent | KeyboardEvent) {
      if (event instanceof KeyboardEvent && event.key !== 'Escape') return;
      for (const menu of panel!.querySelectorAll<HTMLDetailsElement>('.command-menu[open], .view-tools[open], .map-attribution[open]')) {
        if (event instanceof PointerEvent && event.target instanceof Node && menu.contains(event.target)) continue;
        menu.open = false;
        if (event instanceof KeyboardEvent) menu.querySelector('summary')?.focus();
      }
    }
    document.addEventListener('pointerdown', dismiss);
    document.addEventListener('keydown', dismiss);
    return () => {
      document.removeEventListener('pointerdown', dismiss);
      document.removeEventListener('keydown', dismiss);
    };
  }, []);

  useEffect(() => {
    function onFullscreenChange() {
      setScreen(mode => document.fullscreenElement === map.current ? 'native' : mode === 'native' ? 'window' : mode);
    }
    document.addEventListener('fullscreenchange', onFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', onFullscreenChange);
  }, []);

  useEffect(() => {
    if (screen !== 'viewport') return;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    function onEscape(event: KeyboardEvent) {
      if (event.key === 'Escape') setScreen('window');
    }
    window.addEventListener('keydown', onEscape);
    return () => {
      document.body.style.overflow = overflow;
      window.removeEventListener('keydown', onEscape);
    };
  }, [screen]);

  function fitRoute() {
    const current = view.current;
    const group = latest.current.frame(0);
    const points = [...group.trails().flat(), end, ...civilianSpawns.map(spawn => spawn.position), ...zombieSpawns.map(spawn => spawn.position)];
    if (!clearance && (!civilianSpawns.length || (group.outbreak && !zombieSpawns.length))) points.push([0, 0], data.size);
    const xs = points.map(point => point[0]);
    const ys = points.map(point => point[1]);
    const left = Math.min(...xs);
    const right = Math.max(...xs);
    const top = Math.min(...ys);
    const bottom = Math.max(...ys);
    update({
      ...current,
      x: (left + right) / 2,
      y: (top + bottom) / 2,
      zoom: Math.min(
        1.75,
        (current.width - 72) / Math.max(1, right - left),
        (current.height - 100) / Math.max(1, bottom - top),
      ),
    });
  }

  function streetView() {
    const group = latest.current.frame(0);
    const runner = group.people.find(person => person.status === 'moving' || person.status === 'holding')
      ?? (civilianSpawns.length ? undefined : group.people[0]);
    const [x, y] = runner ? [runner.x, runner.y] : civilianSpawns[0]?.position ?? end;
    update({ ...view.current, x, y, zoom: 6 });
  }

  useEffect(() => {
    latest.current = props;
  }, [props]);

  useEffect(() => {
    const host = surface.current;
    const panel = map.current;
    const plane = world.current;
    if (!host || !panel || !plane) return;
    let active = true;
    let started = false;
    let animation = 0;
    let releaseTextures = () => {};
    const atlas = drawAtlas(data, overview);
    let civilianAtlases: HTMLCanvasElement[] | undefined;
    const dotAtlas = drawDotAtlas();
    const infectedMarkers = drawInfectedMarkers();
    let sampledGroup: EvacuationGroup | undefined;
    let sampledAt = -1;
    let tiles: ReturnType<typeof crowdDensity> = [];
    function drawDensity(group: EvacuationGroup, camera: Camera, draw: (x: number, y: number, radius: number, crowded: boolean) => void) {
      if (!densityEnabled.current) return;
      const sample = Math.floor(group.elapsed * 4);
      if (sampledGroup !== group || sampledAt !== sample) {
        sampledGroup = group;
        sampledAt = sample;
        tiles = crowdDensity(group);
      }
      const radius = Math.max(5, Math.min(18, 4 * camera.zoom));
      for (const tile of tiles) {
        const [x, y] = project([tile.x, tile.y], camera);
        if (x < -radius || y < -radius || x > camera.width + radius || y > camera.height + radius) continue;
        draw(x, y, radius, tile.count >= 12);
      }
    }
    const [left, top, right, bottom] = overview.bounds;
    const chartWidth = right - left;
    const chartHeight = bottom - top;
    const app = new Application();
    const resolution = Math.min(devicePixelRatio || 1, 2.5);
    let detailCamera: Camera | undefined;
    let detailSince = 0;
    let detail: HTMLCanvasElement | undefined;

    function detailedView(camera: Camera, now: number) {
      if (camera !== detailCamera) {
        detailCamera = camera;
        detailSince = now;
        detail = undefined;
      }
      if (!detail && now - detailSince > 140 && camera.zoom * resolution > atlas.width / chartWidth) {
        const dpr = Math.min(resolution, 3800 / Math.max(camera.width, camera.height));
        const [x, y] = project([0, 0], camera);
        detail = drawAtlas(data, overview, {
          width: camera.width * dpr,
          height: camera.height * dpr,
          x: x * dpr,
          y: y * dpr,
          scale: camera.zoom * dpr,
        });
      }
      return detail;
    }

    const observer = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect;
      if (!width || !height) return;
      const current = view.current;
      update(started ? { ...current, width, height } : initialView(width, height));
      if (app.renderer) app.renderer.resize(width, height);
    });
    observer.observe(plane);
    const wheel = (event: WheelEvent) => {
      if (event.target instanceof Element && event.target.closest('.command-dock, .map-utilities, .map-attribution, .map-placement, .dot-legend')) return;
      event.preventDefault();
      zoom(Math.exp(-event.deltaY * (event.deltaMode === 1 ? 0.06 : 0.0014)), mapPoint(event.clientX, event.clientY));
    };
    panel.addEventListener('wheel', wheel, { passive: false });
    const width = plane.clientWidth;
    const height = plane.clientHeight;
    update(initialView(width, height));

    function useCanvasFallback() {
      const canvas = fallback.current;
      const context = canvas?.getContext('2d');
      if (!canvas || !context) {
        setError(true);
        return;
      }
      canvas.hidden = false;
      let previous = performance.now();
      function draw(time: number) {
        if (!active || !canvas || !context) return;
        const camera = view.current;
        const width = Math.round(camera.width * resolution);
        const height = Math.round(camera.height * resolution);
        if (canvas.width !== width || canvas.height !== height) {
          canvas.width = width;
          canvas.height = height;
        }
        const group = latest.current.frame(Math.min((time - previous) / 1000, 0.25));
        flightClock.current = group.elapsed;
        previous = time;
        const [x, y] = project([left, top], camera);
        context.setTransform(resolution, 0, 0, resolution, 0, 0);
        context.fillStyle = '#182123';
        context.fillRect(0, 0, camera.width, camera.height);
        const sharp = dotsMode.current || surface.current?.dataset.following === 'true' ? undefined : detailedView(camera, time);
        if (sharp) context.drawImage(sharp, 0, 0, camera.width, camera.height);
        else context.drawImage(atlas, x, y, chartWidth * camera.zoom, chartHeight * camera.zoom);
        drawDensity(group, camera, (x, y, radius, crowded) => {
          context.beginPath();
          context.arc(x, y, radius, 0, Math.PI * 2);
          context.fillStyle = crowded ? '#f17d397a' : '#ffbd6552';
          context.fill();
        });
        group.outbreak?.decals.drawCanvas(context, group.elapsed, camera);
        const trails = group.status === 'ready' ? group.trails() : [];
        if (trails.length) {
          context.beginPath();
          for (const trail of trails) {
            context.moveTo(...project(trail[0], camera));
            for (const point of trail.slice(1)) context.lineTo(...project(point, camera));
          }
          context.lineJoin = 'round';
          context.lineCap = 'round';
          context.strokeStyle = '#142023';
          context.lineWidth = 8;
          context.stroke();
          context.strokeStyle = '#f9c878';
          context.lineWidth = 3;
          context.stroke();
        }
        if (group.defense) {
          for (const [index, soldier] of group.defense.soldiers.entries()) {
            if (soldier.state === 'lost' || soldier.state === 'aboard') continue;
            const selected = selectedRef.current.includes(index);
            const [sx, sy] = project([soldier.x, soldier.y], camera);
            context.beginPath();
            context.arc(sx, sy, selected ? 6.2 : 3.8, 0, Math.PI * 2);
            context.strokeStyle = selected ? '#ffd685' : soldier.reloadUntil ? '#ffc88d' : soldier.type === 'medic' ? '#e8a5c7' : soldier.type === 'sniper' ? '#99cbe4' : '#b7e0ba';
            context.lineWidth = 1.2;
            context.stroke();
            if (soldier.type === 'medic' && camera.zoom >= 2) {
              context.beginPath();
              context.moveTo(sx - 2, sy - 8);
              context.lineTo(sx + 2, sy - 8);
              context.moveTo(sx, sy - 10);
              context.lineTo(sx, sy - 6);
              context.stroke();
            }
          }
          context.beginPath();
          for (const shot of group.defense.shots) {
            const trace = bulletTrace(shot, group.elapsed, camera);
            context.beginPath();
            if (trace.flash) {
              context.save();
              context.translate(trace.x, trace.y);
              context.rotate(trace.angle);
              context.fillStyle = '#ffdf9ad9';
              context.beginPath();
              context.moveTo(0, 0);
              context.lineTo(trace.flashSize * 2, -trace.flashSize);
              context.lineTo(trace.flashSize * 3, 0);
              context.lineTo(trace.flashSize * 2, trace.flashSize);
              context.fill();
              context.restore();
              context.beginPath();
            }
            if (trace.shellImpact !== undefined) {
              context.beginPath();
              context.arc(trace.headX, trace.headY, (2 + trace.shellImpact * 18) * Math.max(1, camera.zoom / 2), 0, Math.PI * 2);
              context.fillStyle = `rgba(255, ${Math.round(165 - trace.shellImpact * 150)}, 68, ${Math.max(0, 1 - trace.shellImpact * 2.3)})`;
              context.fill();
              continue;
            }
            context.moveTo(trace.tailX, trace.tailY);
            context.lineTo(trace.headX, trace.headY);
            context.strokeStyle = '#eacdaa9c';
            context.lineWidth = shot.shell ? 2.7 : 0.9;
            context.stroke();
          }
        }
        const spriteScale = runnerScale * camera.zoom;
        const originX = camera.width / 2 - camera.x * camera.zoom;
        const originY = camera.height / 2 - camera.y * camera.zoom;
        const lowDetail = dotsMode.current;
        const atlases = lowDetail ? undefined : civilianAtlases ??= drawCivilianAtlases();
        forEachRunner(group, camera, lowDetail, (x, y, frame, scale = 1, rotation = 0, infectedMarker) => {
          if (lowDetail) {
            const [sx, sy] = project([x, y], camera);
            context.drawImage(dotAtlas, frame * 12, 0, 12, 12, sx - 6, sy - 6, 12, 12);
            return;
          }
          const actorAtlas = atlases![Math.floor(frame / framesPerAtlas)];
          const [sourceX, sourceY] = civilianFrameOrigin(frame);
          const width = civilianCell * spriteScale * scale, height = civilianCellHeight * spriteScale * scale;
          const left = -width * civilianAnchor[0], top = -height * civilianAnchor[1];
          const centerX = originX + x * camera.zoom, centerY = originY + y * camera.zoom;
          if (infectedMarker !== undefined) {
            const size = infectedMarkerSize(camera.zoom);
            context.drawImage(infectedMarkers, infectedMarker * markerSize, 0, markerSize, markerSize,
              centerX - size / 2, centerY - size * .3, size, size);
          }
          if (rotation) {
            context.save();
            context.translate(centerX, centerY);
            context.rotate(rotation);
            context.drawImage(actorAtlas, sourceX, sourceY, civilianCell, civilianCellHeight, left, top, width, height);
            context.restore();
          } else {
            context.drawImage(actorAtlas, sourceX, sourceY, civilianCell, civilianCellHeight, centerX + left, centerY + top, width, height);
          }
        });
        animation = requestAnimationFrame(draw);
      }
      started = true;
      setReady(true);
      animation = requestAnimationFrame(draw);
    }

    app.init({ width, height, background: 0x182123, resolution, autoDensity: true, antialias: true, preference: ['webgl', 'webgpu'] }).then(() => {
      if (!active) {
        app.destroy(true, { children: true });
        return;
      }
      const sprite = new Sprite(Texture.from(atlas));
      const sharpSprite = new Sprite();
      let sharpCanvas: HTMLCanvasElement | undefined;
      const layer = new Graphics();
      const densityLayer = new Graphics();
      const shotLayer = new Graphics();
      const bloodLayer = new Graphics();
      let densityCamera: Camera | undefined;
      let densitySample = -1;
      let densityGroup: EvacuationGroup | undefined;
      let routeCamera: Camera | undefined;
      let routes: EvacuationGroup['routes'] | undefined;
      function actorLayer(atlas: HTMLCanvasElement, count: number, width: number, height: number, dotMode: boolean) {
        const sheet = Texture.from(atlas);
        const frames = Array.from({ length: count }, (_, index) => {
          const [x, y] = dotMode ? [index * width, 0] : civilianFrameOrigin(index);
          return new Texture({ source: sheet.source, frame: new Rectangle(x, y, width, height) });
        });
        const layer = new ParticleContainer<Particle>({
          texture: sheet,
          dynamicProperties: { position: true, uvs: true, vertex: true, rotation: !dotMode },
        });
        app.stage.addChild(layer);
        return { sheet, frames, layer, pool: [] as Particle[] };
      }
      app.stage.addChild(sprite, sharpSprite, bloodLayer, densityLayer, layer, shotLayer);
      const dotLayer = actorLayer(dotAtlas, dotColors.length, 12, 12, true);
      const markerLayer = actorLayer(infectedMarkers, 2, markerSize, markerSize, true);
      let modelLayers: ReturnType<typeof actorLayer>[] | undefined;
      const chartTexture = sprite.texture;
      releaseTextures = () => {
        chartTexture.destroy(true);
        if (sharpCanvas) sharpSprite.texture.destroy(true);
        for (const actors of [dotLayer, markerLayer, ...(modelLayers ?? [])]) {
          for (const texture of actors.frames) texture.destroy(false);
          actors.sheet.destroy(true);
        }
      };
      host.appendChild(app.canvas);
      app.renderer.resize(view.current.width, view.current.height);
      started = true;
      setReady(true);
      app.ticker.add(ticker => {
        const camera = view.current;
        sprite.position.set(...project([left, top], camera));
        sprite.width = chartWidth * camera.zoom;
        sprite.height = chartHeight * camera.zoom;
        const sharp = dotsMode.current || surface.current?.dataset.following === 'true' ? undefined : detailedView(camera, performance.now());
        if (sharpCanvas !== sharp) {
          if (sharpCanvas) sharpSprite.texture.destroy(true);
          sharpSprite.texture = sharp ? Texture.from(sharp) : Texture.EMPTY;
          sharpCanvas = sharp;
        }
        sharpSprite.visible = !!sharp;
        if (sharp) {
          sharpSprite.width = camera.width;
          sharpSprite.height = camera.height;
        }
        const group = latest.current.frame(Math.min(ticker.elapsedMS / 1000, 0.25));
        flightClock.current = group.elapsed;
        bloodLayer.clear();
        group.outbreak?.decals.draw(group.elapsed, camera, (x: number, y: number, rx: number, ry: number, angle: number, alpha: number, dark: boolean) => {
          const points: number[] = [];
          const cos = Math.cos(angle);
          const sin = Math.sin(angle);
          const [sx, sy] = project([x, y], camera);
          for (let vertex = 0; vertex < 8; vertex++) {
            const theta = vertex * Math.PI / 4;
            const u = Math.cos(theta) * rx;
            const v = Math.sin(theta) * ry;
            points.push(sx + (u * cos - v * sin) * camera.zoom, sy + (u * sin + v * cos) * camera.zoom);
          }
          bloodLayer.poly(points).fill({ color: dark ? 0x471719 : 0x963333, alpha });
        });
        if (group.defense) {
          shotLayer.clear();
          for (const [index, soldier] of group.defense.soldiers.entries()) {
            if (soldier.state === 'lost' || soldier.state === 'aboard') continue;
            const selected = selectedRef.current.includes(index);
            const [sx, sy] = project([soldier.x, soldier.y], camera);
            shotLayer.circle(sx, sy, selected ? 6.2 : 3.8).stroke({ color: selected ? 0xffd685 : soldier.reloadUntil ? 0xffc88d : soldier.type === 'medic' ? 0xe8a5c7 : soldier.type === 'sniper' ? 0x99cbe4 : 0xb7e0ba, width: 1.2 });
            if (soldier.type === 'medic' && camera.zoom >= 2) {
              shotLayer.moveTo(sx - 2, sy - 8).lineTo(sx + 2, sy - 8).moveTo(sx, sy - 10).lineTo(sx, sy - 6)
                .stroke({ color: 0xe8a5c7, width: 1.2 });
            }
          }
          for (const shot of group.defense.shots) {
            const trace = bulletTrace(shot, group.elapsed, camera);
            if (trace.flash) {
              const dx = Math.cos(trace.angle) * trace.flashSize;
              const dy = Math.sin(trace.angle) * trace.flashSize;
              shotLayer.poly([trace.x, trace.y, trace.x + 2 * dx - dy, trace.y + 2 * dy + dx,
                trace.x + 3 * dx, trace.y + 3 * dy, trace.x + 2 * dx + dy, trace.y + 2 * dy - dx])
                .fill({ color: 0xffdf9a, alpha: 0.85 });
            }
            if (trace.shellImpact !== undefined) {
              const radius = (2 + trace.shellImpact * 18) * Math.max(1, camera.zoom / 2);
              shotLayer.circle(trace.headX, trace.headY, radius).fill({ color: 0xf29348, alpha: Math.max(0, 1 - trace.shellImpact * 2.3) });
              shotLayer.circle(trace.headX, trace.headY, radius * 1.45).stroke({ color: 0xe9b47a, width: 1.7, alpha: Math.max(0, .85 - trace.shellImpact * 2) });
              continue;
            }
            shotLayer.moveTo(trace.tailX, trace.tailY).lineTo(trace.headX, trace.headY)
              .stroke({ color: 0xffe7a1, alpha: 0.62, width: shot.shell ? 2.7 : 0.9 });
          }

        }
        densityLayer.visible = densityEnabled.current;
        const sample = Math.floor(group.elapsed * 4);
        if (densityLayer.visible && (densityGroup !== group || densityCamera !== camera || densitySample !== sample)) {
          densityCamera = camera;
          densityGroup = group;
          densitySample = sample;
          densityLayer.clear();
          drawDensity(group, camera, (x, y, radius, crowded) => {
            densityLayer.circle(x, y, radius).fill({ color: densityColors[Number(crowded)], alpha: crowded ? 0.48 : 0.32 });
          });
        }
        const nextRoutes = group.status === 'ready' ? group.routes : undefined;
        if (routes !== nextRoutes || (nextRoutes && routeCamera !== camera)) {
          routes = nextRoutes;
          routeCamera = camera;
          drawRoutes(layer, nextRoutes ? group.trails().map(trail => trail.map(point => project(point, camera))) : []);
        }
        const lowDetail = dotsMode.current;
        if (!lowDetail && !modelLayers) {
          modelLayers = (civilianAtlases ??= drawCivilianAtlases()).map((sheet, index) =>
            actorLayer(sheet, Math.min(framesPerAtlas, atlasFrameCount - index * framesPerAtlas),
              civilianCell, civilianCellHeight, false));
        }
        dotLayer.layer.visible = lowDetail;
        for (const models of modelLayers ?? []) models.layer.visible = !lowDetail;
        const layers = lowDetail ? [dotLayer] : modelLayers!;
        const [worldX, worldY] = project([0, 0], camera);
        markerLayer.layer.visible = !lowDetail;
        markerLayer.layer.position.set(worldX, worldY);
        markerLayer.layer.scale.set(camera.zoom);
        const markerScale = infectedMarkerSize(camera.zoom) / (markerSize * camera.zoom);
        let markerCount = 0;
        const counts = layers.map(({layer}) => {
          layer.position.set(worldX, worldY);
          layer.scale.set(camera.zoom);
          return 0;
        });
        const previousCounts = layers.map(({layer}) => layer.particleChildren.length);
        forEachRunner(group, camera, lowDetail, (x, y, frame, scale = 1, rotation = 0, infectedMarker) => {
          const page = lowDetail ? 0 : Math.floor(frame / framesPerAtlas);
          const { layer: crowdLayer, frames, pool } = layers[page];
          const texture = frames[frame % framesPerAtlas];
          const index = counts[page]++;
          const actor = pool[index] ??= new Particle({
            texture,
            anchorX: lowDetail ? .5 : civilianAnchor[0], anchorY: lowDetail ? .5 : civilianAnchor[1],
          });
          actor.x = x;
          actor.y = y;
          actor.texture = texture;
          actor.rotation = rotation;
          actor.scaleX = actor.scaleY = lowDetail ? 1 / camera.zoom : runnerScale * scale;
          crowdLayer.particleChildren[index] = actor;
          if (infectedMarker !== undefined) {
            const markerTexture = markerLayer.frames[infectedMarker];
            const marker = markerLayer.pool[markerCount] ??= new Particle({
              texture: markerTexture, anchorX: .5, anchorY: .3,
            });
            marker.x = x;
            marker.y = y;
            marker.texture = markerTexture;
            marker.scaleX = marker.scaleY = markerScale;
            markerLayer.layer.particleChildren[markerCount++] = marker;
          }
        });
        if (markerLayer.layer.particleChildren.length !== markerCount) {
          markerLayer.layer.particleChildren.length = markerCount;
          markerLayer.layer.update();
        }
        layers.forEach(({layer}, index) => {
          if (previousCounts[index] !== counts[index]) {
            layer.particleChildren.length = counts[index];
            layer.update();
          }
        });
      });
    }).catch(() => {
      if (active) useCanvasFallback();
    });

    return () => {
      active = false;
      observer.disconnect();
      panel.removeEventListener('wheel', wheel);
      cancelAnimationFrame(animation);
      if (app.renderer && started) {
        releaseTextures();
        app.destroy(true, { children: true });
      }
    };
  }, [data, overview]);

  function mapPoint(clientX: number, clientY: number): Point {
    const bounds = map.current!.getBoundingClientRect();
    const camera = view.current;
    const x = clientX - bounds.left - bounds.width / 2;
    const y = clientY - bounds.top - bounds.height / 2;
    const radians = angleRef.current * Math.PI / 180;
    const depth = bounds.height * 1.75;
    const sin = Math.sin(radians);
    const planeY = y / (Math.cos(radians) + y * sin / depth);
    return [x * (1 - planeY * sin / depth) + camera.width / 2, planeY + camera.height / 2];
  }

  function localPoint(event: React.PointerEvent<HTMLDivElement>): Point {
    return mapPoint(event.clientX, event.clientY);
  }

  function setAngle(angle: number) {
    angleRef.current = angle;
    setTilt(angle);
  }

  function unitAt(point: Point, camera: Camera, soldiers: Defense['soldiers']) {
    let nearest: { index: number; distance: number } | undefined;
    soldiers.forEach((soldier, index) => {
      if (soldier.state !== 'patrol' || soldier.carrier !== undefined) return;
      const [x, y] = project([soldier.x, soldier.y], camera);
      const dx = point[0] - x, dy = point[1] - y;
      const width = vehicleWidth(soldier.type);
      const heading = soldier.hullHeading ?? soldier.heading;
      const along = Math.cos(heading) * dx + Math.sin(heading) * dy;
      const across = Math.cos(heading) * dy - Math.sin(heading) * dx;
      const depth = Math.max(width ? 16 : 11, width * camera.zoom * 1.5);
      const halfWidth = Math.max(width ? 12 : 11, width * camera.zoom * .65);
      const distance = Math.hypot(along / depth, across / halfWidth);
      if (distance <= 1 && (!nearest || distance < nearest.distance)) nearest = { index, distance };
    });
    return nearest;
  }

  const labelStyle = (point: Point) => {
    const [x, y] = project(point, camera);
    return { left: x, top: y };
  };

  const placedPins: Point[] = [];
  function spawnPins(kind: 'civilians' | 'zombies', markers: SpawnMarker[]) {
    return markers.map(({ position, count, removable }, index) => {
      const zombie = kind === 'zombies';
      const label = `${zombie ? 'Zombie' : 'Civilian'} spawn ${index + 1}`;
      const canRemove = removable && selection === kind;
      const content = <>
        <span className="waypoint-glyph"><Icon name={canRemove ? 'close' : zombie ? 'alert' : 'crosshair'} size={17} /></span>
        <span>{label} · {count.toLocaleString()}</span>
      </>;
      const className = `waypoint spawn-marker ${zombie ? 'outbreak-origin' : 'pickup'}`;
      const key = position.join(',');
      const [left, top] = project(position, camera);
      let lift = 0;
      while (lift < 90 && top - lift > 60 && placedPins.some(([x, y]) => Math.abs(x - left) < 142 && Math.abs(y - top + lift) < 26)) lift += 30;
      placedPins.push([left, top - lift]);
      const style = { left, top: top - lift, '--spawn-lift': `${lift}px` } as CSSProperties;
      return canRemove
        ? <button key={key} className={`${className} removable`} style={style}
            aria-label={`Remove ${label.toLowerCase()}`} onClick={() => onRemoveSpawn(kind, index)}>{content}</button>
        : <div key={key} className={className} style={style}>{content}</div>;
    });
  }

  const scaleMeters = [500, 250, 100, 50, 25, 10, 5].find(meters => meters * camera.zoom <= 120) ?? 5;
  const fullscreen = screen !== 'window';
  const fullscreenLabel = fullscreen ? 'Exit fullscreen' : 'Fullscreen map';
  const closeView = camera.zoom >= 0.37;

  return (
    <div className={`map ${night ? 'map-night ' : ''}${screen === 'viewport' ? 'map-viewport-expanded' : ''}`} ref={map} aria-label="Interactive street map of Venice">
      <div className="map-world" ref={world} style={{ width: `${100 + tilt * 1.45}%`, height: `${100 + tilt * 2.6}%`,
        transform: `perspective(${(map.current?.clientHeight || 750) * 1.75}px) rotateX(${tilt}deg)` }}>
      <div className="map-surface" data-following={!!followedUnit} ref={surface} />
      <canvas className="map-fallback" ref={fallback} hidden />
      <div className="map-grid" />
      <div
        className={`map-input${commandMode ? ' commanding' : ''}${selection ? ' selecting' : ''}`}
        tabIndex={0}
        aria-label="Map viewport. Use the arrow keys to pan."
        onKeyDown={event => {
          if (event.target !== event.currentTarget) return;
          if (event.key === 'Escape' && selection) {
            event.preventDefault();
            onCancelPlacement();
            return;
          }
          const directions: Record<string, Point> = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
          const direction = directions[event.key];
          if (!direction) return;
          event.preventDefault();
          const current = view.current;
          update({ ...current, x: current.x + direction[0] * 64 / current.zoom, y: current.y + direction[1] * 64 / current.zoom });
        }}
        onPointerDown={event => {
          if (event.button !== 0 || (event.target as HTMLElement).closest('button')) return;
          if (canCommand && !selection) event.currentTarget.focus({ preventScroll: true });
          if (canCommand && !selection && event.shiftKey) {
            const point = localPoint(event);
            selectionDrag.current = point;
            setSelectionBox([point, point]);
            event.currentTarget.setPointerCapture(event.pointerId);
            return;
          }
          const current = view.current;
          drag.current = { origin: localPoint(event), x: current.x, y: current.y, moved: false };
          event.currentTarget.setPointerCapture(event.pointerId);
        }}
        onPointerMove={event => {
          if (selectionDrag.current) {
            setSelectionBox([selectionDrag.current, localPoint(event)]);
            return;
          }
          if (selection === 'support' && !drag.current) setSupportCursor(unproject(localPoint(event), view.current));
          if (selection === 'barricade' && barricadeStart && !drag.current) {
            const [x, y] = unproject(localPoint(event), view.current);
            setBarricadeCursor([Math.round(x * 10) / 10, Math.round(y * 10) / 10]);
          }
          if (!drag.current) return;
          const [x, y] = localPoint(event);
          const dx = x - drag.current.origin[0];
          const dy = y - drag.current.origin[1];
          if (Math.hypot(dx, dy) > 5) drag.current.moved = true;
          if (!drag.current.moved) return;
          setFollowing(undefined);
          const current = view.current;
          update({ ...current, x: drag.current.x - dx / current.zoom, y: drag.current.y - dy / current.zoom });
        }}
        onPointerUp={event => {
          const end = localPoint(event);
          const start = selectionDrag.current;
          const moved = drag.current?.moved || (drag.current && Math.hypot(end[0] - drag.current.origin[0], end[1] - drag.current.origin[1]) > 5);
          if (!start && !drag.current) return;
          drag.current = null;
          selectionDrag.current = undefined;
          if (start) setSelectionBox(undefined);
          if (moved) return;
          const point = unproject(end, view.current);
          if (selection) {
            onPlace(point);
            return;
          }
          if (!canCommand) return;
          const group = latest.current.frame(0);
          const troops = group.defense?.soldiers ?? [];
          if (start && Math.hypot(end[0] - start[0], end[1] - start[1]) > 5) {
            const picked = troops.flatMap((soldier, index) => {
              if (soldier.state !== 'patrol' || soldier.carrier !== undefined) return [];
              const [x, y] = project([soldier.x, soldier.y], view.current);
              return x >= Math.min(start[0], end[0]) && x <= Math.max(start[0], end[0])
                && y >= Math.min(start[1], end[1]) && y <= Math.max(start[1], end[1]) ? [index] : [];
            });
            selectedRef.current = [...new Set([...selectedRef.current, ...picked])];
          } else {
            const hit = unitAt(end, view.current, troops);
            if (hit && !start && commandMode === 'patrol' && troops[hit.index].type === 'carrier'
              && !selectedRef.current.includes(hit.index) && selectedRef.current.length) {
              const ordered = group.defense?.boardCarrier(selectedRef.current, troops[hit.index], group.bridgeMask) ?? 0;
              if (ordered) {
                selectedRef.current = [hit.index];
                setSelectedTroops([hit.index]);
                setCommandMessage(`${ordered} troops ordered to board`);
                return;
              }
            }
            if (hit && (start || !selectedRef.current.includes(hit.index))) {
              selectedRef.current = !start ? [hit.index] : selectedRef.current.includes(hit.index)
                ? selectedRef.current.filter(index => index !== hit.index) : [...selectedRef.current, hit.index];
            } else if (commandMode && selectedRef.current.length && !start) {
              const result = commandMode === 'rescue' ? group.orderRescue(selectedRef.current, point, 16, returnAfterRescue) : group.orderPatrol(selectedRef.current, point);
              setCommandMessage(commandMode === 'rescue'
                ? result?.assigned ? `${result.assigned} assigned to rescue` : 'Choose a civilian group on the map.'
                : result?.assigned ? `${result.assigned} assigned to patrol${result.blocked ? ` · ${result.blocked} blocked` : ''}`
                  : result?.blocked ? 'No vehicle route. Choose a connected street or square wide enough for it.' : 'Choose a walkable patrol point.');
              return;
            }
          }
          setSelectedTroops(selectedRef.current);
          setCommandMessage('');
          if (selectedRef.current.length) setCommandMode(mode => mode ?? 'patrol');
        }}
        onPointerLeave={() => setBarricadeCursor(null)}
        onPointerCancel={() => { drag.current = null; selectionDrag.current = undefined; setSelectionBox(undefined); }}
      >
        {ready && overview.labels.map(([name, x, y]) => (
          <span className="district-label surrounding-label" style={labelStyle([x, y])} key={name}>{name}</span>
        ))}
        {ready && closeView && data.labels.districts.map(([name, x, y]) => (
          <span className="district-label" style={labelStyle([x, y])} key={name}>{name}</span>
        ))}
        {ready && closeView && data.labels.landmarks.map(([name, x, y]) => (
          <span className="landmark-label" style={labelStyle([x, y])} key={name}>{name}</span>
        ))}
        {ready && closeView && <span className="canal-label" style={labelStyle([976, 1240])}>Canal Grande</span>}
        {ready && data.crossings.map(crossing => (
          <button
            className={`crossing-marker ${crossing.id} ${closed.has(crossing.id) ? 'closed' : ''}`}
            style={labelStyle(crossing.position)}
            key={crossing.id}
            aria-label={`${closed.has(crossing.id) ? 'Open' : 'Close'} ${crossing.name} on map`}
            title={crossing.name}
            onClick={() => onCrossing(crossing.id)}
          >
            <span className="crossing-glyph"><Icon name={closed.has(crossing.id) ? 'close' : 'bridge'} size={16} /></span>
            {closeView && <span className="crossing-name">{crossing.id}</span>}
          </button>
        ))}
        {ready && spawnPins('civilians', civilianSpawns)}
        {ready && rescueMarkers.map(({ point, count, injured }, index) => <button type="button" key={index} className="rescue-marker"
          style={labelStyle(point)} disabled={!canCommand} onClick={() => {
            const result = latest.current.frame(0).quickRescue(point, selectedRef.current, returnAfterRescue);
            setCommandMode('rescue');
            setCommandMessage(result?.assigned ? `${result.assigned} assigned to rescue` : 'No available ground squad for this rescue.');
          }}>
          <Icon name="people" size={15} /> {canCommand ? 'Rescue' : 'Stranded'} · {count}{injured ? ` · ${injured} injured` : ''}
        </button>)}
        {ready && clearance?.sectors.map(sector => <div key={sector.name} className={`clearance-sector ${sector.secured ? 'secured' : ''}`}
          style={{ ...labelStyle(sector.point), width: sectorRadius * camera.zoom * 2, height: sectorRadius * camera.zoom * 2 }}>
          <div><strong>{sector.name}</strong><span>{sector.secured ? 'Relief in position' : sector.remaining
            ? `${sector.remaining} infected` : `Hold · ${Math.max(0, Math.ceil(reliefSeconds - sector.held))}s`}</span></div>
        </div>)}
        {ready && deployments && !clearance && <div aria-hidden="true" className={`evac-zone ${defensePhase ?? 'defend'}`}
          style={{ ...labelStyle(end), width: zoneRadius * 2 * camera.zoom, height: zoneRadius * 2 * camera.zoom }} />}
        {ready && <svg className="zone-blockades" width={camera.width} height={camera.height} aria-label="Barricades">
          {gates?.map((gate, index) => {
            const [x, y] = project(gate.position, camera);
            const data = coverage?.[index];
            return <g key={index}>
              {gate.windupUntil !== undefined && elapsed < gate.windupUntil && <text className="slam-warning" x={x} y={y - 17} textAnchor="middle">Mutant windup</text>}
              {gate.slamAt !== undefined && elapsed - gate.slamAt < .6 && <circle className="slam-impact" cx={x} cy={y} r={8 + (elapsed - gate.slamAt) * 35} />}
              <g className={gate.slamAt !== undefined && elapsed - gate.slamAt < .6 ? "gate-shake" : undefined}><BarricadeModel gate={gate} camera={camera} index={index} /></g>
              {showCoverage && <text className="guard-coverage" x={x} y={y - 10} textAnchor="middle">
                {data ? `${data.guards} nearby · ${data.integrity}%` : 'Troop coverage starts at dispatch'}
              </text>}
            </g>;
          })}
          {selection === 'barricade' && barricadeStart && (() => {
            const [x, y] = project(barricadeStart, camera);
            if (!barricadeCursor) return <circle className="barricade-anchor" cx={x} cy={y} r={4} />;
            const [endX, endY] = project(barricadeCursor, camera);
            const meters = Math.hypot(endX - x, endY - y) / camera.zoom;
            const cost = barricadeCost([barricadeStart, barricadeCursor]);
            const valid = meters >= minBarricadeLength && meters <= maxBarricadeLength && cost <= barricadeCredits;
            const gaps = valid ? inspectGaps([barricadeStart, barricadeCursor]) : [];
            return <g className={`barricade-preview ${valid ? '' : 'invalid'}`}>
              <line x1={x} y1={y} x2={endX} y2={endY} />
              <circle className="barricade-anchor" cx={x} cy={y} r={4} />
              {gaps.map(point => {
                const [gapX, gapY] = project(point, camera);
                return <circle key={point.join(',')} className="barricade-gap" cx={gapX} cy={gapY} r={5} />;
              })}
              <text x={(x + endX) / 2} y={(y + endY) / 2 - 9} textAnchor="middle">
                {meters.toFixed(1)} m · {cost} credits{valid && (gaps.length ? ` · ${gaps.length} open ${gaps.length === 1 ? 'end' : 'ends'}` : ' · ends covered')}
              </text>
            </g>;
          })()}
        </svg>}
        {ready && !selection && defensePhase !== 'departed' && gates?.map((gate, index) => {
          if (gate.integrity <= 0) return null;
          if (gate.locked) {
            let alternate = -1;
            let nearest = Infinity;
            for (const [otherIndex, other] of gates.entries()) {
              if (other === gate || other.locked || other.integrity <= 0) continue;
              const distance = Math.hypot(other.position[0] - gate.position[0], other.position[1] - gate.position[1]);
              if (distance >= nearest) continue;
              nearest = distance;
              alternate = otherIndex;
            }
            return <div key={index} className="gate-toggle locked gate-report" style={labelStyle(gate.position)}>
              <strong>Gate {index + 1} locked</strong>
              <span>{gate.nearbyInfected} infected · {gateQueues.get(index) ?? 0} civilians outside</span>
              <span>{alternate >= 0 ? `Nearest unlocked: Gate ${alternate + 1} · ${Math.round(nearest)} m straight-line` : 'No other unlocked gate'}</span>
            </div>;
          }
          return <button key={index} className={`gate-toggle ${gate.open ? 'open' : ''}`} style={labelStyle(gate.position)}
            aria-label={`${gate.open ? 'Close' : 'Open'} barricade gate ${index + 1}`}
            title={gate.open ? 'Close gate' : 'Open gate'} onClick={() => onToggleGate(index)}>
            {gate.open ? 'Open' : 'Closed'}
          </button>;
        })}
        {ready && aircraft.length > 0 &&
          <EvacuationFlight passengers={evacuatedPassengers} aircraft={aircraft} elapsed={elapsed} camera={camera} departed={defensePhase === 'departed'} />}
        {ready && !clearance && <div className={`waypoint evacuation ${defensePhase ?? ''}`} style={labelStyle(end)}><span className="waypoint-glyph"><Icon name={deployments ? 'transport' : 'exit'} size={18} /></span>
          <span>{defensePhase === 'departed' ? (evacuatedPassengers ? 'Helicopters departed' : 'Extraction ended') : deployments ? 'Extraction transport' : 'Evacuation'}</span></div>}
        {ready && !clearance && spawnPins('zombies', zombieSpawns)}
        {ready && deployments?.map(({ position, type, roof }, index) => (
          <button key={index} className={`soldier-pin ${type}`} title={roof ? `Sniper · estimated ${roof.height} m rooftop` : type} style={labelStyle(position)} disabled={selection !== 'soldiers'}
            aria-label={`Remove ${type} deployment ${index + 1}`} onClick={() => onRemoveSpawn('soldiers', index)}>{index + 1}</button>
        ))}
      </div>
      {selectionBox && <div className="troop-selection" style={{
        left: Math.min(selectionBox[0][0], selectionBox[1][0]), top: Math.min(selectionBox[0][1], selectionBox[1][1]),
        width: Math.abs(selectionBox[0][0] - selectionBox[1][0]), height: Math.abs(selectionBox[0][1] - selectionBox[1][1]),
      }} />}
      {ready && outbreakActive && <CanalLights camera={camera} data={data} overview={overview} />}
      {canCommand && commandMode && patrols.length > 0 && <PatrolOverlay patrols={patrols} camera={camera} />}
      {ready && !!groundFires?.length && <GroundFires fires={groundFires} elapsed={elapsed} camera={camera} />}
      {ready && selection === 'support' && supportStart && <SupportAim start={supportStart} cursor={supportCursor} type={supportType} camera={camera} />}
      {ready && supportRuns.length > 0 && <AirSupportOverlay runs={supportRuns} clock={flightClock} camera={camera} />}
      </div>
      {canCommand && commandMode && selectedTroops.length === 1 && defense?.soldiers[selectedTroops[0]]?.type === 'carrier' &&
        <div className="carrier-controls"><span>{defense.passengers(defense.soldiers[selectedTroops[0]]).length}/6 aboard</span>
          <button disabled={!defense.passengers(defense.soldiers[selectedTroops[0]]).length} onClick={() => {
            const group = latest.current.frame(0);
            const count = defense.unloadCarrier(defense.soldiers[selectedTroops[0]], group.bridgeMask);
            setCommandMessage(`${count} troops unloaded`);
          }}>Unload troops</button>
        </div>}
      {canCommand && commandMode && <div className="command-hint" role="status">
        {blockedPatrols > 0 && <strong className="patrol-warning">{blockedPatrols} {blockedPatrols === 1 ? 'troop has' : 'troops have'} a blocked route. {patrols.some(patrol => patrol.obstruction) ? 'Barricade marked on map.' : 'Check street and bridge access.'}</strong>}
        {patrols.some(patrol => patrol.rescue?.escort) && <strong className="escort-radio">Squad escorting civilians to extraction.</strong>}
        {commandMessage || (selectedTroops.length ? `${selectedTroops.length} selected${selectedTroops.length === 1 && defense?.soldiers[selectedTroops[0]]?.type === 'tank' ? ' · M1 Abrams' : ''} · Click ${commandMode === 'rescue' ? 'a civilian group' : 'a patrol point'}` : 'Click a unit or Shift-drag to select several. Drag to pan.')}
        {defense && selectedTroops.some(index => defense.soldiers[index]?.type === 'medic') && <span className="escort-radio">
          Medic supplies remaining · {selectedTroops.reduce((total, index) => total + (defense.soldiers[index]?.supplies ?? 0), 0)}
        </span>}
      </div>}
      {placementMessage && <div className="map-placement">
        <div><strong>{selection === 'soldiers' ? 'Click the map to deploy' : selection === 'support' ? (supportStart ? 'Choose flight direction' : 'Mark the impact area') : selection === 'end' ? 'Set evacuation' : selection === 'civilians' || selection === 'zombies' ? 'Place a spawn point' : barricadeStart ? 'Choose the second endpoint' : 'Choose the first endpoint'}</strong>
          <span role="status">{placementMessage}</span></div>
        <button type="button" onClick={onCancelPlacement}>Done</button>
      </div>}
      {!ready && <p className="map-loading">{error ? 'This browser could not render the map.' : 'Loading Venice map…'}</p>}
      {hud}
      {followedUnit && <button className="follow-status" onClick={() => setFollowing(undefined)}>Following unit · Stop</button>}
      {dots && <div className="dot-legend" role="region" aria-label="Dot colors" tabIndex={0}>
        {dotColors.map(([label, color]) => <span key={label}><i style={{backgroundColor: color}} />{label}</span>)}
      </div>}
      <div className="map-utilities" aria-label="Map controls">
        <button className="fullscreen-button" title={fullscreenLabel} aria-label={fullscreenLabel} aria-pressed={fullscreen} onClick={toggleFullscreen}><Icon name={fullscreen ? 'collapse' : 'expand'} size={19} /></button>
        <details className="view-tools">
          <summary aria-label="Map options" title="Map options"><Icon name="crosshair" size={19} /></summary>
          <div className="view-options">
            <div className="view-display">
              <button type="button" aria-pressed={dots} onClick={toggleDots}>{dots ? 'Dots · Performance' : 'Models'}</button>
              {!dots && outbreakActive && <small>Red ring · Zombie<br />Pink diamond · Mutant</small>}
              <label>Map angle <output>{tilt}°</output><input aria-label="Map angle" type="range" min="0" max="45" step="5" value={tilt}
                onChange={event => setAngle(Number(event.currentTarget.value))} /></label>
              <button type="button" disabled={selectedTroops.length !== 1} aria-pressed={!!followedUnit}
                onClick={() => {
                  if (followedUnit) { setFollowing(undefined); return; }
                  const index = selectedTroops[0];
                  const soldier = defense?.soldiers[index];
                  if (!soldier) return;
                  setFollowing(index);
                  setAngle(Math.max(tilt, 40));
                  update({ ...view.current, x: soldier.x, y: soldier.y, zoom: 8 });
                }}>Follow selected unit</button>
            </div>
        <button title="Zoom in" aria-label="Zoom in" onClick={() => zoom(1.26)}><Icon name="plus" /></button>
        <button title="Zoom out" aria-label="Zoom out" onClick={() => zoom(1 / 1.26)}><Icon name="minus" /></button>
        <button title="Street view" aria-label="Street view" onClick={streetView}><Icon name="person" size={18} /></button>
        <button title="Fit route in view" aria-label="Fit route in view" onClick={fitRoute}><Icon name="route" size={18} /></button>
        <button title="Crowd density" aria-label="Crowd density" aria-pressed={showDensity} onClick={() => {
          densityEnabled.current = !showDensity;
          setShowDensity(!showDensity);
        }}><Icon name="people" size={18} /></button>
        <button type="button" title="Emergency sirens" aria-label="Emergency sirens" aria-pressed={soundOn}
          onClick={() => void toggleSound()}><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
            <path d="M4 9v6h4l5 4V5L8 9H4Z" />
            {soundOn ? <path d="M16 8a6 6 0 0 1 0 8m2-11a10 10 0 0 1 0 14" /> : <path d="m16 9 5 6m0-6-5 6" />}
          </svg></button>
        {!!gates?.length && <button title="Guard coverage" aria-label="Guard coverage" aria-pressed={showCoverage}
          onClick={() => setShowCoverage(value => !value)}><Icon name="guard" size={19} /></button>}
        <button title="Reset map view" aria-label="Reset map view" onClick={() => { setFollowing(undefined); setAngle(0); update(initialView(camera.width, camera.height)); }}><Icon name="crosshair" /></button>
          </div>
        </details>
      </div>
      {commandBar(canCommand && <>
        {canCommand && <button title="Patrol orders" aria-label="Patrol orders" aria-pressed={commandMode === 'patrol'}
          onClick={() => { setCommandMessage(''); setCommandMode(value => value === 'patrol' ? null : 'patrol'); }}><Icon name="route" size={17} /><span>Patrol</span></button>}
        {canCommand && !clearance && <button title="Rescue orders" aria-label="Rescue orders" aria-pressed={commandMode === 'rescue'}
          onClick={() => { setCommandMessage(''); setCommandMode(value => value === 'rescue' ? null : 'rescue'); }}><Icon name="people" size={17} /><span>Rescue</span></button>}
        <details className="command-menu" name="rialto-command-menu">
          <summary><Icon name="guard" size={17} /><span>Squads</span></summary>
          <section className="command-sheet" aria-label="Squads">
            <h2>Squads</h2>
            <p className="scenario-brief">Select troops, then save them to a slot. Press 1–3 to recall a squad, or Shift+1–3 to save it.</p>
            {squads.map((squad, slot) => <div className="squad-slot spawn-actions" key={slot}>
              <span>Squad {slot + 1} · {squad.length ? `${squad.length} saved` : 'Empty'}</span>
              <button type="button" disabled={!squad.length} onClick={() => useSquad(slot, false)}>Recall {slot + 1}</button>
              <button type="button" disabled={!selectedTroops.length} onClick={() => useSquad(slot, true)}>Save {slot + 1}</button>
            </div>)}
            {!clearance && <label className="lockdown-setting">
              <input type="checkbox" checked={returnAfterRescue} onChange={event => setReturnAfterRescue(event.currentTarget.checked)} />
              Resume previous patrol after rescue
            </label>}
          </section>
        </details>
      </>)}
      <details className="map-attribution">
        <summary>Map credits</summary>
        <div><a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">© OpenStreetMap contributors</a>
          <a href="https://openfreemap.org/" target="_blank" rel="noreferrer">OpenFreeMap</a>
          <a href="https://openmaptiles.org/" target="_blank" rel="noreferrer">© OpenMapTiles</a></div>
      </details>
      {showDensity && <div className="density-legend"><span /> Crowded <span /> Packed</div>}
      <div className="map-scale"><span style={{ width: scaleMeters * camera.zoom }} />{scaleMeters} m</div>
    </div>
  );
}
