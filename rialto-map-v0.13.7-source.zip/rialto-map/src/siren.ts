export function soundSiren(context: AudioContext) {
  const time = context.currentTime;
  const gain = context.createGain();
  const filter = context.createBiquadFilter();
  const oscillator = context.createOscillator();
  oscillator.type = 'triangle';
  filter.frequency.value = 950;
  gain.gain.setValueAtTime(0.001, time);
  gain.gain.exponentialRampToValueAtTime(0.055, time + 0.25);
  gain.gain.exponentialRampToValueAtTime(0.001, time + 2.7);
  oscillator.frequency.setValueAtTime(350, time);
  oscillator.frequency.linearRampToValueAtTime(740, time + 1);
  oscillator.frequency.linearRampToValueAtTime(370, time + 2.7);
  oscillator.connect(filter).connect(gain).connect(context.destination);
  oscillator.onended = () => {
    oscillator.disconnect();
    filter.disconnect();
    gain.disconnect();
  };
  oscillator.start(time);
  oscillator.stop(time + 2.8);
}

export function soundImpact(context: AudioContext) {
  const now = context.currentTime;
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  oscillator.type = 'triangle';
  oscillator.frequency.setValueAtTime(92, now);
  oscillator.frequency.exponentialRampToValueAtTime(32, now + .33);
  gain.gain.setValueAtTime(.24, now);
  gain.gain.exponentialRampToValueAtTime(.001, now + .38);
  oscillator.connect(gain).connect(context.destination);
  oscillator.start();
  oscillator.stop(now + .4);
  oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
}
