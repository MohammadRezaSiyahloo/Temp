import type { Label, Point, Venice } from './routing.ts';

export type Bounds = [left: number, top: number, right: number, bottom: number];
export type Camera = { x: number; y: number; zoom: number; width: number; height: number };
type Land = Record<'parks' | 'buildings' | 'streets' | 'bridges', Point[][]>;

export interface Overview extends Land {
  bounds: Bounds;
  water: Point[][][];
  labels: Label[];
}

type Viewport = { width: number; height: number; x: number; y: number; scale: number };
const featureBounds = new WeakMap<Point[], Bounds>();
const roofs = ['#6a665b', '#5e5d55', '#6a6055', '#777064', '#615d52', '#706b60', '#64635d', '#797265'];

export function limitCamera(camera: Camera, [left, top, right, bottom]: Bounds): Camera {
  const minimum = Math.max(0.14, camera.width / (right - left), camera.height / (bottom - top));
  const zoom = Math.max(minimum, Math.min(9, camera.zoom));
  const dx = camera.width / (2 * zoom);
  const dy = camera.height / (2 * zoom);
  return {
    ...camera,
    zoom,
    x: Math.max(left + dx, Math.min(right - dx, camera.x)),
    y: Math.max(top + dy, Math.min(bottom - dy, camera.y)),
  };
}

function boundsOf(points: Point[]): Bounds {
  const cached = featureBounds.get(points);
  if (cached) return cached;
  const bounds: Bounds = [Infinity, Infinity, -Infinity, -Infinity];
  for (const [x, y] of points) {
    bounds[0] = Math.min(bounds[0], x);
    bounds[1] = Math.min(bounds[1], y);
    bounds[2] = Math.max(bounds[2], x);
    bounds[3] = Math.max(bounds[3], y);
  }
  featureBounds.set(points, bounds);
  return bounds;
}

function trace(path: CanvasRenderingContext2D | Path2D, points: Point[]) {
  path.moveTo(...points[0]);
  for (let i = 1; i < points.length; i++) path.lineTo(...points[i]);
}

function signedArea(points: Point[]) {
  let area = 0;
  for (let i = 1; i < points.length; i++) {
    const [x, y] = points[i - 1];
    const [nextX, nextY] = points[i];
    area += x * nextY - nextX * y;
  }
  return area;
}

function addRing(path: Path2D, ring: Point[], hole = false) {
  const reverse = (signedArea(ring) < 0) !== hole;
  trace(path, reverse ? [...ring].reverse() : ring);
  path.closePath();
}

export function drawAtlas(data: Venice, overview: Overview, view?: Viewport) {
  const [width, height] = data.size;
  const [left, top, right, bottom] = overview.bounds;
  const chartWidth = right - left;
  const chartHeight = bottom - top;
  const density = view?.scale ?? 3800 / Math.max(chartWidth, chartHeight);
  const x = view?.x ?? -left * density;
  const y = view?.y ?? -top * density;
  const canvas = document.createElement('canvas');
  canvas.width = Math.ceil(view?.width ?? chartWidth * density);
  canvas.height = Math.ceil(view?.height ?? chartHeight * density);
  const drawingContext = canvas.getContext('2d', { alpha: false });
  if (!drawingContext) throw new Error('Canvas unavailable');
  const context: CanvasRenderingContext2D = drawingContext;
  context.fillStyle = '#182123';
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.setTransform(density, 0, 0, density, x, y);
  context.lineJoin = 'round';
  context.lineCap = 'round';
  const visible: Bounds = [-x / density - 8, -y / density - 8, (canvas.width - x) / density + 8, (canvas.height - y) / density + 8];

  function inView(points: Point[]) {
    const [x1, y1, x2, y2] = boundsOf(points);
    return x1 <= visible[2] && y1 <= visible[3] && x2 >= visible[0] && y2 >= visible[1];
  }

  const terrain = context.createLinearGradient(0, 0, width, height);
  terrain.addColorStop(0, '#424847');
  terrain.addColorStop(0.62, '#393e3d');
  terrain.addColorStop(1, '#303839');
  context.fillStyle = terrain;
  context.fillRect(left, top, chartWidth, chartHeight);

  function fill(points: Point[], color: string, outline?: string, weight = 1) {
    context.beginPath();
    trace(context, points);
    context.closePath();
    context.fillStyle = color;
    context.fill();
    if (!outline) return;
    context.lineWidth = weight;
    context.strokeStyle = outline;
    context.stroke();
  }

  function network(lines: Point[][], weight: number, color: string) {
    context.beginPath();
    for (const line of lines) {
      if (inView(line)) trace(context, line);
    }
    context.lineWidth = weight;
    context.strokeStyle = color;
    context.stroke();
  }

  function drawLand(land: Land, plazas: Point[][] = [], playable = false) {
    for (const park of land.parks) if (inView(park)) fill(park, '#46564b', '#596659', 1);
    for (const plaza of plazas) if (inView(plaza)) fill(plaza, '#716958', '#8b8067', 0.8);
    if (!playable) {
      network(land.streets, 5, '#303737');
      network(land.streets, 2.2, '#66635a');
    }
    for (const building of land.buildings) {
      if (!inView(building)) continue;
      const [x, y] = building[0];
      const color = roofs[Math.abs(Math.round(x * 41 + y * 73)) % roofs.length];
      context.save();
      context.translate(1.7, 2.6);
      fill(building, '#282f30');
      context.restore();
      fill(building, color, '#81796a', 0.7);
    }
    if (playable) {
      network(land.streets, 6.2, '#363b39');
      network(land.streets, 4.8, '#6c685d');
    }
  }

  function clipDistrict(outside: boolean, draw: () => void) {
    context.save();
    context.beginPath();
    if (outside) context.rect(left, top, chartWidth, chartHeight);
    context.rect(0, 0, width, height);
    context.clip('evenodd');
    draw();
    context.restore();
  }

  clipDistrict(true, () => drawLand(overview));
  clipDistrict(false, () => drawLand(data.terrain, data.terrain.plazas, true));

  const water = context.createLinearGradient(0, 0, width, height);
  water.addColorStop(0, '#173b43');
  water.addColorStop(0.55, '#1c424a');
  water.addColorStop(1, '#142e39');
  const waterShapes = new Path2D();
  for (const [outer, ...holes] of overview.water) {
    if (!inView(outer)) continue;
    addRing(waterShapes, outer);
    for (const hole of holes) if (inView(hole)) addRing(waterShapes, hole, true);
  }
  for (const ring of data.terrain.water) if (inView(ring)) addRing(waterShapes, ring);
  context.strokeStyle = '#243437';
  context.lineWidth = 4;
  context.stroke(waterShapes);
  context.strokeStyle = '#63716a';
  context.lineWidth = 1.8;
  context.stroke(waterShapes);
  context.fillStyle = water;
  context.fill(waterShapes);
  context.save();
  context.clip(waterShapes);
  context.strokeStyle = '#3e6b70';
  context.lineWidth = 0.65;
  const lineGap = density < 0.36 ? 24 : density < 0.65 ? 16 : 8;
  const lineStart = Math.max(top, Math.floor((visible[1] - 60) / lineGap) * lineGap);
  const lineEnd = Math.min(bottom + 40, visible[3] + 60);
  context.beginPath();
  for (let lineY = lineStart; lineY < lineEnd; lineY += lineGap) {
    context.moveTo(left, lineY);
    context.lineTo(right, lineY - 40);
  }
  context.stroke();
  context.restore();

  function drawBridges(land: Land, playable = false) {
    network(land.bridges, 5, '#343c3c');
    network(land.bridges, playable ? 4.1 : 2.7, '#aaa08b');
  }
  clipDistrict(true, () => drawBridges(overview));
  clipDistrict(false, () => {
    for (const deck of data.terrain.bridgeDecks) if (inView(deck)) fill(deck, '#888171', '#343c3c', 1.2);
    drawBridges(data.terrain, true);
    if (density >= 1) {
      network(data.terrain.stairs, 3.1, '#655d50');
      context.save();
      context.lineCap = 'butt';
      context.setLineDash([0.3, 0.9]);
      network(data.terrain.stairs, 2.6, '#b2a68a');
      context.restore();
    }
  });

  let seed = 8171;
  function random() {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  }
  context.fillStyle = '#eddfbf12';
  for (let i = 0; i < 34000; i++) {
    const x = random() * width;
    const y = random() * height;
    const size = 0.7 + random() * 1.5;
    if (x >= visible[0] && x <= visible[2] && y >= visible[1] && y <= visible[3]) context.fillRect(x, y, size, 0.65);
  }
  return canvas;
}
