import { isGrass, type GroundFire } from './ground-fire.ts';
import { roofPath, type Rooftop } from './rooftops.ts';
import { cellSize, steps, type CrowdField } from './crowd-field.ts';
import { clearSight, localPath } from './pursuit.ts';
import { aimRunner, moveRunner, runnerTargetOpen, turnToward, type RunnerMotion } from './runner-motion.ts';
import type { Outbreak, Zombie } from './outbreak.ts';
import { Fortifications, gateIntegrity, type Barricade, type ZoneGate } from './fortifications.ts';
import { random } from './spawn-planning.ts';
import type { Point } from './routing.ts';

export const evacuationRadius = 36;
export const maxSquadSize = 160;
export const infantryCost = 100;
export const sniperCost = 240;
export const medicCost = 180;
export const medicSupplies = 5;
export const boardingSeconds = 4;
export const patrolRadius = 8;

export function hiringBudget(civilians: number, infected: number) {
  return 2000 + Math.floor(civilians / 120) * 100 + Math.floor(infected / 60) * 100;
}

export function shotAccuracy(distance: number, range: number) {
  return 0.96 - 0.58 * Math.min(1, distance / range) ** 1.6;
}
export const squadSize = 4;
export const fallbackSeconds = 12;

export const weapons = {
  mounted: { range: 32, interval: 0.24, magazine: 24, reload: 2.8, damage: 1 },
  cannon: { range: 39, interval: 1.8, magazine: 5, reload: 3.1, damage: 4 },
  precision: { range: 48, interval: 1.35, magazine: 5, reload: 2.6, damage: 2 },
  pistol: { range: 9, interval: 0.7, magazine: 8, reload: 1.8, damage: 1 },
  carbine: { range: 23, interval: 0.48, magazine: 12, reload: 2.2, damage: 1 },
} as const;

export const soldierTypes = {
  sniper: { label: 'Sniper', weapon: 'precision', speed: 4.1, patrolSpeed: 0, health: 2 },
  medic: { label: 'Field medic', weapon: 'pistol', speed: 4.05, patrolSpeed: 1.75, health: 3 },
  jeep: { label: 'HMMWV gun truck', weapon: 'mounted', speed: 3.5, patrolSpeed: 2.1, health: 5 },
  carrier: { label: 'Stryker carrier', weapon: 'mounted', speed: 2.8, patrolSpeed: 1.65, health: 9 },
  tank: { label: 'M1 Abrams', weapon: 'cannon', speed: 2.1, patrolSpeed: 1.25, health: 14 },
  infantry: { label: 'SWAT infantry', weapon: 'carbine', speed: 4.25, patrolSpeed: 1.8, health: 3 },
} as const satisfies Record<string, { label: string; weapon: keyof typeof weapons; speed: number; patrolSpeed: number; health: number }>;

export function deploymentUpgrade(type: keyof typeof soldierTypes) {
  return { infantry: 0, sniper: sniperCost - infantryCost, medic: medicCost - infantryCost, jeep: 250, carrier: 450, tank: 800 }[type];
}

export type Deployment = { position: Point; type: keyof typeof soldierTypes; roof?: Rooftop };
export function vehicleWidth(type: Deployment['type']) {
  return type === 'jeep' ? 0.95 : type === 'carrier' ? 1.22 : type === 'tank' ? 1.5 : 0;
}

export const shellBlastRadius = 3.1;

export function vehicleFits(terrain: CrowdField, cell: number, mask: number, type: Deployment['type']) {
  const radius = vehicleWidth(type);
  if (!radius) return true;
  if (!terrain.open(cell, mask)) return false;
  const x = terrain.x(cell), y = terrain.y(cell);
  return [0, 1, 2, 3, 4, 5, 6, 7].every(index => {
    const angle = index * Math.PI / 4;
    return terrain.open(terrain.cell(x + Math.cos(angle) * radius, y + Math.sin(angle) * radius), mask);
  });
}

export type Soldier = RunnerMotion & {
  type: Deployment['type'];
  roofHeight: number;
  carrier?: Soldier;
  boardingCarrier?: Soldier;
  roof?: Rooftop;
  roofPath?: Point[];
  state: 'patrol' | 'fallback' | 'aboard' | 'lost';
  ammo: number;
  reloadUntil: number;
  nextShot: number;
  health: number;
  supplies: number;
  treatingUntil: number;
  returnPatrol?: number;
  rescue?: { cell: number; escort: boolean };
  patrolCenter?: number;
  patrolObstruction?: ZoneGate | null;
  path: number[];
  pathIndex: number;
  retryAt: number;
  nextWound: number;
  seed: number;
  roundsFired: number;
  aimUntil: number;
  aimHeading?: number;
  trackedTarget?: Zombie;
  hullHeading?: number;
  patrolTurn: number;
};

export type Shot = { from: Point; to: Point; start: number; until: number; shell?: boolean };
type Impact = { shot: Shot; target?: Zombie; damage: number; at: number; origin: Point; roofHeight: number };

export class Defense {
  readonly soldiers: Soldier[] = [];
  readonly shots: Shot[] = [];
  readonly center: Point;
  fortifications?: Fortifications;
  overrun = false;
  private exposedFor = 0;
  phase: 'defend' | 'fallback' | 'departed' = 'defend';
  eliminated = 0;
  readonly groundFires: GroundFire[] = [];
  private fireRoll = 0;
  private readonly impacts: Impact[] = [];
  readonly fallbackWindow: number;
  readonly radius: number;
  private readonly startingCount: number;
  reinforcementSpend = 0;
  get count() { return this.started ? this.soldiers.length : this.startingCount; }
  private started = false;
  private readonly seed: number;
  private readonly patrolPaths = new Map<string, number[][]>();
  private baseline?: Uint16Array;
  private rally: Uint16Array = new Uint16Array(0);
  private nextSweep = 0;
  private readonly routes = new Map<string, number[]>();
  private clearanceFlow?: { destination: number; mask: number; field: Uint16Array };
  private readonly nearby = new Map<number, Zombie[]>();
  private readonly terrain: CrowdField;
  private readonly goal: number;
  private readonly duration: number;
  private readonly barricades: readonly Barricade[];
  private readonly clearance: boolean;
  private readonly gateLockdown: boolean;
  private readonly deployments: readonly Deployment[];

  constructor(terrain: CrowdField, goal: number, duration: number, deployments: readonly Deployment[], count = squadSize, radius = evacuationRadius, seed = 0, barricades: readonly Barricade[] = [], gateLockdown = false, clearance = false) {
    this.terrain = terrain;
    this.goal = goal;
    this.duration = duration;
    this.deployments = deployments;
    this.startingCount = count;
    this.radius = radius;
    this.seed = seed;
    this.barricades = barricades;
    this.gateLockdown = gateLockdown;
    this.clearance = clearance;
    this.fallbackWindow = Math.max(fallbackSeconds, Math.ceil(radius * 0.52));
    this.center = [terrain.x(goal), terrain.y(goal)];
  }

  get aboard() { return this.soldiers.filter(soldier => soldier.state === 'aboard').length; }
  get lost() { return this.soldiers.filter(soldier => soldier.state === 'lost').length; }
  get coverage() {
    return (this.fortifications?.gates ?? []).map(gate => ({
      guards: this.active.filter(soldier => Math.hypot(soldier.x - gate.position[0], soldier.y - gate.position[1]) <= 12).length,
      integrity: Math.ceil(gate.integrity / gateIntegrity * 100),
    }));
  }

  gatesChanged() {
    this.routes.clear();
    this.clearanceFlow = undefined;
    this.patrolPaths.clear();
  }

  orderPatrol(indices: Iterable<number>, point: Point, mask: number, rescue = false, returnAfterRescue = false) {
    if (this.phase !== 'defend') return { assigned: 0, blocked: 0, point: undefined };
    const closest = this.terrain.nearest(point, mask, undefined, 6);
    let destination = closest;
    let assigned = 0;
    let blocked = 0;
    for (const index of indices) {
      const soldier = this.soldiers[index];
      if (!soldier || soldier.carrier || soldier.state !== 'patrol' || (rescue && vehicleWidth(soldier.type))) continue;
      if (soldier.roofHeight) {
        const ring = soldier.roof?.ring;
        const route = !rescue && ring ? roofPath([soldier.x, soldier.y], point, ring) : undefined;
        if (route) {
          soldier.roofPath = route;
          assigned++;
        }
        continue;
      }
      const start = soldier.target >= 0 ? soldier.target : soldier.cell;
      let center = closest;
      let path: number[] = [];
      if (vehicleWidth(soldier.type)) {
        const candidates: {cell: number; distance: number}[] = [];
        this.terrain.visitArea(...point, 9, (cell, distance) => {
          if (this.terrain.open(cell, mask) && vehicleFits(this.terrain, cell, mask, soldier.type)) candidates.push({ cell, distance });
        });
        center = -1;
        for (const candidate of candidates.sort((a, b) => a.distance - b.distance).slice(0, 12)) {
          path = this.route(start, candidate.cell, mask, soldier.type);
          if (path.length || start === candidate.cell) {
            center = candidate.cell;
            break;
          }
        }
      } else if (center >= 0) path = this.route(start, center, mask, soldier.type);
      if (center < 0) {
        if (vehicleWidth(soldier.type)) blocked++;
        continue;
      }
      destination = center;
      soldier.returnPatrol = rescue && returnAfterRescue
        ? soldier.rescue ? soldier.returnPatrol ?? start : soldier.patrolCenter ?? start
        : undefined;
      soldier.boardingCarrier = undefined;
      soldier.rescue = rescue ? { cell: center, escort: false } : undefined;
      soldier.patrolCenter = center;
      if (soldier.type === 'tank') {
        soldier.aimHeading = undefined;
        soldier.aimUntil = 0;
      }
      soldier.patrolObstruction = start !== center && !path.length ? this.findObstruction(start, center, mask) : undefined;
      if (soldier.patrolObstruction !== undefined) blocked++;
      soldier.path = path;
      soldier.pathIndex = 0;
      soldier.retryAt = 0;
      assigned++;
    }
    return { assigned, blocked, point: destination < 0 ? point : [this.terrain.x(destination), this.terrain.y(destination)] as Point };
  }

  get active() { return this.soldiers.filter(soldier => soldier.state !== 'aboard' && soldier.state !== 'lost' && !soldier.carrier); }

  passengers(carrier: Soldier) {
    return this.soldiers.filter(soldier => soldier.carrier === carrier);
  }

  boardCarrier(indices: readonly number[], carrier: Soldier, mask: number) {
    if (carrier.type !== 'carrier' || carrier.state !== 'patrol' || this.phase !== 'defend') return 0;
    let available = 6 - this.soldiers.filter(unit => unit.carrier === carrier || unit.boardingCarrier === carrier).length;
    let ordered = 0;
    for (const index of new Set(indices)) {
      const soldier = this.soldiers[index];
      if (!soldier || soldier.state !== 'patrol' || soldier.carrier || soldier.boardingCarrier === carrier || soldier.roofHeight || vehicleWidth(soldier.type) || available <= 0) continue;
      const start = soldier.target >= 0 ? soldier.target : soldier.cell;
      if (start !== carrier.cell && !this.route(start, carrier.cell, mask).length) continue;
      this.orderPatrol([index], [this.terrain.x(carrier.cell), this.terrain.y(carrier.cell)], mask);
      soldier.boardingCarrier = carrier;
      available--;
      ordered++;
    }
    if (ordered) {
      carrier.patrolCenter = carrier.cell;
      if (carrier.target >= 0 && this.terrain.cell(carrier.x, carrier.y) === carrier.target) carrier.cell = carrier.target;
      carrier.target = -1;
      carrier.path = [];
    }
    return ordered;
  }

  unloadCarrier(carrier: Soldier, mask: number) {
    if (carrier.type !== 'carrier' || carrier.state !== 'patrol') return 0;
    const cells: number[] = [];
    this.terrain.visitArea(carrier.x, carrier.y, 4, (cell, distance) => {
      if (distance >= 1 && this.terrain.open(cell, mask)
        && clearSight(this.terrain, carrier.cell, cell, mask)
        && this.fortifications?.insidePickup(cell, carrier.cell) !== false) cells.push(cell);
    });
    if (!cells.length && this.terrain.open(carrier.cell, mask)) cells.push(carrier.cell);
    let count = 0;
    for (const soldier of this.passengers(carrier)) {
      const cell = cells[count % cells.length];
      if (cell === undefined) continue;
      soldier.carrier = undefined;
      soldier.cell = cell;
      soldier.x = this.terrain.x(cell);
      soldier.y = this.terrain.y(cell);
      soldier.target = -1;
      soldier.path = [];
      soldier.patrolCenter = undefined;
      count++;
    }
    return count;
  }

  start(mask: number, flow: Uint16Array, baseline = flow) {
    if (this.started) return;
    this.started = true;
    this.baseline = baseline;
    this.preparePerimeter(baseline);
    this.replan(mask, flow);
    for (let index = 0; index < this.startingCount; index++) {
      const deployment = this.deployments[index];
      const placed = deployment ? this.terrain.nearest(deployment.roof?.access ?? deployment.position,
        mask, baseline, deployment.roof ? 15 : 3) : -1;
      this.addSoldier(placed >= 0 && deployment && vehicleFits(this.terrain, placed, mask, deployment.type) ? deployment : deployment && { type: deployment.type, position: this.center },
        placed >= 0 && (!deployment || vehicleFits(this.terrain, placed, mask, deployment.type)) ? placed : this.goal);
    }
  }

  canReinforce(elapsed: number) {
    return this.started && !this.clearance && this.phase !== 'departed' && !this.overrun && this.count < maxSquadSize
      && elapsed < this.duration - boardingSeconds;
  }

  reinforce(deployment: Deployment, mask: number, elapsed: number, credits: number) {
    const cost = infantryCost + deploymentUpgrade(deployment.type);
    if (!this.canReinforce(elapsed) || credits < cost) return false;
    const cell = this.deploymentCell(deployment, mask);
    if (cell < 0 || !this.rally[cell] || !vehicleFits(this.terrain, cell, mask, deployment.type)) return false;
    this.addSoldier(deployment, cell);
    this.reinforcementSpend += cost;
    return true;
  }

  private deploymentCell(deployment: Deployment, mask: number) {
    if (deployment.roof) return this.terrain.nearest(deployment.roof.access, mask, this.baseline, 15);
    const cell = this.terrain.cell(...deployment.position);
    return this.terrain.open(cell, mask) && this.baseline?.[cell] ? cell : -1;
  }

  private addSoldier(deployment: Deployment | undefined, cell: number) {
    const index = this.soldiers.length;
    const type = deployment?.type ?? 'infantry';
    const unit = soldierTypes[type];
    const roofHeight = type === 'sniper' ? deployment?.roof?.height ?? 0 : 0;
    const x = roofHeight && deployment ? deployment.position[0] : this.terrain.x(cell);
    const y = roofHeight && deployment ? deployment.position[1] : this.terrain.y(cell);
    const soldier: Soldier = {
      type, hullHeading: vehicleWidth(type) ? (index % 4 - 2) * Math.PI / 2 : undefined, roofHeight, roof: roofHeight ? deployment?.roof : undefined, cell, x, y, target: -1, targetX: x, targetY: y, heading: (index % 4 - 2) * Math.PI / 2,
      vx: 0, vy: 0, speed: 0, travel: 0, ammo: weapons[unit.weapon].magazine, reloadUntil: 0, nextShot: 0,
      health: unit.health, supplies: type === 'medic' ? medicSupplies : 0, treatingUntil: 0, state: 'patrol',
      path: [], pathIndex: 0, retryAt: 0, nextWound: 0, seed: this.seed ^ Math.imul(index + 1, 0x9e3779b1),
      roundsFired: 0, aimUntil: 0, patrolTurn: index,
    };
    this.soldiers.push(soldier);
  }

  preparePerimeter(baseline: Uint16Array) {
    this.fortifications ??= new Fortifications(this.terrain, this.center, baseline, this.barricades);
  }

  inside(x: number, y: number) {
    return (x - this.center[0]) ** 2 + (y - this.center[1]) ** 2 <= this.radius ** 2;
  }

  replan(mask: number, flow: Uint16Array) {
    this.rally = flow;
    this.routes.clear();
    this.clearanceFlow = undefined;
    this.patrolPaths.clear();
    for (const soldier of this.active) {
      soldier.path = [];
      soldier.pathIndex = 0;
      soldier.retryAt = 0;
      soldier.patrolObstruction = undefined;
      const actual = this.terrain.cell(soldier.x, soldier.y);
      if (soldier.target >= 0 && this.terrain.open(actual, mask)
        && (!runnerTargetOpen(soldier, this.terrain, mask)
          || (actual === soldier.cell && this.fortifications?.allows(soldier.cell, soldier.target, false) === false))) {
        aimRunner(soldier, this.terrain, soldier.cell, mask);
      }
      if (soldier.state === 'patrol' && soldier.patrolCenter !== undefined) {
        const start = soldier.target >= 0 ? soldier.target : soldier.cell;
        if (soldier.rescue?.escort) continue;
        soldier.path = this.route(start, soldier.patrolCenter, mask, soldier.type);
        if (!soldier.path.length && start !== soldier.patrolCenter) {
          soldier.patrolObstruction = this.findObstruction(start, soldier.patrolCenter, mask);
        }
      }
    }
  }

  tryIgnite(point: Point, elapsed: number, bomb = false) {
    if (!this.terrain.open(this.terrain.cell(...point))) return false;
    const grass = isGrass(point, this.terrain.parks);
    const chance = bomb ? grass ? .8 : .35 : grass ? .58 : .19;
    if (random(this.seed ^ Math.imul(++this.fireRoll, 0x25bd28a1)) >= chance) return false;
    const until = elapsed + (grass ? 22 : 9);
    if (this.groundFires.length >= 32) this.groundFires.shift();
    this.groundFires.push({ point, start: elapsed, until, radius: bomb ? 5.5 : 2.5 });
    return true;
  }

  tick(elapsed: number, seconds: number, mask: number, outbreak: Outbreak, onShellImpact?: (point: Point, radius: number) => void) {
    const before = this.fortifications?.gates.map(gate => gate.integrity > 0 && gate.open && !gate.locked || gate.integrity <= 0).join();
    this.fortifications?.resolve(seconds, elapsed);
    if (!this.clearance && !this.overrun) {
      const occupied = outbreak.zombies.some(zombie => this.rally[this.terrain.cell(zombie.x, zombie.y)] === 1);
      this.exposedFor = occupied ? this.exposedFor + seconds : 0;
      this.overrun = this.exposedFor >= 3;
    }
    for (let index = this.groundFires.length - 1; index >= 0; index--) {
      if (this.groundFires[index].until <= elapsed) this.groundFires.splice(index, 1);
    }
    let pending = 0;
    for (const impact of this.impacts) {
      if (impact.at > elapsed) {
        this.impacts[pending++] = impact;
        continue;
      }
      const { shot, target } = impact;
      if (shot.shell) {
        this.tryIgnite(shot.to, elapsed);
        onShellImpact?.(shot.to, shellBlastRadius);
        for (const zombie of this.targets(...shot.to, shellBlastRadius)) {
          if (zombie.health === 0 || (zombie.x - shot.to[0]) ** 2 + (zombie.y - shot.to[1]) ** 2 > shellBlastRadius ** 2
            || (zombie !== target && !this.hasSight(shot.to, 0, zombie, mask))) continue;
          outbreak.decals.hit([zombie.x, zombie.y], shot.from, elapsed);
          if (outbreak.hit(zombie, impact.damage)) this.eliminated++;
        }
        continue;
      }
      if (target && target.health !== 0 && (target.x - shot.to[0]) ** 2 + (target.y - shot.to[1]) ** 2 <= 1.6 ** 2
        && this.hasSight(impact.origin, impact.roofHeight, target, mask)) {
        outbreak.decals.hit([target.x, target.y], shot.from, elapsed);
        if (outbreak.hit(target, impact.damage)) this.eliminated++;
      }
    }
    this.impacts.length = pending;
    if (!this.clearance && elapsed >= this.duration - this.fallbackWindow) this.phase = 'fallback';
    for (let i = this.shots.length - 1; i >= 0; i--) if (this.shots[i].until <= elapsed) this.shots.splice(i, 1);
    const fire = elapsed >= this.nextSweep;
    if (fire) {
      this.nextSweep = elapsed + 0.12;
      this.nearby.clear();
      for (const zombie of outbreak.zombies) {
        const key = this.bucket(zombie.x, zombie.y);
        const occupants = this.nearby.get(key);
        if (occupants) occupants.push(zombie);
        else this.nearby.set(key, [zombie]);
      }
    }
    if (fire && this.gateLockdown) this.scanGates(mask);
    if (before !== this.fortifications?.gates.map(gate => gate.integrity > 0 && gate.open && !gate.locked || gate.integrity <= 0).join()) this.gatesChanged();
    for (const soldier of this.active) {
      const carrier = soldier.boardingCarrier;
      if (carrier) {
        if (carrier.state !== 'patrol' || this.phase !== 'defend' || soldier.patrolObstruction !== undefined) soldier.boardingCarrier = undefined;
        else if (Math.hypot(carrier.x - soldier.x, carrier.y - soldier.y) <= 2.2
          && clearSight(this.terrain, soldier.cell, carrier.cell, mask)
          && this.fortifications?.insidePickup(soldier.cell, carrier.cell) !== false) {
          soldier.carrier = carrier;
          soldier.boardingCarrier = undefined;
          soldier.path = [];
          soldier.target = -1;
          continue;
        }
      }
      if (!this.clearance && soldier.state !== 'fallback' && (this.phase === 'fallback'
        || this.rally[soldier.cell] * cellSize * 1.55 / soldierTypes[soldier.type].speed + boardingSeconds + 2 >= this.duration - elapsed)) {
        if (soldier.roofHeight) {
          soldier.roofHeight = 0;
          soldier.roofPath = undefined;
          soldier.x = this.terrain.x(soldier.cell);
          soldier.y = this.terrain.y(soldier.cell);
          soldier.aimUntil = elapsed + 1;
        }
        soldier.state = 'fallback';
        soldier.rescue = undefined;
        soldier.path = [];
      }
      const drivingToOrder = soldier.type === 'tank' && soldier.state === 'patrol'
        && soldier.patrolCenter !== undefined && soldier.cell !== soldier.patrolCenter
        && (soldier.pathIndex < soldier.path.length || soldier.target === soldier.patrolCenter);
      if (!drivingToOrder && (elapsed < soldier.aimUntil || elapsed < soldier.treatingUntil || elapsed < soldier.reloadUntil)) {
        soldier.speed = Math.max(0, soldier.speed - seconds * 10);
        if (soldier.aimHeading !== undefined && elapsed < soldier.aimUntil) {
          const angle = soldier.aimHeading - soldier.heading;
          const gap = Math.atan2(Math.sin(angle), Math.cos(angle));
          const turn = seconds * (vehicleWidth(soldier.type) ? 4 : 7);
          soldier.heading += Math.max(-turn, Math.min(turn, gap));
        }
      }
      else if (soldier.type === 'carrier' && this.soldiers.some(unit => unit.boardingCarrier === soldier)) soldier.speed = 0;
      else if (soldier.roofHeight) this.moveOnRoof(soldier, seconds);
      else if (soldier.type !== 'sniper' || soldier.state === 'fallback' || soldier.patrolCenter !== undefined) this.move(soldier, elapsed, seconds, mask);
      if (soldier.reloadUntil && elapsed >= soldier.reloadUntil) {
        soldier.reloadUntil = 0;
        soldier.ammo = weapons[soldierTypes[soldier.type].weapon].magazine;
      }
      if (fire && soldier.state !== 'aboard' && elapsed >= soldier.treatingUntil) {
        const candidates = this.targets(soldier.x, soldier.y, this.range(soldier));
        if (!drivingToOrder) this.fire(soldier, elapsed, mask, candidates);
        if (!soldier.roofHeight) this.checkContact(soldier, elapsed, mask, candidates);
      }
      if (soldier.type === 'carrier' && (soldier.state === 'aboard' || soldier.state === 'lost')) {
        for (const passenger of this.passengers(soldier)) {
          passenger.carrier = undefined;
          passenger.state = soldier.state;
        }
      }
    }
  }

  private moveOnRoof(soldier: Soldier, seconds: number) {
    const next = soldier.roofPath?.[0];
    soldier.speed = 0;
    if (!next) return;
    const dx = next[0] - soldier.x, dy = next[1] - soldier.y;
    const distance = Math.hypot(dx, dy);
    if (distance <= 1e-6) {
      soldier.roofPath?.shift();
      return;
    }
    const stride = Math.min(distance, seconds * 1.8);
    soldier.speed = stride / seconds;
    soldier.heading = turnToward(soldier.heading, Math.atan2(dy, dx), seconds, 7.5);
    soldier.x += dx * stride / distance;
    soldier.y += dy * stride / distance;
    soldier.travel += stride;
    if (stride === distance) soldier.roofPath?.shift();
  }

  private move(soldier: Soldier, elapsed: number, seconds: number, mask: number) {
    const unit = soldierTypes[soldier.type];
    const pace = soldier.state !== 'patrol' || (soldier.rescue && !soldier.rescue.escort)
      || (this.clearance && soldier.patrolCenter !== undefined
        && (this.terrain.x(soldier.patrolCenter) - soldier.x) ** 2 + (this.terrain.y(soldier.patrolCenter) - soldier.y) ** 2 > patrolRadius ** 2) ? unit.speed
      : soldier.rescue?.escort ? 2.7 : unit.patrolSpeed || 1.8;
    const vehicle = vehicleWidth(soldier.type) > 0;
    const bearing = (soldier.targetHeading ?? soldier.heading) - (soldier.hullHeading ?? soldier.heading);
    const corner = .60 + .40 * Math.max(0, Math.cos(bearing));
    const desiredSpeed = pace * corner * this.terrain.paceFactor(soldier.cell) * (soldier.health < unit.health ? 0.72 : 1);
    soldier.speed += Math.max(-seconds * 5, Math.min(seconds * (vehicle ? 2.3 : 4.4), desiredSpeed - soldier.speed));
    let remaining = soldier.speed * seconds;
    while (remaining > 0.0001) {
      if (soldier.target < 0) {
        if (soldier.state === 'fallback' && Math.hypot(soldier.x - this.center[0], soldier.y - this.center[1]) <= 6 && this.rally[soldier.cell] === 1) {
          if (elapsed >= this.duration - boardingSeconds) soldier.state = 'aboard';
          soldier.speed = 0;
          return;
        }
        const localMask = this.terrain.open(soldier.cell, mask) ? mask : 0;
        const next = soldier.state === 'patrol' ? this.patrolStep(soldier, elapsed, localMask) : this.rallyStep(soldier, localMask);
        if (next < 0 || !vehicleFits(this.terrain, next, localMask, soldier.type)) {
          soldier.speed = 0;
          return;
        }
        aimRunner(soldier, this.terrain, next, mask);
        if ((vehicle || this.fortifications?.gates.length) && soldier.curve) soldier.curve.length = 0;
      }
      if (soldier.target !== soldier.cell && this.terrain.cell(soldier.x, soldier.y) === soldier.cell
        && !this.fortifications?.allows(soldier.cell, soldier.target, false) && this.fortifications) {
        soldier.path = [];
        aimRunner(soldier, this.terrain, soldier.cell, mask);
      }
      const aim = soldier.heading;
      if (soldier.hullHeading !== undefined) soldier.heading = soldier.hullHeading;
      remaining -= moveRunner(soldier, remaining, vehicle ? 3.3 : 7.5);
      if (vehicle) {
        soldier.hullHeading = soldier.heading;
        soldier.heading = aim;
      }
      if (soldier.x !== soldier.targetX || soldier.y !== soldier.targetY) return;
      soldier.cell = soldier.target;
      soldier.target = -1;
    }
  }

  private rallyStep(soldier: Soldier, mask: number) {
    const flow = this.rally;
    let best = -Infinity;
    let target = -1;
    for (const [direction, [dx, dy]] of steps.entries()) {
      const next = soldier.cell + dy * this.terrain.columns + dx;
      if (!vehicleFits(this.terrain, next, mask, soldier.type) || !flow[next] || (flow[soldier.cell] && flow[next] >= flow[soldier.cell]) || !this.terrain.canStep(soldier.cell, direction, mask)
        || this.fortifications?.allows(soldier.cell, next, false) === false) continue;
      const score = -flow[next] + (dx * soldier.vx + dy * soldier.vy) * 0.25;
      if (score > best) { best = score; target = next; }
    }
    return target;
  }

  private scanGates(mask: number) {
    const forts = this.fortifications;
    if (!forts) return;
    for (const gate of forts.gates) {
      if (gate.integrity <= 0) continue;
      const [[x, y], [endX, endY]] = gate.span;
      const dx = endX - x;
      const dy = endY - y;
      const side = Math.sign(dx * (this.terrain.y(gate.post) - y) - dy * (this.terrain.x(gate.post) - x))
        || Math.sign(dx * (this.center[1] - y) - dy * (this.center[0] - x)) || 1;
      let count = 0;
      for (const zombie of this.targets(...gate.position, 12)) {
        if ((dx * (zombie.y - y) - dy * (zombie.x - x)) * side >= 0
          || Math.hypot(zombie.x - gate.position[0], zombie.y - gate.position[1]) > 12) continue;
        if (clearSight(this.terrain, gate.post, this.terrain.cell(zombie.x, zombie.y), mask)) count++;
      }
      forts.updateLockdown(gate, count);
    }
  }

  private route(start: number, end: number, mask: number, type: Deployment['type'] = 'infantry') {
    const width = Math.round(vehicleWidth(type) * 100);
    const key = `${start}:${end}:${mask}:${width}`;
    let path = this.routes.get(key);
    if (!path) {
      const allows = (from: number, to: number) => this.fortifications?.allows(from, to, false) ?? true;
      path = this.clearance && !width ? this.clearanceRoute(start, end, mask, allows)
        : localPath(this.terrain, start, end, mask, cell => !!this.baseline?.[cell] && vehicleFits(this.terrain, cell, mask, type),
          this.clearance ? 650000 : 24000, this.clearance ? 7000 : 1200, allows);
      if (this.routes.size >= 1024) this.routes.clear();
      this.routes.set(key, path);
    }
    return path;
  }

  private clearanceRoute(start: number, end: number, mask: number, allows: (from: number, to: number) => boolean) {
    if (!this.baseline?.[end]) return [];
    const terrain = this.terrain;
    if (this.clearanceFlow?.destination !== end || this.clearanceFlow.mask !== mask) {
      const field = terrain.flow(end, mask, this.clearanceFlow?.field, allows, cell => cell === end);
      this.clearanceFlow = { destination: end, mask, field };
    }
    const { field } = this.clearanceFlow;
    const path: number[] = [];
    let cell = start;
    while (field[cell] > 1) {
      let best = -Infinity;
      let next = -1;
      for (const [direction, [dx, dy]] of steps.entries()) {
        const candidate = cell + dy * terrain.columns + dx;
        if (!field[candidate] || field[candidate] >= field[cell] || !terrain.canStep(cell, direction, mask) || !allows(cell, candidate)) continue;
        const score = (field[cell] - field[candidate]) / Math.hypot(dx, dy);
        if (score <= best) continue;
        next = candidate;
        best = score;
      }
      if (next < 0) return [];
      path.push(next);
      cell = next;
    }
    return cell === end ? path : [];
  }

  patrolView(soldier: Soldier) {
    const point = (cell: number): Point => [this.terrain.x(cell), this.terrain.y(cell)];
    return {
      center: soldier.patrolCenter === undefined ? undefined : point(soldier.patrolCenter),
      rescue: soldier.rescue,
      obstruction: soldier.patrolObstruction?.position,
      blocked: soldier.patrolObstruction !== undefined,
      path: soldier.roofHeight ? [[soldier.x, soldier.y] as Point, ...(soldier.roofPath ?? [])] : [[soldier.x, soldier.y] as Point,
        ...(soldier.target >= 0 ? [point(soldier.target)] : []),
        ...soldier.path.slice(soldier.pathIndex).map(point)],
    };
  }

  private findObstruction(start: number, end: number, mask: number) {
    if (!this.fortifications?.gates.length) return null;
    const path = localPath(this.terrain, start, end, mask, cell => !!this.baseline?.[cell], 24000, 1200);
    let from = start;
    for (const next of path) {
      const gate = this.fortifications.blockingGate(from, next);
      if (gate) return gate;
      from = next;
    }
    return null;
  }

  private patrolStep(soldier: Soldier, elapsed: number, mask: number) {
    if (soldier.pathIndex < soldier.path.length) return soldier.path[soldier.pathIndex++];
    if (elapsed < soldier.retryAt) return -1;
    soldier.retryAt = elapsed + 0.85;
    if (soldier.rescue?.escort) {
      if (this.rally[soldier.cell] > 1) return this.rallyStep(soldier, mask);
      if (this.rally[soldier.cell] === 1) {
        soldier.rescue = undefined;
        soldier.patrolCenter = soldier.returnPatrol ?? this.goal;
        soldier.returnPatrol = undefined;
      } else return -1;
    }
    const post = soldier.patrolCenter ?? soldier.cell;
    const radius = soldier.rescue ? 0.7 : soldier.patrolCenter === undefined ? 18 : patrolRadius;
    const distance = Math.hypot(soldier.x - this.terrain.x(post), soldier.y - this.terrain.y(post));
    const route = distance > radius || soldier.patrolObstruction !== undefined ? this.route(soldier.cell, post, mask, soldier.type) : [];
    if (route.length) {
      soldier.patrolObstruction = undefined;
      soldier.path = route;
      soldier.pathIndex = 1;
      return route[0];
    }
    if (distance > radius) {
      if (soldier.patrolObstruction === undefined) soldier.patrolObstruction = this.findObstruction(soldier.cell, post, mask);
      return -1;
    }
    if (soldier.patrolObstruction !== undefined && soldier.cell !== post) return -1;
    soldier.patrolObstruction = undefined;
    if (soldier.rescue) return -1;
    const options = this.roamingPaths(soldier.cell, post, radius, mask, soldier.type);
    if (!options.length) return -1;
    const seed = soldier.seed + ++soldier.patrolTurn * 91;
    const heading = random(seed) * 2 * Math.PI;
    let best = -Infinity;
    for (const path of options) {
      const end = path.at(-1)!;
      const dx = this.terrain.x(end) - soldier.x;
      const dy = this.terrain.y(end) - soldier.y;
      const score = dx * (Math.cos(heading) + .55 * soldier.vx) + dy * (Math.sin(heading) + .55 * soldier.vy) + random(seed ^ end);
      if (score <= best) continue;
      best = score;
      soldier.path = path;
    }
    soldier.pathIndex = 1;
    return soldier.path[0];
  }

  private roamingPaths(start: number, post: number, radius: number, mask: number, type: Deployment['type']) {
    const key = `${start}:${post}:${mask}:${radius}:${vehicleWidth(type)}`;
    const cached = this.patrolPaths.get(key);
    if (cached) return cached;
    const queue = [start];
    const parents = new Map<number, number>([[start, -1]]);
    const x = this.terrain.x(post);
    const y = this.terrain.y(post);
    const sectors = new Map<number, { cell: number; distance: number }>();
    let nearest = Infinity;
    let fallback = -1;
    for (let index = 0; index < queue.length && index < 480; index++) {
      const cell = queue[index];
      const distance = (this.terrain.x(cell) - x) ** 2 + (this.terrain.y(cell) - y) ** 2;
      if (cell !== start && distance < nearest) {
        nearest = distance;
        fallback = cell;
      }
      if (index >= 42 && distance <= radius ** 2
        && Math.hypot(this.terrain.x(cell) - this.terrain.x(start), this.terrain.y(cell) - this.terrain.y(start)) > 2.4) {
        const dx = this.terrain.x(cell) - this.terrain.x(start);
        const dy = this.terrain.y(cell) - this.terrain.y(start);
        const sector = Math.round(Math.atan2(dy, dx) / (Math.PI / 4));
        const displacement = dx * dx + dy * dy;
        if (displacement > (sectors.get(sector)?.distance ?? 0)) sectors.set(sector, { cell, distance: displacement });
      }
      for (const [direction, [dx, dy]] of steps.entries()) {
        const next = cell + dy * this.terrain.columns + dx;
        if (parents.has(next) || !this.rally[next] || !vehicleFits(this.terrain, next, mask, type) || !this.terrain.canStep(cell, direction, mask) || this.fortifications?.allows(cell, next, false) === false) continue;
        parents.set(next, cell);
        queue.push(next);
      }
    }
    const destinations = [...sectors.values()].map(({ cell }) => cell);
    if (!destinations.length && fallback >= 0) destinations.push(fallback);
    const paths = destinations.map(destination => {
      const path: number[] = [];
      for (let cell = destination; cell !== start; cell = parents.get(cell)!) path.push(cell);
      return path.reverse();
    });
    if (this.patrolPaths.size >= 1024) this.patrolPaths.clear();
    this.patrolPaths.set(key, paths);
    return paths;
  }

  private bucket(x: number, y: number) {
    return Math.floor(x / 24) + Math.floor(y / 24) * 4096;
  }

  private targets(worldX: number, worldY: number, range: number) {
    const candidates: Zombie[] = [];
    for (let y = Math.floor((worldY - range) / 24); y <= Math.floor((worldY + range) / 24); y++) {
      for (let x = Math.floor((worldX - range) / 24); x <= Math.floor((worldX + range) / 24); x++) {
        for (const zombie of this.nearby.get(x + y * 4096) ?? []) candidates.push(zombie);
      }
    }
    return candidates;
  }

  private range(soldier: Soldier) {
    return weapons[soldierTypes[soldier.type].weapon].range + soldier.roofHeight * 2;
  }

  private hasSight(origin: Point, height: number, target: Zombie, mask: number) {
    const end = this.terrain.cell(target.x, target.y);
    if (!height) return clearSight(this.terrain, this.terrain.cell(...origin), end, mask);
    // Leave the source roof before checking the street-level sightline.
    const dx = target.x - origin[0];
    const dy = target.y - origin[1];
    const samples = Math.max(1, Math.ceil(Math.hypot(dx, dy) / 0.3));
    for (let index = 0; index <= samples; index++) {
      const cell = this.terrain.cell(origin[0] + dx * index / samples, origin[1] + dy * index / samples);
      if (this.terrain.open(cell, mask)) return clearSight(this.terrain, cell, end, mask);
    }
    return false;
  }

  private fire(soldier: Soldier, elapsed: number, mask: number, candidates: Zombie[]) {
    if (soldier.reloadUntil || soldier.nextShot > elapsed) return;
    const weapon = weapons[soldierTypes[soldier.type].weapon];
    const origin = this.terrain.cell(soldier.x, soldier.y);
    let target: Zombie | undefined;
    const maxRange = this.range(soldier);
    let range = maxRange ** 2;
    let best = Infinity;
    for (const zombie of candidates) {
      const distance = (zombie.x - soldier.x) ** 2 + (zombie.y - soldier.y) ** 2;
      const score = distance * (zombie === soldier.trackedTarget ? .74 : 1) * (zombie.slam ? .72 : 1);
      if (distance >= maxRange ** 2 || score >= best || !this.hasSight([soldier.x, soldier.y], soldier.roofHeight, zombie, mask)) continue;
      target = zombie;
      range = distance;
      best = score;
    }
    soldier.trackedTarget = target;
    if (!target) return;
    const angle = Math.atan2(target.y - soldier.y, target.x - soldier.x);
    const turn = Math.atan2(Math.sin(angle - soldier.heading), Math.cos(angle - soldier.heading));
    if (Math.abs(turn) > 0.16) {
      soldier.aimHeading = angle;
      soldier.aimUntil = elapsed + 0.18;
      return;
    }
    soldier.heading = angle;
    soldier.aimHeading = undefined;
    soldier.speed = 0;
    soldier.aimUntil = elapsed + 0.22;
    const roll = random(soldier.seed ^ Math.imul(++soldier.roundsFired, 0x85ebca6b));
    const hits = roll < shotAccuracy(Math.sqrt(range), maxRange);
    const offset = hits ? 0 : (roll < 0.8 ? -1 : 1) * (1.4 + Math.sqrt(range) * 0.09);
    const to: Point = [target.x - Math.sin(angle) * offset, target.y + Math.cos(angle) * offset];
    // Clip a missed tracer at the first blocked patch of ground.
    if (!hits && !soldier.roofHeight) {
      const dx = to[0] - soldier.x;
      const dy = to[1] - soldier.y;
      const samples = Math.max(1, Math.ceil(Math.hypot(dx, dy) / 0.6));
      let previous = origin;
      for (let i = 1; i <= samples; i++) {
        const cell = this.terrain.cell(soldier.x + dx * i / samples, soldier.y + dy * i / samples);
        if (!this.terrain.touches(previous, cell, mask)) {
          to[0] = soldier.x + dx * (i - 1) / samples;
          to[1] = soldier.y + dy * (i - 1) / samples;
          break;
        }
        previous = cell;
      }
    }
    const shell = soldier.type === 'tank';
    const muzzleReach = shell ? 2.8 : vehicleWidth(soldier.type) ? 1.1 : soldier.type === 'medic' ? 0.37 : 0.63;
    const muzzle: Point = [soldier.x + Math.cos(angle) * muzzleReach, soldier.y + Math.sin(angle) * muzzleReach];
    const shot = { from: muzzle, to, start: elapsed, until: elapsed + (shell ? .7 : .15), shell };
    this.shots.push(shot);
    if (hits || shell) this.impacts.push({ shot, target, damage: weapon.damage, at: elapsed + (shell ? .24 : .075), origin: [soldier.x, soldier.y], roofHeight: soldier.roofHeight });
    soldier.ammo--;
    soldier.nextShot = elapsed + weapon.interval;
    if (!soldier.ammo) soldier.reloadUntil = elapsed + weapon.reload;
  }

  private checkContact(soldier: Soldier, elapsed: number, mask: number, candidates: Zombie[]) {
    if (soldier.nextWound > elapsed) return;
    const cell = this.terrain.cell(soldier.x, soldier.y);
    const grabbed = candidates.some(zombie => !zombie.attack && (zombie.x - soldier.x) ** 2 + (zombie.y - soldier.y) ** 2 <= 0.9 ** 2
      && this.terrain.touches(cell, this.terrain.cell(zombie.x, zombie.y), mask)
      && (this.fortifications?.allows(this.terrain.cell(zombie.x, zombie.y), cell, false) ?? true));
    if (!grabbed) return;
    soldier.health--;
    soldier.nextWound = elapsed + 0.85;
    if (!soldier.health) {
      soldier.state = 'lost';
      soldier.boardingCarrier = undefined;
    }
  }

  depart() {
    if (this.phase === 'departed') return;
    for (const soldier of this.soldiers) if (soldier.state !== 'aboard') { soldier.state = 'lost'; soldier.carrier = undefined; soldier.boardingCarrier = undefined; }
    this.shots.length = 0;
    this.impacts.length = 0;
    this.phase = 'departed';
  }
}
