import type { Point } from './routing.ts';

export type Joint = [side: number, forward: number, height: number];
export type Pose = [Joint, Joint, Joint, Joint, Joint, Joint, Joint, Joint, Joint, Joint, Joint];
export type Look = {
  build: number;
  colors: readonly [string, string, string, string];
  hairStyle: string;
  role: 'civilian' | 'infected' | 'brute' | 'infantry' | 'sniper' | 'medic';
  outfit?: number;
};

const tau = Math.PI * 2;
type Part = { depth: number; paint: () => void };

const tones = new Map<string, [string, string]>();
function shade(color: string): [string, string] {
  const cached = tones.get(color);
  if (cached) return cached;
  const rgb = Number.parseInt(color.slice(1), 16);
  const tint = (factor: number, light: number) => {
    const channel = (shift: number) => Math.min(255, Math.round(((rgb >> shift) & 255) * factor + light));
    return '#' + [16, 8, 0].map(shift => channel(shift).toString(16).padStart(2, '0')).join('');
  };
  const result: [string, string] = [tint(.66, 1), tint(1.07, 14)];
  tones.set(color, result);
  return result;
}

export function drawCharacter(context: CanvasRenderingContext2D, heading: number, pose: Pose, look: Look, action = 0) {
  const [coat, trousers, skin, hair] = look.colors;
  const [hips, shoulders, head] = pose;
  const { role } = look;
  const infected = role === 'infected' || role === 'brute';
  const brute = role === 'brute';
  const soldier = role === 'infantry' || role === 'sniper' || role === 'medic';
  const flat = shoulders[2] < .32;
  const c = Math.cos(heading), s = Math.sin(heading);
  const parts: Part[] = [];
  const project = ([side, front, height]: Joint): Point =>
    [front * c - side * s * look.build, (front * s + side * c * look.build) * .85 - height];
  const depth = ([side, front, height]: Joint) => front * s + side * c * look.build + height * .63;
  const local = ([side, front, height]: Joint, right: number, ahead: number, up: number): Joint =>
    [side + right, front + ahead, height + up];

  function panel(joints: Joint[], color: string, bias = 0, outline = true) {
    const points = joints.map(project);
    parts.push({ depth: joints.reduce((sum, joint) => sum + depth(joint), 0) / joints.length + bias, paint: () => {
      context.beginPath();
      context.moveTo(...points[0]);
      for (const point of points.slice(1)) context.lineTo(...point);
      context.closePath();
      context.fillStyle = color;
      context.fill();
      if (outline) {
        context.lineWidth = .033;
        context.strokeStyle = shade(color)[0];
        context.stroke();
      }
    } });
  }

  function link(a: Joint, b: Joint, start: number, end: number, color: string, bias = 0) {
    const [x, y] = project(a), [ex, ey] = project(b);
    const angle = Math.atan2(ey - y, ex - x);
    const length = Math.hypot(ex - x, ey - y);
    const [dark, light] = shade(color);
    parts.push({ depth: (depth(a) + depth(b)) / 2 + bias, paint: () => {
      context.save();
      context.translate(x, y);
      context.rotate(angle);
      context.beginPath();
      context.moveTo(0, -start);
      context.lineTo(length, -end);
      context.bezierCurveTo(length + end * .9, -end, length + end * .9, end, length, end);
      context.lineTo(0, start);
      context.bezierCurveTo(-start * .9, start, -start * .9, -start, 0, -start);
      const gradient = context.createLinearGradient(0, -start, 0, start);
      gradient.addColorStop(0, light);
      gradient.addColorStop(.38, color);
      gradient.addColorStop(1, dark);
      context.fillStyle = gradient;
      context.fill();
      context.lineWidth = .035;
      context.strokeStyle = dark;
      context.stroke();
      context.restore();
    } });
  }

  const rear = s < -.38;
  const chest = [local(hips, -.20, .07, .03), local(hips, .20, .07, .03),
    local(shoulders, .29, .05, 0), local(shoulders, -.29, .05, 0)];
  const back = [local(hips, .20, -.13, .03), local(hips, -.20, -.13, .03),
    local(shoulders, -.29, -.12, 0), local(shoulders, .29, -.12, 0)];
  panel(chest, coat);
  panel(back, shade(coat)[0]);
  panel([chest[0], back[1], back[2], chest[3]], shade(coat)[1]);
  panel([back[0], chest[1], chest[2], back[3]], coat);
  panel([chest[2], chest[3], back[2], back[3]], shade(coat)[1]);
  link(shoulders, local(head, 0, -.02, -.13), .09, .079, skin);

  for (const side of [-1, 1]) {
    const offset = side < 0 ? 3 : 7;
    const [knee, foot, elbow, hand] = pose.slice(offset, offset + 4);
    const hip = local(hips, side * .14, 0, 0);
    const shoulder = local(shoulders, side * (brute ? .32 : .265), 0, -.045);
    const oversized = brute && side > 0;
    const size = oversized ? 1.55 : 1;
    link(hip, knee, .136, .106, trousers);
    link(knee, foot, .105, .067, trousers);
    link(local(foot, 0, -.035, -.02), local(foot, 0, .18, -.024), .086, .088,
      soldier ? '#293632' : infected ? '#403f38' : '#534136', .025);
    if (soldier) link(local(knee, 0, .05, .07), local(knee, 0, .062, -.08), .107, .093, '#45504a', .06);
    link(shoulder, elbow, .12 * size, .083 * size, coat);
    link(elbow, hand, .086 * size, .062 * size, infected || oversized ? skin : coat);
    link(hand, local(hand, 0, .065, -.04), .07 * size, .045 * size, skin, .028);
    if (oversized) {
      link(local(shoulder, .04, -.02, .09), local(elbow, .055, 0, .04), .21, .12, '#854d50', .07);
      for (let claw = -1; claw <= 1; claw++) {
        link(local(hand, claw * .06, .025, .015), local(hand, claw * .08, .16, -.09), .038, .019, '#c2a08b', .08);
      }
    }
  }

  if (soldier) {
    const vest = role === 'sniper' ? '#595341' : role === 'medic' ? '#376060' : '#343d36';
    link(local(hips, 0, .125, .20), local(shoulders, 0, .135, -.18), .219, .245, vest, s * .04);
    for (const side of [-1, 0, 1]) {
      link(local(hips, side * .13, .19, .21), local(hips, side * .13, .19, .39), .052, .053, '#85816b', s * .09);
    }
    if (role === 'medic' || role === 'sniper') {
      const pack = role === 'medic' ? '#c2cbc0' : '#777157';
      link(local(hips, 0, -.23, .21), local(shoulders, 0, -.24, -.23), .195, .205, pack, -s * .04);
      if (role === 'medic' && rear) {
        const center = local(hips, 0, -.33, .49);
        link(local(center, -.11, 0, 0), local(center, .11, 0, 0), .029, .029, '#a73844', .10);
        link(local(center, 0, 0, -.11), local(center, 0, 0, .11), .029, .029, '#a73844', .10);
      }
    }
    if (action !== 1) {
      const pistol = role === 'medic';
      const sight = local(shoulders, -.04, .25, action === 3 ? -.40 : -.26);
      const muzzle = local(sight, 0, pistol ? .29 : role === 'sniper' ? 1.04 : .73, 0);
      link(local(sight, 0, pistol ? -.06 : -.57, -.03), muzzle, pistol ? .061 : .081, .025, '#303c3d', .08);
      link(sight, local(sight, 0, -.05, -.18), .06, .046, '#242d2e', .075);
      if (role === 'sniper') link(local(sight, 0, .05, .09), local(sight, 0, .34, .09), .046, .042, '#424d48', .10);
    }
  } else if (infected) {
    const wound = local(shoulders, -.13, .133, -.24);
    link(wound, local(wound, .17, .01, -.23), .095, .068, '#613b40', s * .06);
    if (brute) {
      for (let plate = 0; plate < 3; plate++) {
        const point = local(shoulders, .14 - plate * .13, -.13, .06 - plate * .17);
        link(point, local(point, .10, -.06, .10), .115, .049, '#a87770', -s * .13);
      }
    }
  } else if (look.outfit === 2 || look.outfit === 3) {
    link(local(hips, 0, -.22, .24), local(shoulders, 0, -.23, -.16), .185, .178, '#b98058', -s * .06);
  } else if (look.outfit === 1 || look.outfit === 5) {
    link(local(shoulders, -.20, .14, -.06), local(hips, .29, .13, .05), .035, .037, '#65503c');
    link(local(hips, .30, .06, -.12), local(hips, .30, .06, .05), .113, .118, '#83644a');
  } else {
    link(local(hips, .025, .12, .12), local(shoulders, .025, .14, -.12), .017, .021, shade(coat)[0], s * .05);
  }

  link(local(head, 0, .018, -.076), local(head, 0, 0, .071), .157, .185, skin, .091);
  if (soldier) {
    const helmet = role === 'medic' ? '#ccd2bf' : role === 'sniper' ? '#8b8165' : '#596854';
    link(local(head, 0, -.045, .06), local(head, 0, -.035, .139), .185, .17, helmet, .13);
    if (!rear) link(local(head, -.145, .139, .016), local(head, .145, .139, .016), .047, .047, '#273d40', .23);
  } else {
    link(local(head, 0, -.085, .035), local(head, 0, -.08, look.hairStyle === 'receding' ? .10 : .15),
      .165, .143, hair, .105);
    if (look.hairStyle === 'ponytail' || look.hairStyle === 'bun') {
      const tail = local(head, 0, -.193, .064);
      link(tail, local(tail, .024, -.09, look.hairStyle === 'bun' ? -.025 : -.24), .081, .054, hair, .089);
    }
    if (!rear) {
      for (const side of [-1, 1]) {
        if (Math.abs(c) > .68 && side * c < 0) continue;
        const eye = local(head, side * .069, .158, .018);
        link(eye, local(eye, side * .02, 0, .002), .02, .02, infected ? '#dfc891' : '#3f3534', .24);
      }
      if (infected) link(local(head, -.07, .149, -.09), local(head, .064, .149, -.102), .035, .026, '#4d282c', .21);
    }
  }

  context.beginPath();
  context.ellipse(0, .10, flat ? .96 : brute ? .70 : .52, .32, flat ? heading : 0, 0, tau);
  context.fillStyle = '#15202091';
  context.fill();
  parts.sort((a, b) => a.depth - b.depth);
  for (const part of parts) part.paint();
}
