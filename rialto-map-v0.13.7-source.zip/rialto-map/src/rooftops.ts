import type { Point } from './routing.ts';

export function rooftopAt(point: Point, buildings: Point[][]) {
  const [x, y] = point;
  for (const ring of buildings) {
    let inside = false;
    let twiceArea = 0;
    let access = ring[0];
    let nearest = Infinity;
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const [ax, ay] = ring[j];
      const [bx, by] = ring[i];
      if ((ay > y) !== (by > y) && x < ax + (y - ay) * (bx - ax) / (by - ay)) inside = !inside;
      twiceArea += ax * by - bx * ay;
      const dx = bx - ax;
      const dy = by - ay;
      const fraction = Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy || 1)));
      const candidate: Point = [ax + dx * fraction, ay + dy * fraction];
      const distance = (x - candidate[0]) ** 2 + (y - candidate[1]) ** 2;
      if (distance >= nearest) continue;
      nearest = distance;
      access = candidate;
    }
    if (inside) return { height: Math.max(6, Math.min(18, Math.round(Math.sqrt(Math.abs(twiceArea) / 2) / 2))), access, ring };
  }
}

export type Rooftop = { height: number; access: Point; ring?: Point[] };

function insideRoof([x, y]: Point, ring: Point[]) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [ax, ay] = ring[j], [bx, by] = ring[i];
    const cross = (x - ax) * (by - ay) - (y - ay) * (bx - ax);
    if (Math.abs(cross) < 1e-7 && x >= Math.min(ax, bx) && x <= Math.max(ax, bx)
      && y >= Math.min(ay, by) && y <= Math.max(ay, by)) return true;
    if ((ay > y) !== (by > y) && x < ax + (y - ay) * (bx - ax) / (by - ay)) inside = !inside;
  }
  return inside;
}

function roofSegment(from: Point, to: Point, ring: Point[]) {
  const [x, y] = from;
  const dx = to[0] - x, dy = to[1] - y;
  const cuts = [0, 1];
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [ax, ay] = ring[j], [bx, by] = ring[i];
    const sx = bx - ax, sy = by - ay;
    const cross = dx * sy - dy * sx;
    if (Math.abs(cross) < 1e-8) continue;
    const travel = ((ax - x) * sy - (ay - y) * sx) / cross;
    const along = ((ax - x) * dy - (ay - y) * dx) / cross;
    if (travel > 0 && travel < 1 && along >= 0 && along <= 1) cuts.push(travel);
  }
  cuts.sort((a, b) => a - b);
  return cuts.slice(1).every((end, index) => {
    const middle = (cuts[index] + end) / 2;
    return insideRoof([x + middle * dx, y + middle * dy], ring);
  });
}

export function roofPath(from: Point, to: Point, ring: Point[]) {
  if (!insideRoof(to, ring)) return undefined;
  if (roofSegment(from, to, ring)) return [to];
  const nodes = [from, to, ...ring];
  const costs = nodes.map((_, i) => i === 0 ? 0 : Infinity);
  const previous = nodes.map(() => -1);
  const visited = new Set<number>();
  while (true) {
    let current = -1;
    for (const [index, cost] of costs.entries()) {
      if (!visited.has(index) && Number.isFinite(cost) && (current < 0 || cost < costs[current])) current = index;
    }
    if (current < 0) return undefined;
    if (current === 1) break;
    visited.add(current);
    for (const [index, point] of nodes.entries()) {
      if (visited.has(index)) continue;
      const cost = costs[current] + Math.hypot(point[0] - nodes[current][0], point[1] - nodes[current][1]);
      if (cost >= costs[index] || !roofSegment(nodes[current], point, ring)) continue;
      costs[index] = cost;
      previous[index] = current;
    }
  }
  const path: Point[] = [];
  for (let index = 1; index > 0; index = previous[index]) path.unshift(nodes[index]);
  return path;
}
