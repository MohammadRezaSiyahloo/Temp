import type { Point } from './routing.ts';

export const supportTypes = {
  strike: { label: 'F-16 airstrike', cost: 450, delay: 6, radius: 11, damage: 10, pulses: 1, interval: .25 },
  helicopter: { label: 'UH-60 armed escort', cost: 650, delay: 4, radius: 45, damage: 2, pulses: 12, interval: 1 },
  gunRun: { label: 'A-10 Thunderbolt II', cost: 550, delay: 5, radius: 9, damage: 3, pulses: 11, interval: .10 },
} as const;
export type SupportType = keyof typeof supportTypes;
export type SupportRun = { type: SupportType; point: Point; impactAt: number; axis?: Point; length?: number; pulses: number; lastTarget?: Point };

export function supportImpact(run: SupportRun, pulse: number): Point {
  const [dx, dy] = run.axis ?? [1, 0];
  const count = supportTypes.gunRun.pulses - 1;
  const offset = run.type === 'gunRun' ? (pulse / count - .5) * (run.length ?? 22.5) : 0;
  return [run.point[0] + dx * offset, run.point[1] + dy * offset];
}

export function supportDuration(type: SupportType) {
  const spec = supportTypes[type];
  return (spec.pulses - 1) * spec.interval;
}

export function cannonLane(run: SupportRun, x: number, y: number, pulse: number) {
  const [px, py] = supportImpact(run, pulse);
  const [dx, dy] = run.axis ?? [1, 0];
  const along = (x - px) * dx + (y - py) * dy;
  const across = (y - py) * dx - (x - px) * dy;
  return Math.abs(along) <= Math.max(2.5, (run.length ?? 22.5) / 20) && Math.abs(across) <= 2.2;
}

export function escortFlight(age: number, delay: number, duration: number, radius: number, x: number, y: number, width: number) {
  const angle = (Math.min(duration, Math.max(0, age)) * .75) - Math.PI / 2;
  const departure = Math.max(0, age - duration);
  const approach = age < 0 ? age / delay * (x + 100) : 0;
  const px = x + Math.cos(angle) * radius + approach;
  const py = y + Math.sin(angle) * radius;
  const tangent = angle + Math.PI / 2;
  const reach = Math.max(width, 250) / 2.4;
  return {
    x: px + Math.cos(tangent) * departure * reach,
    y: py + Math.sin(tangent) * departure * reach,
    heading: tangent * 180 / Math.PI,
  };
}
