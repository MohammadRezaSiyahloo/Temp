import { cellSize, type CrowdField } from './crowd-field.ts';
import type { Point } from './routing.ts';

export type SpawnLayout = Point[] | 'random';

export function splitPopulation(total: number, sites: number) {
  if (!sites) return [];
  const each = Math.floor(total / sites);
  const remainder = total % sites;
  return Array.from({ length: sites }, (_, index) => each + Number(index < remainder));
}

export function random(seed: number) {
  const bits = Math.imul(seed ^ (seed >>> 16), 0x45d9f3b);
  return ((bits ^ (bits >>> 16)) >>> 0) / 4294967296;
}

export function scatterCells(terrain: CrowdField, flow: Uint16Array, mask: number, count: number, seed: number) {
  const chosen = new Set<number>();
  const isFree = (cell: number) => flow[cell] > 1 && terrain.open(cell, mask);
  for (let attempt = 0; chosen.size < count && attempt < count * 28 + 1000; attempt++) {
    const cell = Math.floor(random(seed ^ Math.imul(attempt + 1, 0x9e3779b1)) * flow.length);
    if (isFree(cell)) chosen.add(cell);
  }
  for (let cell = 0; chosen.size < count && cell < flow.length; cell++) {
    if (isFree(cell)) chosen.add(cell);
  }
  const cells = [...chosen];
  return cells.length ? Array.from({ length: count }, (_, index) => cells[index % cells.length]) : cells;
}

export function spawnNear(
  terrain: CrowdField, flow: Uint16Array, mask: number, point: Point, count: number, radius: number,
  seed: number, used: Set<number>, nearby: Uint16Array,
) {
  if (!count) return [];
  const open = terrain.nearest(point, mask, flow, 20);
  const origin = open < 0 ? terrain.nearest(point, 0, flow, 32) : open;
  if (origin < 0) return [];
  terrain.localFlow([origin], open < 0 ? 0 : mask, Math.ceil(radius / cellSize) + 1, nearby);
  const candidates: number[] = [];
  const shared: number[] = [];
  terrain.visitArea(terrain.x(origin), terrain.y(origin), radius, cell => {
    if (!nearby[cell] || flow[cell] <= 1) return;
    if (used.has(cell)) shared.push(cell);
    else candidates.push(cell);
  });
  if (!candidates.length && shared.length) candidates.push(...shared);
  if (!candidates.length && flow[origin] > 1) candidates.push(origin);
  const cells = [];
  for (let index = 0; index < count && candidates.length; index++) {
    const slot = index % candidates.length;
    const pick = slot + Math.floor(random(seed ^ Math.imul(index + 1, 0x85ebca6b)) * (candidates.length - slot));
    [candidates[slot], candidates[pick]] = [candidates[pick], candidates[slot]];
    const cell = candidates[slot];
    cells.push(cell);
    used.add(cell);
  }
  return cells;
}
