import { drawVehicleArt } from './vehicle-art.ts';
import { drawCharacter, type Joint, type Look, type Pose } from './character-art.ts';
import type { Civilian } from './convoy.ts';
import { civilianProfiles } from './civilian-profiles.ts';
import { bites, riseDuration, type Encounter, type Zombie } from './outbreak.ts';
import type { Point } from './routing.ts';
import { facingIndex, facingStep, spriteFacings } from './sprite-heading.ts';
import { vehicleWidth, type Soldier } from './defense.ts';

export const civilianCell = 80;
export const civilianCellHeight = 96;
const fullTurn = Math.PI * 2;
const zombieProfile = {
  role: 'infected',
  height: 0.96, build: 0.96, stride: 2.04, armSwing: 0.37, pace: 1,
  hairStyle: 'short', colors: ['#be6755', '#4a3434', '#a7aa80', '#322826'],
} as const;
const infantryProfile = {
  role: 'infantry',
  height: 1.02, build: 1.03, stride: 1.9, armSwing: 0.22, pace: 1,
  hairStyle: 'short', colors: ['#819575', '#394c3c', '#b99075', '#263c35'],
} as const;
const soldierModels = {
  infantry: infantryProfile,
  sniper: { role: 'sniper', height: 0.99, build: 0.87, stride: 1.82, armSwing: 0.15, pace: 1,
    hairStyle: 'short', colors: ['#a29b70', '#494c3e', '#bc9274', '#3b4439'] },
  medic: { role: 'medic', height: 1.01, build: 1.02, stride: 1.83, armSwing: 0.24, pace: 1,
    hairStyle: 'short', colors: ['#688f8b', '#34494b', '#b99075', '#223a3b'] },
} as const;
const mutantProfile = {
  role: 'brute',
  height: 1.25, build: 1.40, stride: 1.85, armSwing: 0.31, pace: 1,
  hairStyle: 'short', colors: ['#895758', '#43363d', '#ac8279', '#503b43'],
} as const;
const soldierTypes = Object.keys(soldierModels) as (keyof typeof soldierModels)[];
const civilianModels = civilianProfiles.map((profile, outfit) => ({ ...profile, role: 'civilian' as const, outfit }));
const infectedModels = [
  zombieProfile,
  { ...zombieProfile, armSwing: .23, colors: ['#848070', '#544a45', '#a2ab88', '#403631'] },
  { ...zombieProfile, build: .89, armSwing: .49, hairStyle: 'ponytail', colors: ['#805b69', '#45494b', '#a2a985', '#403333'] },
] as const;
const infectedPalette = civilianModels.length;
const brutePalette = infectedPalette + infectedModels.length;
const soldierPalette = brutePalette + 1;
const spriteModels = [...civilianModels, ...infectedModels, mutantProfile, ...soldierTypes.map(type => soldierModels[type])];
type ActorModel = Look & { height: number; stride: number; armSwing: number };
const infectedLook = (zombie: Zombie) => (zombie.random >>> 0) % infectedModels.length;
export const civilianPalettes = spriteModels.length;
export const civilianAnchor = [0.5, 64 / civilianCellHeight] as const;
export const civilianPixelsPerMeter = 14;
export const civilianScale = 0.76;
const runningFrames = 20;
const waitingFrames = 4;
export const civilianFrames = runningFrames + waitingFrames;
const stanceFraction = 0.34;
const columns = 50;
const rowsPerPage = 42;
export const framesPerAtlas = columns * rowsPerPage;
const attackFrames = 8;
const riseFrames = 7;
const attackFrameCount = bites.length * attackFrames;
const victimFrames = attackFrameCount + 1 + riseFrames;
const victimBase = civilianPalettes * spriteFacings * civilianFrames;
const attackerBase = victimBase + civilianProfiles.length * spriteFacings * victimFrames;
const mutantAttackBase = attackerBase + infectedModels.length * spriteFacings * attackFrameCount;
const crawlerBase = mutantAttackBase + spriteFacings * attackFrameCount;
const crawlerFrames = 16;
const slamFrames = 10;
const vehicleBase = crawlerBase + spriteFacings * crawlerFrames;
const actionBase = vehicleBase + spriteFacings * 3;
const slamBase = actionBase + spriteFacings * 3 * 4;
export const atlasFrameCount = slamBase + spriteFacings * slamFrames;
const vehicles = ['jeep', 'carrier', 'tank'] as const;

function drawVehicle(context: CanvasRenderingContext2D, heading: number, type: Soldier['type']) {
  if (drawVehicleArt(context, heading, type)) return;
  const heavy = type === 'tank';
  const width = vehicleWidth(type);
  const length = heavy ? 2.0 : type === 'carrier' ? 1.75 : 1.48;
  context.rotate(heading);
  context.fillStyle = '#111918';
  for (const side of [-1, 1]) {
    if (type !== 'jeep') context.fillRect(-length, side * width * 0.82 - 0.18, length * 2, 0.36);
    else for (const end of [-1, 1]) context.fillRect(end * 0.85 - 0.24, side * width * 0.8 - 0.15, 0.48, 0.3);
  }
  context.fillStyle = heavy ? '#647252' : type === 'carrier' ? '#74826a' : '#8b8b65';
  context.beginPath();
  context.roundRect(-length * .94, -width * .72, length * 1.88, width * 1.44, .25);
  context.fill();
  context.fillStyle = '#38483e';
  context.fillRect(length * .28, -width * .56, .36, width * 1.12);
  context.beginPath();
  context.roundRect(-.62, -width * .45, heavy ? 1.25 : .74, width * .9, .23);
  context.fill();
  context.fillStyle = '#171f21';
  context.fillRect(0, -.09, heavy ? 2.15 : 1.06, .18);
}

function drawCrawler(context: CanvasRenderingContext2D, heading: number, frame: number) {
  const phase = frame / crawlerFrames * fullTurn;
  const c = Math.cos(heading), s = Math.sin(heading);
  const project = (forward: number, side: number, height: number): Point =>
    [forward * c - side * s, (forward * s + side * c) * .85 - height];
  const segments = Array.from({ length: 4 }, (_, i) => ({
    i, forward: 1.22 - i * .76, sway: Math.sin(phase - i * .88) * (.11 + i * .028),
  })).sort((a, b) => (a.forward - b.forward) * s + (a.sway - b.sway) * c);
  const [shadowX, shadowY] = project(.14, 0, 0);
  context.fillStyle = '#1520209a';
  context.beginPath();
  context.ellipse(shadowX, shadowY, 1.65, .50, heading, 0, fullTurn);
  context.fill();

  for (const { i, forward, sway } of segments) {
    const drawArm = (side: number) => {
      const swing = Math.sin(phase - i * 1.22 + (side > 0 ? Math.PI : 0));
      const lift = Math.max(0, swing) * .28;
      const hand = project(forward + .05 + swing * .34, sway + side * .68, .055 + lift);
      context.beginPath();
      context.moveTo(...project(forward, sway + side * .23, .48 - i * .035));
      context.lineTo(...project(forward - .29 + swing * .13, sway + side * .58, .27 + lift));
      context.lineTo(...hand);
      context.lineWidth = .19;
      context.strokeStyle = '#513437';
      context.stroke();
      context.lineWidth = .118;
      context.strokeStyle = '#b48177';
      context.stroke();
      for (const offset of [-.09, 0, .09]) {
        context.beginPath();
        context.moveTo(...hand);
        context.lineTo(...project(forward + .20 + swing * .34, sway + side * .71 + offset, .025 + lift));
        context.lineWidth = .037;
        context.strokeStyle = '#dec0a8';
        context.stroke();
      }
    };
    const farSide = c > 0 ? -1 : 1;
    drawArm(farSide);
    const [x, y] = project(forward, sway, .41 - i * .055);
    context.save();
    context.translate(x, y);
    context.rotate(Math.atan2(s * .85, c));
    const skin = context.createLinearGradient(0, -.36, 0, .36);
    skin.addColorStop(0, '#c8a18f');
    skin.addColorStop(.42, '#976664');
    skin.addColorStop(1, '#563641');
    context.beginPath();
    context.ellipse(0, 0, .49 - i * .025, .35 - i * .044, 0, 0, fullTurn);
    context.fillStyle = skin;
    context.fill();
    context.strokeStyle = '#51373c';
    context.lineWidth = .055;
    context.stroke();
    for (let rib = 0; rib < 3; rib++) {
      context.beginPath();
      context.moveTo(.18 - rib * .14, -.22 + i * .027);
      context.quadraticCurveTo(.32 - rib * .14, 0, .10 - rib * .14, .22 - i * .027);
      context.strokeStyle = '#deb69c88';
      context.lineWidth = .045;
      context.stroke();
    }
    context.restore();
    if (i === 0) {
      const [headX, headY] = project(forward + .33, sway, .68);
      context.fillStyle = '#bda18c';
      context.beginPath();
      context.ellipse(headX, headY, .21, .23, 0, 0, fullTurn);
      context.fill();
      if (s > -.44) {
        const [jawX, jawY] = project(forward + .48, sway, .59);
        context.fillStyle = '#482931';
        context.beginPath();
        context.ellipse(jawX, jawY, .114, .067, 0, 0, fullTurn);
        context.fill();
      }
    }
    drawArm(-farSide);
  }
}

export function civilianFrameOrigin(index: number): Point {
  return [(index % columns) * civilianCell, Math.floor(index % framesPerAtlas / columns) * civilianCellHeight];
}


function bentKnee(hip: Joint, ankle: Joint): Joint {
  const thigh = 0.55;
  const shin = 0.52;
  const forward = ankle[1] - hip[1];
  const down = ankle[2] - hip[2];
  const length = Math.hypot(forward, down);
  const reach = Math.min(length, thigh + shin - 0.001);
  const along = (thigh * thigh - shin * shin + reach * reach) / (2 * reach);
  const bend = Math.sqrt(Math.max(0, thigh * thigh - along * along));
  return [
    (hip[0] + ankle[0]) / 2,
    hip[1] + (forward * along - down * bend) / length,
    hip[2] + (down * along + forward * bend) / length,
  ];
}

function drawPose(context: CanvasRenderingContext2D, heading: number, frame: number, model: ActorModel, action = 0, progress = 0) {
  const waiting = frame >= runningFrames;
  const phase = frame / runningFrames;
  const breath = waiting ? Math.sin((frame - runningFrames) / waitingFrames * fullTurn) * .023 : 0;
  const infected = model.role === 'infected' || model.role === 'brute';
  const soldier = model.role === 'infantry' || model.role === 'sniper' || model.role === 'medic';
  const older = model.hairStyle === 'receding' || model.hairStyle === 'bun';
  const crouch = action === 1 ? .61 : action === 2 ? .21 : action === 3 ? .10 : 0;
  const bob = waiting ? breath - crouch : -Math.cos((phase - .1) * fullTurn * 2) * .031;
  const slam = action === 4 ? ease(progress / .66) : 0;
  const swingDown = action === 4 ? ease((progress - .66) / .34) : 0;
  const lean = action === 4 ? -.26 * slam + .73 * swingDown
    : waiting ? infected ? .19 : .07 : (infected ? .39 : soldier ? .18 : older ? .15 : .27) + Math.sin(phase * fullTurn * 2) * .052;
  const twist = waiting ? 0 : Math.cos(phase * fullTurn) * (infected ? .069 : .035);
  const hip: Joint = [0, 0, 1.01 + bob];
  const shoulders: Joint = [twist, lean, 1.79 + bob - swingDown * .23];
  const head: Joint = [infected ? -.09 + twist : waiting ? breath * 1.4 : twist, lean + .12, 2.08 + bob - swingDown * .27];

  function limb(side: number): [Joint, Joint, Joint, Joint] {
    const asymmetry = infected && side > 0 ? .06 : 0;
    const step = (phase + (side > 0 ? .5 : 0) + asymmetry) % 1;
    const stance = step < stanceFraction;
    const swing = (step - stanceFraction) / (1 - stanceFraction);
    const stride = model.stride / (civilianScale * model.height);
    const reach = stanceFraction * stride / 2;
    const footForward = waiting ? side * .13 : stance ? reach - step * stride : -reach + ease(swing) * reach * 2;
    const lift = waiting || stance ? 0 : Math.sin(swing * Math.PI) ** 1.2 * (older ? .39 : soldier ? .50 : .65);
    const foot: Joint = [side * .17, footForward, lift + .065];
    const knee = bentKnee([side * .14, -side * twist, hip[2]], foot);
    const armSwing = waiting ? side * .10 : -Math.cos((step - .08) * fullTurn) * model.armSwing;
    const elbow: Joint = [side * (infected ? .43 : .35), lean + armSwing - .16, 1.39 + bob];
    const hand: Joint = [side * .32, lean + armSwing + (infected ? .38 : .22), 1.57 + bob + (waiting && infected ? .08 : 0)];
    if (soldier) {
      elbow[1] = lean - .03 + armSwing * .26;
      hand[0] = side > 0 ? .06 : -.08;
      hand[1] = lean + (side > 0 ? .23 : .48);
      hand[2] = 1.52 + bob;
      if (action === 1) {
        hand[0] = side * .26;
        hand[1] = lean + .44;
        hand[2] = .48 + Math.sin(progress * Math.PI) * .18;
      }
      if (action === 3 && side > 0) hand[2] -= Math.sin(progress * Math.PI) * .28;
    }
    if (action === 4) {
      elbow[2] += slam * .68 - swingDown * .59;
      hand[1] += slam * .19 + swingDown * .48;
      hand[2] += slam * 1.05 - swingDown * 1.03;
    }
    return [knee, foot, elbow, hand];
  }

  drawCharacter(context, heading, [hip, shoulders, head, ...limb(-1), ...limb(1)], model, action);
}

export function drawCivilianAtlases() {
  const contexts = Array.from({ length: Math.ceil(atlasFrameCount / framesPerAtlas) }, (_, page) => {
    const canvas = document.createElement('canvas');
    canvas.width = civilianCell * columns;
    canvas.height = civilianCellHeight * Math.ceil(Math.min(framesPerAtlas, atlasFrameCount - page * framesPerAtlas) / columns);
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas unavailable');
    context.lineCap = 'round';
    context.lineJoin = 'round';
    return context;
  });
  function paint(index: number, size: number, draw: (context: CanvasRenderingContext2D) => void) {
    const context = contexts[Math.floor(index / framesPerAtlas)];
    const [x, y] = civilianFrameOrigin(index);
    context.save();
    context.translate(x + civilianAnchor[0] * civilianCell, y + civilianAnchor[1] * civilianCellHeight);
    context.scale(civilianPixelsPerMeter * size, civilianPixelsPerMeter * size);
    draw(context);
    context.restore();
  }

  for (let palette = 0; palette < civilianPalettes; palette++) {
    for (let facing = 0; facing < spriteFacings; facing++) {
      const row = palette * spriteFacings + facing;
      for (let frame = 0; frame < civilianFrames; frame++) {
        const model = spriteModels[palette];
        paint(row * civilianFrames + frame, model.height, context =>
          drawPose(context, facing * facingStep, frame, model));
      }
    }
  }

  for (let facing = 0; facing < spriteFacings; facing++) {
    const heading = facing * facingStep;
    for (let palette = 0; palette < civilianProfiles.length; palette++) {
      const start = victimBase + (palette * spriteFacings + facing) * victimFrames;
      const model = civilianModels[palette];
      for (let frame = 0; frame < victimFrames; frame++) {
        const pose = frame < attackFrameCount
          ? reactToBite(Math.floor(frame / attackFrames), frame % attackFrames / (attackFrames - 1))
          : frame === attackFrameCount ? grounded : rise((frame - attackFrameCount - 1) / (riseFrames - 1));
        paint(start + frame, model.height, context =>
          drawCombatFrame(context, heading, model, pose, frame >= attackFrameCount + riseFrames));
      }
    }
    for (let frame = 0; frame < attackFrameCount; frame++) {
      const pose = bitePose(Math.floor(frame / attackFrames), frame % attackFrames / (attackFrames - 1));
      infectedModels.forEach((model, index) =>
        paint(attackerBase + (index * spriteFacings + facing) * attackFrameCount + frame, model.height,
          context => drawCombatFrame(context, heading, model, pose, true)));
      paint(mutantAttackBase + facing * attackFrameCount + frame, mutantProfile.height,
        context => drawCombatFrame(context, heading, mutantProfile, pose, true));
    }
  }
  for (let facing = 0; facing < spriteFacings; facing++) {
    const heading = facing * facingStep;
    for (let frame = 0; frame < crawlerFrames; frame++) {
      paint(crawlerBase + facing * crawlerFrames + frame, 1, context => drawCrawler(context, heading, frame));
    }
    vehicles.forEach((type, index) => paint(vehicleBase + index * spriteFacings + facing, .7,
      context => drawVehicle(context, heading, type)));
    for (let action = 1; action <= 3; action++) for (let frame = 0; frame < 4; frame++) {
      const model = action === 1 ? soldierModels.medic : action === 2 ? soldierModels.sniper : infantryProfile;
      paint(actionBase + ((action - 1) * spriteFacings + facing) * 4 + frame, model.height,
        context => drawPose(context, heading, runningFrames, model, action, frame / 3));
    }
    for (let frame = 0; frame < slamFrames; frame++) {
      paint(slamBase + facing * slamFrames + frame, mutantProfile.height,
        context => drawPose(context, heading, runningFrames, mutantProfile, 4, frame / (slamFrames - 1)));
    }
  }
  return contexts.map(context => context.canvas);
}

// Hip, shoulders, head, then knee, foot, elbow and hand for each side.
type Puppet = Pose;
const upright: Puppet = [
  [0, 0, 1], [0, 0.07, 1.78], [0, 0.13, 2.12],
  [-0.19, 0.18, 0.53], [-0.2, 0.22, 0.07], [-0.41, 0.14, 1.36], [-0.46, 0.36, 1.54],
  [0.19, -0.18, 0.55], [0.2, -0.22, 0.07], [0.41, -0.07, 1.37], [0.42, 0.2, 1.5],
];
const grounded: Puppet = [
  [0, 0, 0.12], [0, 0.64, 0.1], [0.05, 0.99, 0.09],
  [-0.17, -0.43, 0.09], [-0.29, -0.87, 0.06], [-0.38, 0.36, 0.08], [-0.6, 0.53, 0.06],
  [0.2, -0.48, 0.08], [0.31, -0.88, 0.06], [0.4, 0.38, 0.08], [0.57, 0.61, 0.06],
];
const kneeling: Puppet = [
  [0, -0.18, 0.57], [0, 0.39, 0.88], [0.05, 0.66, 1.02],
  [-0.2, 0.07, 0.15], [-0.25, -0.48, 0.07], [-0.36, 0.49, 0.5], [-0.39, 0.55, 0.07],
  [0.2, -0.46, 0.26], [0.2, -0.75, 0.07], [0.36, 0.55, 0.56], [0.39, 0.7, 0.1],
];
const shoulderRecoil: Puppet = [
  [0, 0, 0.95], [-0.19, 0.28, 1.63], [-0.32, 0.45, 1.94],
  [-0.24, 0.31, 0.49], [-0.32, 0.31, 0.07], [-0.57, 0.06, 1.36], [-0.25, 0.25, 1.69],
  [0.23, -0.31, 0.47], [0.22, -0.46, 0.07], [0.34, 0.27, 1.53], [0.52, 0.5, 1.71],
];
const armRecoil: Puppet = [
  [0.02, 0.02, 0.94], [0.14, 0.24, 1.69], [0.25, 0.46, 1.96],
  [-0.19, -0.24, 0.47], [-0.28, -0.47, 0.07], [-0.49, -0.26, 1.48], [-0.66, -0.48, 1.36],
  [0.28, 0.35, 0.5], [0.34, 0.41, 0.07], [0.45, 0.41, 1.47], [0.68, 0.63, 1.56],
];

function ease(progress: number) {
  const t = Math.max(0, Math.min(1, progress));
  return t * t * (3 - 2 * t);
}

function mixPose(a: Puppet, b: Puppet, t: number): Puppet {
  return a.map(([x, y, z], index): Joint => [
    x + (b[index][0] - x) * t,
    y + (b[index][1] - y) * t,
    z + (b[index][2] - z) * t,
  ]) as Puppet;
}

function reactToBite(variant: number, progress: number) {
  const collapse = bites[variant].collapse;
  const recoil = variant === 1 ? armRecoil : shoulderRecoil;
  const flinch = mixPose(upright, recoil, ease(progress / Math.min(collapse, 0.25)));
  return mixPose(flinch, grounded, ease((progress - collapse) / (1 - collapse)));
}

function rise(progress: number) {
  if (progress < 0.57) return mixPose(grounded, kneeling, ease(progress / 0.57));
  return mixPose(kneeling, upright, ease((progress - 0.57) / 0.43));
}

function bitePose(variant: number, progress: number) {
  const reach = ease(progress / 0.32) * (1 - ease((progress - 0.73) / 0.27));
  if (variant === 2) {
    const pin: Puppet = [
      [0, 0.19, 0.51], [0.01, 0.73, 0.6], [0.04, 1.01, 0.46],
      [-0.21, 0.37, 0.26], [-0.24, -0.32, 0.08], [-0.39, 0.61, 0.4], [-0.41, 0.92, 0.17],
      [0.24, 0.06, 0.16], [0.26, -0.48, 0.07], [0.31, 0.72, 0.45], [0.31, 1.04, 0.18],
    ];
    return mixPose(upright, pin, reach);
  }
  const lower = variant === 1;
  const lunge: Puppet = [
    [0, 0.17, 0.92], [0.04, 0.62, lower ? 1.38 : 1.61], [lower ? -0.22 : 0.13, 0.91, lower ? 1.26 : 1.68],
    [-0.19, 0.41, 0.48], [-0.2, 0.49, 0.07], [-0.39, 0.62, 1.31], [-0.29, 1.02, lower ? 1.18 : 1.56],
    [0.21, -0.27, 0.5], [0.24, -0.45, 0.07], [0.46, 0.58, 1.29], [0.34, 0.96, lower ? 1.22 : 1.48],
  ];
  return mixPose(upright, lunge, reach);
}

function drawCombatFrame(context: CanvasRenderingContext2D, heading: number, model: ActorModel, pose: Pose, infected: boolean) {
  const look: Look = infected && model.role === 'civilian'
    ? { ...model, role: 'infected', colors: [model.colors[0], model.colors[1], '#a6aa88', model.colors[3]] } : model;
  drawCharacter(context, heading, pose, look);
}

export function encounterFrame(scene: Encounter, time: number, attacker = false) {
  const turn = attacker ? scene.heading : scene.fallHeading;
  const direction = facingIndex(turn);
  const sample = (progress: number, frames: number) => Math.min(frames - 1, Math.max(0, Math.floor(progress * frames)));
  const attack = scene.variant * attackFrames;
  if (attacker) {
    if (scene.attacker.crawler) {
      return crawlerBase + direction * crawlerFrames + Math.floor((time - scene.start) * 26) % crawlerFrames;
    }
    const base = scene.attacker.mutant ? mutantAttackBase : attackerBase + infectedLook(scene.attacker) * spriteFacings * attackFrameCount;
    return base + direction * attackFrameCount + attack + sample((time - scene.start) / (scene.biteEnd - scene.start), attackFrames);
  }
  const base = victimBase + (scene.victim.profile * spriteFacings + direction) * victimFrames;
  if (time < scene.downAt) return base + attack + sample((time - scene.start) / (scene.downAt - scene.start), attackFrames);
  if (time < scene.riseAt) return base + attackFrameCount;
  return base + attackFrameCount + 1 + sample((time - scene.riseAt) / riseDuration, riseFrames);
}

export function civilianFrame(person: Civilian, index: number, time: number, zombie = false) {
  const glance = time - (person.glanceAt ?? -1);
  const look = !zombie && glance >= 0 && glance < 0.46
    ? Math.sin(glance / 0.46 * Math.PI) * (person.random & 1 ? 0.32 : -0.32) : 0;
  const heading = person.heading + look;
  const waiting = person.status === 'holding' || (person.status === 'sheltered' ? person.speed === 0 : person.pauseUntil > time);
  const facing = facingIndex(heading);
  const infected = zombie ? person as Zombie : undefined;
  if (infected?.crawler) {
    const step = Math.floor(person.travel * 11) % crawlerFrames;
    return crawlerBase + facing * crawlerFrames + step;
  }
  if (infected?.slam) {
    const progress = 1 - (infected.slam.until - time) / 1.15;
    return slamBase + facing * slamFrames + Math.min(slamFrames - 1, Math.max(0, Math.floor(progress * slamFrames)));
  }
  const palette = infected?.mutant ? brutePalette : infected ? infectedPalette + infectedLook(infected) : person.profile;
  const model = spriteModels[palette];
  const frame = waiting || person.speed < .08
    ? runningFrames + Math.floor(time * 5 + index * 1.7) % waitingFrames
    : Math.floor((person.travel / model.stride + index * .27) * runningFrames) % runningFrames;
  return (palette * spriteFacings + facing) * civilianFrames + frame;
}

export function soldierFrame(soldier: Soldier, index: number, time: number) {
  const facing = facingIndex(soldier.hullHeading ?? soldier.heading);
  const type = soldier.type;
  if (type === 'jeep' || type === 'carrier' || type === 'tank') return vehicleBase + vehicles.indexOf(type) * spriteFacings + facing;
  const model = soldierModels[type];
  const action = soldier.treatingUntil > time ? 1 : type === 'sniper' && soldier.speed === 0 ? 2 : type === 'infantry' && soldier.reloadUntil > time ? 3 : 0;
  if (action) return actionBase + ((action - 1) * spriteFacings + facing) * 4 + Math.floor(time * 8) % 4;
  const frame = soldier.speed > .12
    ? Math.floor((soldier.travel / model.stride + index * 0.27) * runningFrames) % runningFrames
    : runningFrames + Math.floor(time * 3 + index * 1.7) % waitingFrames;
  return ((soldierPalette + soldierTypes.indexOf(type)) * spriteFacings + facing) * civilianFrames + frame;
}

export function drawSoldierPreview(canvas: HTMLCanvasElement, type: Soldier['type']) {
  const context = canvas.getContext('2d');
  if (!context) return;
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.save();
  const heading = -facingStep;
  const size = Math.min(canvas.width, canvas.height);
  context.lineCap = 'round';
  context.lineJoin = 'round';
  if (type === 'jeep' || type === 'carrier' || type === 'tank') {
    context.translate(canvas.width / 2, canvas.height / 2);
    context.scale(size * .20, size * .20);
    drawVehicle(context, heading, type);
  } else {
    const model = soldierModels[type];
    context.translate(canvas.width / 2, canvas.height * .86);
    context.scale(size * .32 * model.height, size * .32 * model.height);
    drawPose(context, facingStep, runningFrames, model, type === 'sniper' ? 2 : 0);
  }
  context.restore();
}
