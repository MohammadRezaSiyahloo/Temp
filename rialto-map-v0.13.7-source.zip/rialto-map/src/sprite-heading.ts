export const spriteFacings = 8;
export const facingStep = 2 * Math.PI / spriteFacings;

export function facingIndex(heading: number) {
  return ((Math.round(heading / facingStep) % spriteFacings) + spriteFacings) % spriteFacings;
}

export function facingOffset(heading: number) {
  return heading - Math.round(heading / facingStep) * facingStep;
}
