export const civilianProfiles = [
  { spawnWeight: 4, height: 1.02, build: 1.06, stride: 2.2, armSwing: 0.39, pace: 1.04, hairStyle: 'short', colors: ['#8ba29c', '#454b51', '#e2b38f', '#40302b'] },
  { spawnWeight: 4, height: 0.94, build: 0.89, stride: 2.03, armSwing: 0.37, pace: 1.02, hairStyle: 'ponytail', colors: ['#bf8d5d', '#373e46', '#bd8666', '#392823'] },
  { spawnWeight: 1, height: 0.72, build: 0.85, stride: 1.65, armSwing: 0.35, pace: 0.94, hairStyle: 'short', colors: ['#7198af', '#4b464c', '#e2b394', '#533528'] },
  { spawnWeight: 1, height: 0.68, build: 0.83, stride: 1.55, armSwing: 0.34, pace: 0.93, hairStyle: 'ponytail', colors: ['#b38388', '#3d4d52', '#9d6b50', '#282323'] },
  { spawnWeight: 1, height: 0.97, build: 1.01, stride: 1.83, armSwing: 0.29, pace: 0.88, hairStyle: 'receding', colors: ['#b3b398', '#4d4843', '#d5a27e', '#c6c3b6'] },
  { spawnWeight: 1, height: 0.88, build: 0.91, stride: 1.73, armSwing: 0.28, pace: 0.86, hairStyle: 'bun', colors: ['#a99bbb', '#424551', '#b77e61', '#b8afa5'] },
] as const;
