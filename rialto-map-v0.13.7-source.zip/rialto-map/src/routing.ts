export type Point = [number, number];
export type CrossingId = 'rialto' | 'scalzi' | 'accademia';
export type Link = [number, number, CrossingId?];
export type Crossing = { id: CrossingId; name: string; position: Point };
export type Label = [string, number, number];
export interface Venice {
  size: Point;
  projection: { origin: Point; metersPerDegree: Point };
  nodes: Point[];
  edges: Link[];
  crossings: Crossing[];
  terrain: Record<'water' | 'parks' | 'buildings' | 'plazas' | 'streets' | 'bridges' | 'bridgeDecks' | 'stairs', Point[][]>;
  labels: Record<'districts' | 'landmarks', Label[]>;
}
export type Route = { nodes: number[]; meters: number; crossings: CrossingId[] };
type Arc = { to: number; meters: number; crossing?: CrossingId };

export const distance = (a: Point, b: Point) => Math.hypot(a[0] - b[0], a[1] - b[1]);

export function projectLocation([longitude, latitude]: Point, projection: Venice['projection']): Point {
  const { origin, metersPerDegree } = projection;
  return [(longitude - origin[0]) * metersPerDegree[0], (origin[1] - latitude) * metersPerDegree[1]];
}

export class Queue {
  entries: [number, number][] = [];

  push(entry: [number, number]) {
    let index = this.entries.length;
    this.entries.push(entry);
    while (index > 0) {
      const parent = (index - 1) >> 1;
      if (this.entries[parent][1] <= entry[1]) break;
      this.entries[index] = this.entries[parent];
      index = parent;
    }
    this.entries[index] = entry;
  }

  pop() {
    const first = this.entries[0];
    const last = this.entries.pop();
    if (!last || !this.entries.length) return first;
    let index = 0;
    while (index * 2 + 1 < this.entries.length) {
      let child = index * 2 + 1;
      if (child + 1 < this.entries.length && this.entries[child + 1][1] < this.entries[child][1]) child++;
      if (this.entries[child][1] >= last[1]) break;
      this.entries[index] = this.entries[child];
      index = child;
    }
    this.entries[index] = last;
    return first;
  }
}

export class StreetGraph {
  readonly neighbors: Arc[][];
  readonly walkable: number[];

  readonly nodes: Point[];

  constructor(nodes: Point[], edges: Link[]) {
    this.nodes = nodes;
    this.neighbors = nodes.map(() => []);
    for (const [a, b, crossing] of edges) {
      const meters = Math.max(0.1, distance(nodes[a], nodes[b]));
      this.neighbors[a].push({ to: b, meters, crossing });
      this.neighbors[b].push({ to: a, meters, crossing });
    }
    const seen = new Set<number>();
    let biggest: number[] = [];
    for (let root = 0; root < nodes.length; root++) {
      if (seen.has(root)) continue;
      const component = [root];
      seen.add(root);
      for (let index = 0; index < component.length; index++) {
        for (const arc of this.neighbors[component[index]]) {
          if (seen.has(arc.to)) continue;
          seen.add(arc.to);
          component.push(arc.to);
        }
      }
      if (component.length > biggest.length) biggest = component;
    }
    this.walkable = biggest;
  }

  nearest(point: Point, maxDistance = 55) {
    let nearest: number | undefined;
    for (const node of this.walkable) {
      const meters = distance(this.nodes[node], point);
      if (meters >= maxDistance) continue;
      nearest = node;
      maxDistance = meters;
    }
    return nearest;
  }

  route(start: number, end: number, closed: ReadonlySet<CrossingId>): Route | null {
    const costs = new Float64Array(this.nodes.length).fill(Infinity);
    const previous = new Int32Array(this.nodes.length).fill(-1);
    const crossings: (CrossingId | undefined)[] = [];
    const queue = new Queue();
    costs[start] = 0;
    queue.push([start, distance(this.nodes[start], this.nodes[end])]);
    while (queue.entries.length) {
      const [node, estimate] = queue.pop();
      if (estimate > costs[node] + distance(this.nodes[node], this.nodes[end])) continue;
      if (node === end) {
        const path = [];
        const used = new Set<CrossingId>();
        for (let current = end; current !== -1; current = previous[current]) {
          path.push(current);
          const crossing = crossings[current];
          if (crossing) used.add(crossing);
        }
        return { nodes: path.reverse(), meters: costs[end], crossings: [...used].reverse() };
      }
      for (const arc of this.neighbors[node]) {
        if (arc.crossing && closed.has(arc.crossing)) continue;
        const cost = costs[node] + arc.meters;
        if (cost >= costs[arc.to]) continue;
        costs[arc.to] = cost;
        previous[arc.to] = node;
        crossings[arc.to] = arc.crossing;
        queue.push([arc.to, cost + distance(this.nodes[arc.to], this.nodes[end])]);
      }
    }
    return null;
  }
}
