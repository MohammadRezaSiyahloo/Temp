import type { CrossingId, Point } from './routing.ts';

type Objective =
  | { type: 'evacuate'; fraction: number }
  | { type: 'reopen'; crossing: CrossingId }
  | { type: 'sectors' };

type VeniceMission = {
  name: string;
  objective: string;
  goal: Objective;
  civilianSites: { name: string; point: Point }[];
  extraction: Point;
  infectedSites: Point[];
  infectedPace?: number;
  count: number;
  duration: number;
  night?: boolean;
  closed?: CrossingId[];
  stranded?: boolean;
};

export const veniceMissions = {
  market: {
    name: 'Rialto after dark',
    objective: 'Evacuate at least half of the night market crowd. Injured civilians are sheltering near the market.',
    goal: { type: 'evacuate', fraction: 0.5 },
    civilianSites: [{ name: 'Rialto Market', point: [12.33378, 45.43888] }],
    extraction: [12.3360997, 45.4373248],
    infectedSites: [[12.3328, 45.4394], [12.3331, 45.43965]],
    infectedPace: 3.65,
    count: 60, duration: 215, night: true, stranded: true,
  },
  bridge: {
    name: 'Reopen Rialto',
    objective: 'Open the closed Rialto crossing before the first helicopter leaves, then get at least one civilian out.',
    goal: { type: 'reopen', crossing: 'rialto' },
    civilianSites: [{ name: 'Rialto Market', point: [12.33378, 45.43888] }],
    extraction: [12.3360997, 45.4373248],
    infectedSites: [[12.3328, 45.4394], [12.3331, 45.43965]],
    count: 36, duration: 190, closed: ['rialto'],
  },
  canal: {
    name: 'Both banks of the Grand Canal',
    objective: 'Evacuate at least one civilian from each bank. Stranded groups will wait for an escort.',
    goal: { type: 'sectors' },
    civilianSites: [
      { name: 'San Polo bank', point: [12.33378, 45.43888] },
      { name: 'San Marco bank', point: [12.3384, 45.4387] },
    ],
    extraction: [12.3360997, 45.4373248],
    infectedSites: [[12.3328, 45.4394], [12.3391, 45.4412]],
    infectedPace: 3.65,
    count: 48, duration: 240, stranded: true,
  },
} satisfies Record<string, VeniceMission>;
