import { useEffect, useId, useRef, useState, type KeyboardEvent } from 'react';
import { Icon } from './icons.tsx';

type PickerOption<T> = {
  value: T;
  label: string;
  detail?: string;
  icon?: string;
  disabled?: boolean;
};

export function CommandPicker<T extends string | number>({ label, value, options, onChange }: {
  label: string;
  value: T;
  options: readonly PickerOption<T>[];
  onChange: (value: T) => void;
}) {
  const id = useId();
  const root = useRef<HTMLDivElement>(null);
  const list = useRef<HTMLDivElement>(null);
  const search = useRef({ text: '', time: 0 });
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const selected = options.findIndex(option => option.value === value);
  const current = options[selected];
  const enabled = options.flatMap((option, index) => option.disabled ? [] : [index]);

  useEffect(() => {
    const menu = root.current?.closest('details');
    if (!menu) return;
    function closePicker() {
      if (!menu?.open) setOpen(false);
    }
    menu.addEventListener('toggle', closePicker);
    return () => menu.removeEventListener('toggle', closePicker);
  }, []);

  useEffect(() => {
    if (!open) return;
    list.current?.children[active]?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }, [open, active]);

  function show(index: number) {
    search.current = { text: '', time: 0 };
    setActive(index);
    setOpen(true);
  }

  function choose(index: number) {
    const option = options[index];
    if (!option || option.disabled) return;
    onChange(option.value);
    setOpen(false);
  }

  function handleKey(event: KeyboardEvent<HTMLButtonElement>) {
    const { key } = event;
    if (key === 'Tab') {
      setOpen(false);
      return;
    }
    if (key === 'Escape' && open) {
      event.preventDefault();
      event.stopPropagation();
      setOpen(false);
      return;
    }
    if (key === 'Enter' || key === ' ') {
      event.preventDefault();
      if (open) choose(active);
      else show(enabled.includes(selected) ? selected : enabled[0]);
      return;
    }
    if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(key)) {
      event.preventDefault();
      const first = enabled[0];
      const last = enabled.at(-1) ?? first;
      if (!open) {
        show(key === 'Home' ? first : key === 'End' ? last : enabled.includes(selected) ? selected : key === 'ArrowUp' ? last : first);
      } else if (key === 'Home' || key === 'End') {
        setActive(key === 'Home' ? first : last);
      } else {
        const position = enabled.indexOf(active) + (key === 'ArrowUp' ? -1 : 1);
        setActive(enabled[Math.max(0, Math.min(enabled.length - 1, position))]);
      }
      return;
    }
    if (key.length !== 1 || event.ctrlKey || event.metaKey || event.altKey) return;
    const now = Date.now();
    const prefix = (now - search.current.time < 650 ? search.current.text : '') + key.toLowerCase();
    const match = enabled.find(index => options[index].label.toLowerCase().startsWith(prefix));
    if (match === undefined) return;
    event.preventDefault();
    setOpen(true);
    setActive(match);
    search.current = { text: prefix, time: now };
  }

  return (
    <div className="command-picker" ref={root} onBlur={event => {
      if (!event.currentTarget.contains(event.relatedTarget)) setOpen(false);
    }}>
      <span id={id + '-label'} className="picker-label">{label}</span>
      <button type="button" role="combobox" className="picker-trigger" aria-labelledby={id + '-label'}
        aria-expanded={open} aria-controls={id + '-options'} aria-activedescendant={open && active >= 0 ? id + '-' + active : undefined}
        disabled={!enabled.length} onKeyDown={handleKey}
        onClick={() => open ? setOpen(false) : show(enabled.includes(selected) ? selected : enabled[0])}>
        {current?.icon && <Icon name={current.icon} size={18} />}
        <span className="picker-value">{current?.label}</span>
        {current?.detail && <span className="picker-detail">{current.detail}</span>}
        <span className="picker-chevron"><Icon name="chevron" size={18} /></span>
      </button>
      <div className="picker-options" id={id + '-options'} role="listbox" aria-labelledby={id + '-label'} hidden={!open} ref={list}>
        {options.map((option, index) => (
          <div key={option.value} id={id + '-' + index} role="option" aria-selected={index === selected}
            aria-disabled={option.disabled || undefined} data-active={index === active} className="picker-option"
            onMouseDown={event => event.preventDefault()} onClick={() => choose(index)}>
            {option.icon && <Icon name={option.icon} size={17} />}
            <span className="picker-value">{option.label}</span>
            {option.detail && <span className="picker-detail">{option.detail}</span>}
            <span className="picker-check">{index === selected && <Icon name="check" size={17} />}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
