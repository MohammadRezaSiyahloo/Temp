/**
 * Ground effects for Rialto. Create one BloodDecals instance per mission.
 *
 * Confirmed bullet impact in Defense.tick:
 *   decals.hit([target.x, target.y], shot.from, elapsed);
 * Call inside the successful impact branch, before outbreak.hit removes a target.
 *
 * Victim collapse in Outbreak.advanceEncounters:
 *   decals.bite([scene.victim.x, scene.victim.y], scene.fallHeading, elapsed);
 * Call once when elapsed crosses scene.downAt, before the victim starts rising.
 *
 * Render after the map and before actors using the mission clock. Canvas:
 *   decals.drawCanvas(context, group.elapsed, camera);
 * Pixi: use a Graphics layer between the map and crowd, positioned in world space:
 *   bloodLayer.clear();
 *   decals.draw(group.elapsed, camera, (x, y, rx, ry, angle, alpha, dark) => {
 *     const points = [];
 *     const cos = Math.cos(angle), sin = Math.sin(angle);
 *     for (let i = 0; i < 10; i++) {
 *       const t = i * Math.PI / 5;
 *       const u = Math.cos(t) * rx, v = Math.sin(t) * ry;
 *       points.push(x + u * cos - v * sin, y + u * sin + v * cos);
 *     }
 *     bloodLayer.poly(points).fill({ color: dark ? 0x482328 : 0x773333, alpha });
 *   });
 * The Pixi layer uses the same map origin and zoom as the crowd layer.
 */

const lifetime = 360;
const palette = ['#963333', '#471719'];

/** @typedef {[number, number]} Point */
/** @typedef {{x: number, y: number, zoom: number, width: number, height: number}} Camera */
/** @typedef {{x: number, y: number, rx: number, ry: number, angle: number, shade: number}} Mark */

export class BloodDecals {
  /** @type {{time: number, marks: Mark[]}[]} */
  #stains = [];
  #limit;

  constructor(limit = 700) {
    this.#limit = Number.isFinite(limit) ? Math.max(0, Math.floor(limit)) : 700;
  }

  get size() { return this.#stains.length; }

  /** @param {Point} impact @param {Point} origin @param {number} time */
  hit(impact, origin, time) {
    const angle = Math.atan2(impact[1] - origin[1], impact[0] - origin[0]);
    this.#stamp(impact, angle, time, false);
  }

  /** @param {Point} position @param {number} fallHeading @param {number} time */
  bite(position, fallHeading, time) {
    this.#stamp(position, fallHeading, time, true);
  }

  /** @param {Point} position @param {number} angle @param {number} time @param {boolean} bite */
  #stamp([x, y], angle, time, bite) {
    if (!this.#limit) return;
    let seed = (Math.round(x * 100) ^ Math.imul(Math.round(y * 100), 31) ^ Math.round(time * 1000)) >>> 0;
    const random = () => {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      return seed / 4294967296;
    };
    const forward = Math.cos(angle);
    const side = Math.sin(angle);
    const marks = [{ x, y, rx: bite ? 0.73 : 0.24, ry: bite ? 0.46 : 0.13, angle, shade: Number(bite) }];
    for (let i = 0; i < (bite ? 11 : 12); i++) {
      const along = (0.06 + random() ** 1.45 * 1.42) * (bite ? 0.86 : 1);
      const across = (random() - 0.5) * (bite ? 0.95 : 0.66);
      const radius = 0.025 + random() ** 2 * (i < 3 ? 0.24 : 0.105);
      marks.push({
        x: x + forward * along - side * across,
        y: y + side * along + forward * across,
        rx: radius * (bite ? 1.45 : 2.3),
        ry: radius,
        angle: angle + (random() - 0.5) * 0.6,
        shade: Number(random() > 0.45),
      });
    }
    if (this.#stains.length === this.#limit) this.#stains.shift();
    this.#stains.push({ time, marks });
  }

  /** @param {number} time @param {Camera} camera
   * @param {(x:number, y:number, rx:number, ry:number, angle:number, alpha:number, dark:boolean) => void} ellipse */
  draw(time, camera, ellipse) {
    while (this.#stains.length && time - this.#stains[0].time >= lifetime) this.#stains.shift();
    if (camera.zoom < 1.15) return;
    const halfWidth = camera.width / (camera.zoom * 2) + 1.7;
    const halfHeight = camera.height / (camera.zoom * 2) + 1.7;
    for (const stain of this.#stains) {
      const main = stain.marks[0];
      if (Math.abs(main.x - camera.x) > halfWidth || Math.abs(main.y - camera.y) > halfHeight) continue;
      const alpha = 0.86 * Math.min(1, Math.max(0, (lifetime - (time - stain.time)) / 55));
      for (const mark of stain.marks) ellipse(mark.x, mark.y, mark.rx, mark.ry, mark.angle, alpha, mark.shade === 1);
    }
  }

  /** @param {CanvasRenderingContext2D} context @param {number} time @param {Camera} camera */
  drawCanvas(context, time, camera) {
    context.save();
    const opacity = context.globalAlpha;
    this.draw(time, camera, (x, y, rx, ry, angle, alpha, dark) => {
      context.beginPath();
      context.ellipse(
        (x - camera.x) * camera.zoom + camera.width / 2,
        (y - camera.y) * camera.zoom + camera.height / 2,
        rx * camera.zoom, ry * camera.zoom, angle, 0, Math.PI * 2,
      );
      context.fillStyle = palette[Number(dark)];
      context.globalAlpha = opacity * alpha;
      context.fill();
    });
    context.restore();
  }
}
