import { loadVehicleArt } from './vehicle-art.ts';
import { supportTypes, type SupportType } from './air-support.ts';
import { rooftopAt } from './rooftops.ts';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource-variable/dm-sans';
import '@fontsource/barlow-condensed/latin-600.css';
import '@fontsource/barlow-condensed/latin-700.css';
import '@fontsource/ibm-plex-mono/latin-500.css';
import mapData from '../data/venice.json';
import overviewData from '../data/venice-overview.json';
import scenario from '../data/rialto-scenario.json';
import outbreakScenario from '../data/rialto-outbreak.json';
import type { Overview } from './cartography.ts';
import { CrowdField } from './crowd-field.ts';
import { civilianBoardingSeconds, EvacuationGroup, type ConvoyStatus, type SpawnPlan } from './convoy.ts';
import { drawSoldierPreview } from './civilians.ts';
import { CommandPicker } from './CommandPicker.tsx';
import { Icon } from './icons.tsx';
import { MapView } from './MapView.tsx';
import type { OutbreakRules } from './outbreak.ts';
import { projectLocation, StreetGraph, type CrossingId, type Point, type Venice } from './routing.ts';
import { splitPopulation } from './spawn-planning.ts';
import { deploymentUpgrade, evacuationRadius, hiringBudget, infantryCost, maxSquadSize, squadSize, soldierTypes, vehicleFits, vehicleWidth, type Deployment } from './defense.ts';
import { barricadeCost, barricadeEdges, barricadeGaps, maxBarricadeLength, minBarricadeLength, type Barricade } from './fortifications.ts';
import { reliefSeconds, type ClearanceSector } from './clearance.ts';
import { veniceMissions } from './venice-missions.ts';
import './styles.css';

const data = mapData as unknown as Venice;
const overview = overviewData as unknown as Overview;
const graph = new StreetGraph(data.nodes, data.edges);
const terrain = new CrowdField(data, overview.water);
const pickup = graph.nearest(projectLocation(scenario.pickup as Point, data.projection));
const evacuation = graph.nearest(projectLocation(scenario.evacuation as Point, data.projection));
if (pickup === undefined || evacuation === undefined) throw new Error('Scenario waypoints must be on the street graph.');
const defaults = { start: pickup, end: evacuation };
const outbreakPickup = graph.nearest(projectLocation(outbreakScenario.pickup as Point, data.projection));
const outbreakExit = graph.nearest(projectLocation(outbreakScenario.evacuation as Point, data.projection));
if (outbreakPickup === undefined || outbreakExit === undefined) throw new Error('The outbreak requires pickup and extraction points.');
type Mission = 'outbreak' | 'drill' | 'clearance' | keyof typeof veniceMissions;
type Placement = 'civilians' | 'zombies' | 'soldiers' | 'barricade' | 'end' | 'support';
const crossingNames: Record<CrossingId, string> = { rialto: 'Rialto', scalzi: 'Scalzi', accademia: 'Accademia' };
const project = (point: Point) => projectLocation(point, data.projection);
const origin = (position: Point, pace: number) => ({ position, pace });
type Scenario = {
  name: string;
  waypoints: typeof defaults;
  count: number;
  objective: string;
  rules?: OutbreakRules;
  layout?: SpawnPlan;
  challenge?: (typeof veniceMissions)[keyof typeof veniceMissions]['goal'];
  siteNames?: string[];
  night?: boolean;
  closed?: readonly CrossingId[];
};
const clearanceSectors: ClearanceSector[] = [
  { name: 'Rialto Market', point: project([12.33378, 45.43888]) },
  { name: 'Campo San Polo', point: project([12.3308, 45.4372]) },
  { name: 'San Marco', point: project([12.3376, 45.43403]) },
].map(site => {
  const cell = terrain.nearest(site.point, 0, undefined, 38);
  return { ...site, point: cell < 0 ? site.point : [terrain.x(cell), terrain.y(cell)] as Point };
});
const clearanceInfected = 18;

const missions: Record<Mission, Scenario> = {
  drill: { name: 'Evacuation drill', waypoints: defaults, count: scenario.civilians, objective: scenario.objective },
  outbreak: {
    name: 'Rialto outbreak', waypoints: { start: outbreakPickup, end: outbreakExit },
    count: outbreakScenario.civilians, objective: outbreakScenario.objective,
    rules: { duration: outbreakScenario.duration, downDuration: outbreakScenario.downDuration,
      origins: outbreakScenario.origins.map(item => origin(project(item.location as Point), item.pace)) },
  },
  clearance: {
    name: 'District Clearance', waypoints: { start: outbreakPickup, end: outbreakExit }, count: 0,
    objective: 'Clear three sectors in any order. Hold each for eight seconds so relief can take over.',
    rules: { duration: 900, downDuration: 3, clearance: true,
      origins: clearanceSectors.map(site => origin(site.point, 3.8)) },
    layout: { hired: 8, zombieCount: clearanceInfected, clearanceSectors },
  },
  ...(Object.fromEntries(Object.entries(veniceMissions).map(([id, mission]) => {
    const night = 'night' in mission && mission.night;
    const civilians = mission.civilianSites.map(site => project(site.point));
    const start = graph.nearest(civilians[0]);
    const end = graph.nearest(project(mission.extraction));
    if (start === undefined || end === undefined) throw new Error('Scenario waypoint is outside the street graph.');
    return [id, {
      name: mission.name, waypoints: { start, end }, count: mission.count, objective: mission.objective,
      rules: { duration: mission.duration, downDuration: 3, mutantChance: night ? 0.08 : undefined,
        origins: mission.infectedSites.map((point, i) => origin(project(point), ('infectedPace' in mission ? mission.infectedPace : 4.15) + i * 0.22)) },
      layout: { civilians, rescueGroups: 'stranded' in mission && mission.stranded },
      challenge: mission.goal, siteNames: mission.civilianSites.map(site => site.name),
      night, closed: 'closed' in mission ? mission.closed : undefined,
    } satisfies Scenario];
  })) as Record<keyof typeof veniceMissions, Scenario>),
};
const defaultDuration = outbreakScenario.duration;

const maxStartingZombies = 20_000;

function startingZombieCount(civilians: number, rules: OutbreakRules | undefined, spawns: SpawnPlan) {
  if (!rules) return 0;
  const spawnCount = Array.isArray(spawns.zombies) ? spawns.zombies.length
    : spawns.zombies === 'random' ? 1 : rules.origins.length;
  return Math.min(maxStartingZombies, Math.max(spawnCount, spawns.zombieCount ?? Math.max(8, Math.round(civilians / 4))));
}

function makeGroup(waypoints: typeof defaults, closed: ReadonlySet<CrossingId>, count: number, mission: Mission, spawns: SpawnPlan, seed: number) {
  const rules = missions[mission].rules;
  return new EvacuationGroup(terrain, graph, waypoints.start, waypoints.end, closed, count, scenario.metersPerSecond,
    seed, rules && { ...rules, duration: spawns.roundSeconds ?? rules.duration }, rules ? { ...spawns, soldiers: spawns.soldiers ?? [], zombieCount: startingZombieCount(count, rules, spawns) } : spawns);
}

const readyMessage = (mission: Mission) => mission === 'clearance' ? 'Deploy the eight-person squad and dispatch when ready.'
  : missions[mission].rules
  ? `Place up to ${squadSize} soldiers. Any unassigned soldiers start at extraction.`
  : 'Choose which crossings to keep open, then dispatch the group.';
const startingStats = { evacuated: 0, infected: 0, remaining: defaultDuration, eliminated: 0, aboard: 0, lost: 0, patrol: 0, reloading: 0, waiting: 0, shelterLosses: 0, friendlyFireLosses: 0, overrun: false, breached: 0, coverage: '', lockdown: '', civilianAboard: 0, landing: false, boarding: false, airliftState: '', effects: 0, assisted: 0, treated: 0 };

function CommandMenu({ name, icon, children }: {
  name: string; icon: 'bridge' | 'guard' | 'route' | 'people'; children: ReactNode;
}) {
  return <details className="command-menu" name="rialto-command-menu">
    <summary><Icon name={icon} size={18} /><span>{name}</span></summary>
    <section className="command-sheet" aria-label={name} onClick={event => {
      if (event.target instanceof Element && event.target.closest('[data-close-command]')) {
        const menu = event.currentTarget.parentElement;
        if (menu instanceof HTMLDetailsElement) menu.open = false;
      }
    }}>{children}</section>
  </details>;
}

const unitDescriptions = {
  infantry: 'Carbine · frontline defense',
  sniper: 'Long rifle · rooftop deployment',
  medic: 'Pistol · five treatments',
  jeep: 'Fast support · mounted gun',
  carrier: 'Armored support · mounted gun',
  tank: 'Heavy armor · cannon',
};

function SoldierPreview({ type }: { type: Deployment['type'] }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (canvas.current) drawSoldierPreview(canvas.current, type);
  }, [type]);
  return <canvas ref={canvas} className="unit-preview" width="144" height="136" aria-hidden="true" />;
}

type RunResult = { evacuated: number; aboard: number; civilians: number; troops: number; creditsSpent: number };

function App() {
  const [supportType, setSupportType] = useState<SupportType>('strike');
  const [unitType, setUnitType] = useState<Deployment['type']>('infantry');
  const [, refreshGates] = useState(0);
  const startGateStates = useRef<boolean[]>([]);
  const reopenedInTime = useRef(false);
  const [playSpeed, setPlaySpeed] = useState(1);
  const [mission, setMission] = useState<Mission>('outbreak');
  const [closed, setClosed] = useState<ReadonlySet<CrossingId>>(new Set());
  const [waypoints, setWaypoints] = useState(missions.outbreak.waypoints);
  const [spawns, setSpawns] = useState<SpawnPlan>({});
  const [selection, setSelection] = useState<Placement | null>(null);
  const [barricadeStart, setBarricadeStart] = useState<Point | null>(null);
  const [supportStart, setSupportStart] = useState<Point | null>(null);
  function select(next: Placement | null) {
    setSupportStart(null);
    setBarricadeStart(null);
    setSelection(next);
  }
  const [status, setStatus] = useState<ConvoyStatus>('ready');
  const [{ evacuated, infected, remaining, eliminated, aboard, lost, patrol, reloading, waiting, shelterLosses, friendlyFireLosses, overrun, breached, civilianAboard, landing, boarding, assisted, treated }, setStats] = useState(startingStats);
  const [groupSize, setGroupSize] = useState(missions.outbreak.count);
  const [message, setMessage] = useState(readyMessage('outbreak'));
  const [seed] = useState(() => Math.floor(Math.random() * 0x100000000));
  const runSeed = useRef(seed);
  const frameTime = useRef(0);
  const startCrossings = useRef<ReadonlySet<CrossingId>>(new Set());
  const [lastResult, setLastResult] = useState<RunResult>();
  const [comparison, setComparison] = useState<RunResult>();
  const convoyRef = useRef<EvacuationGroup | null>(null);
  convoyRef.current ??= makeGroup(waypoints, closed, groupSize, mission, spawns, runSeed.current);
  const convoy = convoyRef.current;
  const operation = missions[mission];
  const challenge = operation.challenge;
  const defaultZombiePoints = operation.rules?.origins.map(item => item.position) ?? [];
  const clearance = convoy.clearance;
  const civilianPoints = clearance || spawns.civilians === 'random' ? [] : spawns.civilians ?? [data.nodes[waypoints.start]];
  const zombiePoints = spawns.zombies === 'random' || !operation.rules ? [] : spawns.zombies ?? defaultZombiePoints;
  const zombieTotal = startingZombieCount(groupSize, operation.rules, spawns);
  const roundSeconds = spawns.roundSeconds ?? operation.rules?.duration ?? defaultDuration;
  const zoneRadius = spawns.zoneRadius ?? evacuationRadius;
  const squadCount = convoy.defense?.count ?? squadSize;
  const budget = hiringBudget(groupSize, zombieTotal);
  const barricades = spawns.barricades ?? [];
  const barricadeSpend = barricades.reduce((total, span) => total + barricadeCost(span), 0);
  const upgradeSpend = (spawns.soldiers ?? []).reduce((total, unit) => total + deploymentUpgrade(unit.type), 0);
  const startingSquad = spawns.hired ?? squadSize;
  const credits = budget - startingSquad * infantryCost - barricadeSpend - upgradeSpend
    - (convoy.defense?.reinforcementSpend ?? 0) - convoy.liveBarricadeSpend - convoy.supportSpend;
  const running = status === 'moving' || status === 'holding';
  const editing = !running;
  const canReinforce = !clearance && running && (convoy.defense?.canReinforce(convoy.elapsed) ?? false);
  const canDraw = status === 'ready' || (running && convoy.defense?.phase !== 'departed');
  const minimumBarricadeCost = barricadeCost([[0, 0], [minBarricadeLength, 0]]);
  const selectedUnitCost = deploymentUpgrade(unitType) + (running ? infantryCost : 0);
  const deploymentAvailable = running ? canReinforce : status === 'ready' && (spawns.soldiers?.length ?? 0) < squadCount;
  const canFinishPlacement = selection === 'soldiers' || selection === 'barricade' || selection === 'support';

  function prepare(nextWaypoints: typeof defaults, nextSpawns: SpawnPlan, count: number, feedback: string) {
    if (operation.rules) {
      const spend = (nextSpawns.barricades ?? []).reduce((total, span) => total + barricadeCost(span), 0);
      const nextBudget = hiringBudget(count, startingZombieCount(count, operation.rules, nextSpawns));
      const capacity = Math.min(maxSquadSize, Math.floor((nextBudget - spend) / infantryCost));
      if (capacity < 1) {
        setMessage('Remove a barricade before reducing the population. The new budget must cover at least one soldier.');
        return;
      }
      const hired = Math.min(capacity, nextSpawns.hired ?? squadSize);
      const soldiers = nextSpawns.soldiers?.slice(0, hired);
      const upgrades = (soldiers ?? []).reduce((total, unit) => total + deploymentUpgrade(unit.type), 0);
      if (hired * infantryCost + spend + upgrades > nextBudget) {
        setMessage('The new budget cannot cover this squad. Remove a deployment or barricade first.');
        return;
      }
      nextSpawns = { ...nextSpawns, hired, soldiers };
    }
    const gateStates = new Map(convoy.defense?.fortifications?.gates.map(gate => [gate.span, gate.open]));
    convoyRef.current = makeGroup(nextWaypoints, closed, count, mission, nextSpawns, runSeed.current);
    convoyRef.current.defense?.fortifications?.gates.forEach(gate => { gate.open = gateStates.get(gate.span) ?? false; });
    if (gateStates.size) convoyRef.current.barricadeChanged();
    frameTime.current = 0;
    setWaypoints(nextWaypoints);
    setSpawns(nextSpawns);
    setGroupSize(count);
    setStatus('ready');
    setStats({ ...startingStats, remaining: convoyRef.current.outbreak?.duration ?? defaultDuration });
    setMessage(feedback);
  }

  function toggleCrossing(id: CrossingId) {
    const next = new Set(closed);
    const opening = next.delete(id);
    if (!opening) next.add(id);
    const previous = convoy.route;
    if (opening && challenge?.type === 'reopen' && challenge.crossing === id
      && convoy.elapsed < roundSeconds - civilianBoardingSeconds / 2) reopenedInTime.current = true;
    convoy.replan(next);
    setClosed(next);
    setStatus(convoy.status);
    if (convoy.status === 'arrived' || convoy.status === 'finished') return;
    if (spawns.civilians === 'random') {
      setMessage(`${crossingNames[id]} ${opening ? 'reopened' : 'closed'}.${convoy.stranded ? ` ${convoy.stranded} civilians have no route.` : ''}`);
    } else if (!convoy.route) {
      setMessage(convoy.status === 'moving'
        ? 'All routes to evacuation are blocked. The group will stop at the last reachable point.'
        : 'There is no open route. Reopen a crossing to connect the two points.');
    } else if (convoy.stranded) {
      setMessage(`${convoy.stranded} of ${groupSize} civilians have no route. The others can continue.`);
    } else if (civilianPoints.length > 1) {
      setMessage(`${convoy.routes.length} of ${civilianPoints.length} civilian spawn routes are open.`);
    } else if (!previous || previous.crossings.join() !== convoy.route.crossings.join()) {
      const crossing = convoy.route.crossings.map(item => crossingNames[item]).join(', ');
      setMessage(crossing ? `Route updated via ${crossing}.` : 'A new route is open.');
    } else {
      setMessage(`${crossingNames[id]} ${opening ? 'reopened' : 'closed'}. Current route is still clear.`);
    }
  }

  function place(point: Point) {
    if (!selection || (running && !canFinishPlacement)) return;
    if (selection === 'support') {
      if (terrain.cell(...point) < 0) {
        setMessage('Choose a point inside the playable district.');
        return;
      }
      if (supportType !== 'helicopter' && !supportStart) {
        setSupportStart(point);
        setMessage(supportType === 'gunRun' ? 'Choose the end of the cannon run.' : 'Choose a second point in the direction the F-16 should fly.');
        return;
      }
      if (supportStart && Math.hypot(point[0] - supportStart[0], point[1] - supportStart[1]) < 3) {
        setMessage('Place the second point farther away.');
        return;
      }
      if (convoy.callSupport(supportType, supportStart ?? point, credits, supportStart ? point : undefined)) {
        setMessage(`${supportTypes[supportType].label} inbound`);
        select(null);
      } else setMessage('Support unavailable. Check credits, time remaining, or an active flyby.');
      return;
    }
    if (selection === 'barricade') {
      if (terrain.cell(...point) < 0) {
        setMessage('Choose an endpoint inside the playable district.');
        return;
      }
      const endpoint: Point = [Math.round(point[0] * 10) / 10, Math.round(point[1] * 10) / 10];
      if (!barricadeStart) {
        setBarricadeStart(endpoint);
        setMessage('Choose the other end of the barricade.');
        return;
      }
      const span: Barricade = [barricadeStart, endpoint];
      const length = Math.hypot(endpoint[0] - barricadeStart[0], endpoint[1] - barricadeStart[1]);
      if (length < minBarricadeLength || length > maxBarricadeLength) {
        setMessage(`Draw a barricade between ${minBarricadeLength} and ${maxBarricadeLength} meters long.`);
        return;
      }
      const cost = barricadeCost(span);
      if (cost > credits) {
        setMessage(`This barricade costs ${cost} credits. Shorten it or release a soldier.`);
        return;
      }
      const edges = barricadeEdges(terrain, span);
      const flow = terrain.openFlow(terrain.nearest(data.nodes[waypoints.end]));
      if (![...edges.values()].some(cell => flow[cell])) {
        setMessage('Draw across walkable ground connected to extraction.');
        return;
      }
      const existingSpans = running
        ? convoy.defense?.fortifications?.gates.filter(gate => gate.integrity > 0).map(gate => gate.span) ?? [] : barricades;
      if (existingSpans.some(existing => [...barricadeEdges(terrain, existing).keys()].some(edge => edges.has(edge)))) {
        setMessage('That span overlaps a barricade you already placed.');
        return;
      }
      if (running) {
        const placed = convoy.placeLiveBarricade(span, credits);
        setMessage(placed ? `Barricade placed for ${cost} credits.` : 'Barricade unavailable at this location.');
      } else {
        prepare(waypoints, { ...spawns, barricades: [...barricades, span] }, groupSize, `Barricade placed for ${cost} credits.`);
      }
      setBarricadeStart(null);
      return;
    }
    if (selection === 'end') {
      const node = graph.nearest(point, 38);
      if (node === undefined) {
        setMessage('Choose a street or footpath in the playable district.');
        return;
      }
      const goal = terrain.nearest(data.nodes[node]);
      const flow = terrain.openFlow(goal);
      if (goal < 0 || [...civilianPoints, ...zombiePoints].some(position => {
        const cell = terrain.nearest(position, 0, flow, 20);
        return cell < 0 || flow[cell] === 1;
      })) {
        setMessage('Choose an evacuation point outside the spawn areas and reachable with the bridges open.');
        return;
      }
      prepare({ ...waypoints, end: node }, spawns, groupSize, 'Evacuation moved.');
      select(null);
      return;
    }
    const flow = terrain.openFlow(terrain.nearest(data.nodes[waypoints.end]));
    const mask = terrain.mask(closed);
    if (selection === 'soldiers') {
      const deployments = spawns.soldiers ?? [];
      const clicked = terrain.cell(...point);
      const roof = unitType === 'sniper' && !terrain.open(clicked) ? rooftopAt(point, data.terrain.buildings) : undefined;
      const cell = roof ? terrain.nearest(roof.access, mask, flow, 15) : clicked;
      if (!terrain.open(cell, mask) || !flow[cell]) {
        setMessage('Choose a connected street or, for snipers, a rooftop with street access.');
        return;
      }
      if (!vehicleFits(terrain, cell, mask, unitType)) {
        setMessage('Choose a wider street or square for this vehicle.');
        return;
      }
      const position: Point = roof ? point : [terrain.x(cell), terrain.y(cell)];
      if (running) {
        const deployed = convoy.deployReinforcement({ position, type: unitType, roof }, credits);
        setMessage(deployed ? `${soldierTypes[unitType].label} deployed for ${selectedUnitCost} credits.`
          : 'Deployment unavailable. Check credits, extraction access, and boarding time.');
        return;
      }
      if (deployments.length >= squadCount) return;
      if (deployments.some(existing => terrain.cell(...existing.position) === terrain.cell(...position))) {
        setMessage('A soldier is already assigned to this position.');
        return;
      }
      const upgrade = deploymentUpgrade(unitType);
      if (credits < upgrade) {
        setMessage(`${soldierTypes[unitType].label} costs ${upgrade} additional credits.`);
        return;
      }
      const soldiers = [...deployments, { position, type: unitType, roof }];
      prepare(waypoints, { ...spawns, soldiers }, groupSize, roof
        ? `Sniper posted on an estimated ${roof.height} m rooftop.`
        : `${soldiers.length} of ${squadCount} deployment positions set.`);
      if (soldiers.length === squadCount) select(null);
      return;
    }
    const cell = terrain.nearest(point, mask, flow, 12);
    if (cell < 0 || flow[cell] <= 1) {
      setMessage('Choose walkable ground outside the evacuation zone.');
      return;
    }
    const layout = spawns[selection];
    const points = Array.isArray(layout) ? layout : [];
    if (points.some(position => terrain.cell(...position) === cell)) {
      setMessage('There is already a spawn point here.');
      return;
    }
    const limit = selection === 'civilians' ? groupSize : maxStartingZombies;
    if (points.length >= limit) {
      setMessage(selection === 'civilians' ? 'Increase the crowd size to add another civilian spawn.' : 'The zombie spawn list is full.');
      return;
    }
    const next = [...points, [terrain.x(cell), terrain.y(cell)] as Point];
    prepare(waypoints, { ...spawns, [selection]: next }, groupSize, `${next.length} ${selection === 'civilians' ? 'civilian' : 'zombie'} spawn ${next.length === 1 ? 'point' : 'points'} set.`);
  }

  function reset(nextMission = mission, count = groupSize, keepLayout = true, replay = false) {
    const open = replay ? new Set(startCrossings.current) : new Set(missions[nextMission].closed);
    reopenedInTime.current = false;
    if (!replay) runSeed.current = Math.floor(Math.random() * 0x100000000);
    setComparison(replay ? lastResult : undefined);
    setLastResult(undefined);
    const initial = keepLayout ? waypoints : missions[nextMission].waypoints;
    const layout = keepLayout ? spawns : missions[nextMission].layout ?? {};
    convoyRef.current = makeGroup(initial, open, count, nextMission, layout, runSeed.current);
    if (replay) convoyRef.current.defense?.fortifications?.gates.forEach((gate, index) => {
      gate.open = startGateStates.current[index] ?? false;
    });
    if (replay) convoyRef.current.barricadeChanged();
    frameTime.current = 0;
    setMission(nextMission);
    setGroupSize(count);
    setWaypoints(initial);
    setSpawns(layout);
    setClosed(open);
    setStatus('ready');
    setStats({ ...startingStats, remaining: convoyRef.current.outbreak?.duration ?? defaultDuration });
    select(null);
    setMessage(replay ? 'Same outbreak ready. Adjust your defenses or dispatch to retry.' : readyMessage(nextMission));
  }

  function frame(seconds: number) {
    const active = convoyRef.current!;
    const before = active.status;
    const previousSample = Math.floor(active.elapsed * 6);
    // A fixed step keeps replay outcomes independent of render rate and speed.
    const step = 1 / 30;
    const large = active.initialPopulation >= 6000;
    const elapsed = Math.min(seconds, large ? step : 0.1) * playSpeed;
    if (before === 'ready' || before === 'finished' || before === 'arrived') frameTime.current = 0;
    else frameTime.current += elapsed;
    while (frameTime.current >= step) {
      active.tick(step);
      frameTime.current -= step;
    }
    if (active.status !== before || Math.floor(active.elapsed * 6) !== previousSample) {
      const next = {
        evacuated: active.evacuated,
        assisted: active.assisted,
        treated: active.treated,
        waiting: active.waiting,
        civilianAboard: active.civilianAboard,
        landing: active.aircraft.length > 0,
        boarding: active.boardingOpen,
        effects: active.supportRuns.length || active.defense?.groundFires.length || active.defense?.fortifications?.gates.some(gate => gate.windupUntil !== undefined || (gate.slamAt !== undefined && active.elapsed - gate.slamAt < 1)) ? active.elapsed : 0,
        airliftState: active.aircraft.map(flight => [flight.boarded, flight.departed, flight.aborted].join('/')).join(','),
        shelterLosses: active.shelterLosses,
        friendlyFireLosses: active.friendlyFireLosses,
        overrun: active.defense?.overrun ?? false,
        lockdown: (active.defense?.fortifications?.gates.map(gate => `${gate.locked}:${gate.nearbyInfected}`).join(',') ?? '') + '|' + [...active.gateQueueCounts.values()].join(','),
        coverage: active.defense?.coverage.map(gate => [gate.guards, gate.integrity].join('/')).join(',') ?? '',
        breached: active.defense?.fortifications?.gates.filter(gate => gate.integrity <= 0).length ?? 0,
        infected: active.outbreak?.infected ?? 0,
        remaining: Math.max(0, Math.ceil((active.outbreak?.duration ?? 0) - active.elapsed)),
        eliminated: active.defense?.eliminated ?? 0,
        aboard: active.defense?.aboard ?? 0,
        lost: active.defense?.lost ?? 0,
        patrol: active.defense?.soldiers.filter(soldier => soldier.state === 'patrol').length ?? 0,
        reloading: active.defense?.active.filter(soldier => soldier.reloadUntil > active.elapsed).length ?? 0,
      };
      setStats(old => (Object.keys(next) as (keyof typeof next)[]).every(key => old[key] === next[key]) ? old : next);
    }
    if (active.status !== before) {
      setStatus(active.status);
      if (active.status === 'finished') {
        select(null);
        const infected = active.outbreak?.infected ?? 0;
        if (active.defense) setLastResult({
          evacuated: active.evacuated, aboard: active.defense.aboard, civilians: groupSize,
          troops: active.defense.count, creditsSpent: startingSquad * infantryCost + barricadeSpend + upgradeSpend
            + active.defense.reinforcementSpend + active.liveBarricadeSpend + active.supportSpend,
        });
        if (active.clearance) {
          setMessage(`${active.clearance.secured === active.clearance.sectors.length ? 'District secured' : 'Operation ended'} · ${active.clearance.secured}/${active.clearance.sectors.length} sectors handed over.`);
          return active;
        }
        const squad = active.defense ? ` ${active.defense.aboard}/${active.defense.count} soldiers extracted.` : '';
        setMessage(`${active.evacuated} evacuated · ${infected} infected · ${active.people.length - active.evacuated - infected - active.shelterLosses - active.friendlyFireLosses} left behind.${active.shelterLosses ? ` ${active.shelterLosses} lost at pickup.` : ''}${active.friendlyFireLosses ? ` ${active.friendlyFireLosses} killed by friendly fire.` : ''}${squad}`);
      } else if (active.status === 'arrived') {
        setMessage(`All ${groupSize} civilians reached the evacuation point.`);
      } else if (active.status === 'holding') {
        setMessage('Civilians are holding. Reopen a crossing to give them a route.');
      } else {
        setMessage('Civilians are moving toward extraction.');
      }
    }
    return active;
  }

  function dispatch() {
    if (convoy.people.length !== groupSize || (convoy.outbreak && convoy.outbreak.zombies.length !== zombieTotal)) {
      setMessage('A spawn area could not fit its assigned group. Move the point onto open ground.');
      return;
    }
    if (challenge?.type === 'reopen') reopenedInTime.current = !closed.has(challenge.crossing);
    startCrossings.current = new Set(closed);
    startGateStates.current = convoy.defense?.fortifications?.gates.map(gate => gate.open) ?? [];
    convoy.dispatch();
    setStatus(convoy.status);
    setMessage(clearance ? 'Select a squad with Patrol, then click a sector to move in.' : convoy.defense ? 'Use Deploy for reinforcements or Bridges to manage crossings.'
      : 'Civilians are finding their own way to evacuation. You can still change crossings.');
  }

  function resizeCrowd(count: number) {
    prepare(waypoints, spawns, count, readyMessage(mission));
  }

  const groupStatus = { ready: 'Awaiting dispatch', moving: 'In transit', holding: 'Holding position', arrived: 'Evacuated', finished: 'Extraction ended' }[status];
  const timer = status === 'finished' ? clearance ? (clearance.secured === clearance.sectors.length ? 'District secured' : 'Operation ended') : 'Extraction closed' : `${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, '0')} left`;
  function changeLayout(kind: 'civilians' | 'zombies', layout: SpawnPlan['civilians'], feedback: string) {
    prepare(waypoints, { ...spawns, [kind]: layout }, groupSize, feedback);
  }

  function removeSpawn(kind: 'civilians' | 'zombies' | 'soldiers', index: number) {
    if (selection !== kind) return;
    if (kind === 'soldiers') {
      prepare(waypoints, { ...spawns, soldiers: spawns.soldiers?.filter((_, current) => current !== index) }, groupSize,
        'Deployment removed. That soldier will start at extraction.');
      return;
    }
    const points = spawns[kind];
    if (!Array.isArray(points)) return;
    const next = points.filter((_, current) => current !== index);
    changeLayout(kind, next.length ? next : undefined, next.length ? 'Spawn point removed.' : 'Default spawn points restored.');
  }

  function spawnControls(kind: 'civilians' | 'zombies', count: number) {
    const layout = spawns[kind];
    const name = kind === 'civilians' ? 'Civilian spawns' : 'Zombie spawns';
    const selected = selection === kind;
    return (
      <div className="spawn-row">
        <span><i className={kind === 'civilians' ? 'point-dot pickup-dot' : 'point-dot zombie-dot'} />{name}<small>{layout === 'random' ? 'Random' : count}</small></span>
        <div className="spawn-actions">
          <button data-close-command disabled={!editing} aria-pressed={selected} aria-label={selected ? `Done placing ${kind}` : `Place ${name.toLowerCase()}`}
            onClick={() => select(selected ? null : kind)}>{selected ? 'Done' : 'Place'}</button>
          <button disabled={!editing} aria-pressed={layout === 'random'} aria-label={`Randomize ${name.toLowerCase()}`} onClick={() => {
            select(null);
            changeLayout(kind, layout === 'random' ? undefined : 'random', layout === 'random'
              ? 'Default spawn points restored.'
              : `${kind === 'civilians' ? 'Civilians' : 'Zombies'} will spawn across the district.`);
          }}>Random</button>
          {layout && layout !== 'random' && <button disabled={!editing} aria-label={`Restore default ${name.toLowerCase()}`} onClick={() => {
            select(null);
            changeLayout(kind, undefined, 'Default spawn points restored.');
          }}>Default</button>}
        </div>
      </div>
    );
  }

  const civilianAllocation = splitPopulation(groupSize, civilianPoints.length);
  const zombieAllocation = splitPopulation(zombieTotal, zombiePoints.length);
  const defensePhase = convoy.defense?.phase;
  const lockedGates = convoy.defense?.fortifications?.gates.filter(gate => gate.locked).length ?? 0;
  const airlift = landing && defensePhase !== 'departed' && !overrun;
  const radioCue = defensePhase === 'departed' ? (evacuated + aboard ? 'Aircraft clear of pickup.' : 'Pickup closed. No aircraft departed with passengers.')
    : overrun ? 'Pickup overrun. Civilian boarding suspended.' : boarding ? 'Boarding open. Move to an aircraft with seats.'
      : airlift ? 'Stand by for the next boarding window.' : lockedGates ? `${lockedGates} ${lockedGates === 1 ? 'gate' : 'gates'} locked. Civilian passage suspended.` : '';
  const defenseStatus = defensePhase === 'departed' ? (evacuated + aboard ? 'Helicopters departed' : 'Extraction ended') : defensePhase === 'fallback' ? 'Falling back to transport'
    : status === 'ready' ? `${zoneRadius * 2} m extraction zone` : `${patrol} on patrol · ${reloading} reloading`;
  const speedControls = <div className="speed-controls" role="group" aria-label="Simulation speed">
    {[1, 2, 4].map(speed => <button key={speed} aria-pressed={playSpeed === speed} onClick={() => setPlaySpeed(speed)}>{speed}×</button>)}
  </div>;
  const objectiveReached = challenge?.type === 'evacuate' ? evacuated >= Math.ceil(groupSize * challenge.fraction)
    : challenge?.type === 'reopen' ? reopenedInTime.current && evacuated > 0
    : challenge?.type === 'sectors' && (convoy.evacuatedSectors.get(0) ?? 0) > 0 && (convoy.evacuatedSectors.get(1) ?? 0) > 0;
  const objectiveDetail = challenge?.type === 'evacuate' ? `${evacuated} / ${Math.ceil(groupSize * challenge.fraction)} evacuated`
    : challenge?.type === 'reopen' ? `Rialto ${reopenedInTime.current ? 'reopened in time' : 'must reopen before wave one departs'} · ${evacuated} evacuated`
    : challenge?.type === 'sectors' ? operation.siteNames?.map((name, index) => `${name} · ${convoy.evacuatedSectors.get(index) ?? 0} out`).join(' | ') : '';
  const coverage = status === 'ready' ? undefined : convoy.defense?.coverage;
  const inspectGaps = (span: Barricade) => barricadeGaps(terrain, span, terrain.mask(closed),
    convoy.defense?.fortifications?.gates.filter(gate => gate.integrity > 0).map(gate => gate.span) ?? barricades);
  const missionActions = (
    <div className="mission-actions">
      {status === 'ready' && <button className="dispatch" disabled={!convoy.canDispatch || !!selection} onClick={dispatch}><Icon name="play" size={21} /> Dispatch group</button>}
      <button className="reset" aria-label="Reset scenario" title="Reset scenario" onClick={() => reset()}><Icon name="reset" size={21} /></button>
    </div>
  );

  const deploymentControls = (
    <div className="deployment-controls">
      {(!clearance || !running) && <div className="unit-choices" role="group" aria-label="Choose a unit to deploy">
        {(Object.keys(soldierTypes) as Deployment['type'][]).map(type => {
          const cost = deploymentUpgrade(type) + (running ? infantryCost : 0);
          return <button key={type} type="button" className="unit-choice" data-close-command
            disabled={!deploymentAvailable || credits < cost} aria-pressed={selection === 'soldiers' && unitType === type}
            onClick={() => {
              setUnitType(type);
              setMessage(running ? `${soldierTypes[type].label} · ${cost} credits per reinforcement.`
                : `Choose a deployment point for ${soldierTypes[type].label.toLowerCase()}.`);
              select('soldiers');
            }}>
            <SoldierPreview type={type} />
            <span className="unit-choice-copy"><strong>{soldierTypes[type].label}</strong><small>{unitDescriptions[type]}</small></span>
            <span className="unit-choice-price">{cost ? `${running ? '' : '+'}${cost} cr` : 'Included'}</span>
          </button>;
        })}
      </div>}
      <div className="deployment-actions spawn-actions">
        <button data-close-command disabled={selection !== 'barricade' && (!canDraw || credits < minimumBarricadeCost)}
          aria-pressed={selection === 'barricade'} onClick={() => {
            if (selection !== 'barricade') setMessage('Draw across a street to place a gated barricade.');
            select(selection === 'barricade' ? null : 'barricade');
          }}>
          {selection === 'barricade' ? 'Done drawing' : 'Draw barricade'}
        </button>
        {editing && barricades.length > 0 && <button onClick={() =>
          prepare(waypoints, { ...spawns, barricades: barricades.slice(0, -1) }, groupSize, 'Last barricade removed. Credits refunded.')
        }>Undo barricade</button>}
      </div>
      {selection === 'soldiers' && <p className="select-help">{vehicleWidth(unitType) ? 'Click a wide street or square to deploy.' : 'Click a street to deploy. Snipers can use rooftops.'}
        {editing && ' Click a deployment pin to remove it.'}</p>}
      {selection === 'barricade' && <p className="select-help">{barricadeStart ? 'Click the opposite side to place the barricade.' : 'Click one side of a street.'}</p>}
      {running && !canReinforce && <p className="deployment-note">{clearance ? 'Fixed squad · no reinforcements' : overrun ? 'Pickup overrun. Reinforcements closed.'
        : squadCount >= maxSquadSize ? 'Squad limit reached.' : 'Reinforcements closed for final boarding.'}</p>}
      {editing && <p className="deployment-note">{spawns.soldiers?.length ?? 0} of {squadCount} starting troops placed</p>}
    </div>
  );

  const setupControls = <>
    <h2>Scenario setup</h2>
    <CommandPicker label="Mission" value={mission} onChange={next => reset(next, missions[next].count, false)}
      options={(Object.keys(missions) as Mission[]).map(value => ({
        value, label: missions[value].name, icon: value === 'bridge' ? 'bridge' : 'route',
      }))} />
    <p className="scenario-brief">{operation.objective}</p>
    {!clearance && <><div className="spawn-layouts">
      {challenge?.type === 'sectors' ? <span className="mission-sectors">Civilian spawns · {operation.siteNames?.join(' and ')}</span> : spawnControls('civilians', civilianPoints.length)}
      {operation.rules && spawnControls('zombies', zombiePoints.length)}
    </div>
    <div className="waypoint-actions spawn-evac">
      <button data-close-command disabled={!editing} aria-pressed={selection === 'end'} onClick={() => {
        if (selection !== 'end') setMessage('Select an evacuation point on the map.');
        select(selection === 'end' ? null : 'end');
      }}><span className="point-dot evacuation-dot" />Set evacuation</button>
    </div>
    <CommandPicker label="Crowd size" value={groupSize} onChange={resizeCrowd}
      options={[operation.count, 1000, 10000, 20000].map(count => ({
        value: count, label: `${count.toLocaleString()} civilians`, icon: 'people', disabled: count < civilianPoints.length,
      }))} />
    {operation.rules && <div className="zombie-setting">
      <label className="crowd-size">Starting zombies
        <input key={zombieTotal} type="number" min={Math.max(1, zombiePoints.length)} max={maxStartingZombies} step={1}
          defaultValue={zombieTotal} disabled={!editing}
          onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}
          onBlur={event => {
            const value = event.currentTarget.valueAsNumber;
            const count = Number.isFinite(value) ? Math.min(maxStartingZombies, Math.max(1, zombiePoints.length, Math.round(value))) : zombieTotal;
            event.currentTarget.value = String(count);
            if (count !== zombieTotal) {
              prepare(waypoints, { ...spawns, zombieCount: count }, groupSize, `${count.toLocaleString()} starting zombies.`);
              event.currentTarget.value = String(convoyRef.current?.outbreak?.zombies.length ?? zombieTotal);
            }
          }} />
      </label>
      <div className="zombie-setting-mode spawn-actions">
        <span>{spawns.zombieCount === undefined ? 'Auto · 1 per 4 civilians, minimum 8' : 'Manual count'}</span>
        {spawns.zombieCount !== undefined && <button type="button" onClick={() =>
          prepare(waypoints, { ...spawns, zombieCount: undefined }, groupSize, 'Zombie count now scales with the crowd.')
        }>Use auto</button>}
      </div>
    </div>}
    {convoy.defense && <>
    <label className="lockdown-setting">
      <input type="checkbox" checked={!!spawns.gateLockdown} disabled={!editing}
        onChange={event => prepare(waypoints, { ...spawns, gateLockdown: event.currentTarget.checked }, groupSize,
          event.currentTarget.checked ? 'Gate lockdown enabled.' : 'Gate lockdown disabled.')} />
      Lock gates under heavy zombie pressure
    </label>
    <label className="crowd-size">Round length (seconds)
      <input key={roundSeconds} type="number" min={45} max={900} defaultValue={roundSeconds} disabled={!editing}
        onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}
        onBlur={event => {
          const seconds = Number.parseInt(event.currentTarget.value, 10);
          const value = Number.isFinite(seconds) ? Math.max(45, Math.min(900, seconds)) : roundSeconds;
          event.currentTarget.value = String(value);
          if (value !== roundSeconds) prepare(waypoints, { ...spawns, roundSeconds: value }, groupSize, 'Round length updated.');
        }} />
    </label>
    <label className="crowd-size">Extraction radius (m)
      <input key={zoneRadius} type="number" min={24} max={70} defaultValue={zoneRadius} disabled={!editing}
        onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}
        onBlur={event => {
          const meters = Number.parseInt(event.currentTarget.value, 10);
          const value = Number.isFinite(meters) ? Math.max(24, Math.min(70, meters)) : zoneRadius;
          event.currentTarget.value = String(value);
          if (value !== zoneRadius) prepare(waypoints, { ...spawns, zoneRadius: value }, groupSize, 'Extraction radius updated.');
        }} />
    </label>
    </>}
    </>}
  </>;

  const report = <>
    <h2>Round report</h2>
    <p className="scenario-brief">{operation.objective}</p>
    {clearance && <div className="squad-status">
      <strong>{clearance.secured} / {clearance.sectors.length} sectors secured</strong>
      {clearance.sectors.map(sector => <span key={sector.name}>{sector.name} · {sector.secured ? 'Relief in position'
        : sector.remaining ? `${sector.remaining} infected` : `${Math.max(0, Math.ceil(reliefSeconds - sector.held))}s hold remaining`}</span>)}
      <span>{eliminated} neutralized · {lost} soldiers lost</span>
    </div>}
    {convoy.defense && !clearance && <div className="squad-status">
      <span>{convoy.defense.fortifications?.gates.length ?? 0} gates · {breached} breached</span>
      <strong>{overrun && defensePhase !== 'departed' ? 'Pickup overrun' : defenseStatus}</strong>
      {!!lockedGates && airlift && <span>{lockedGates} {lockedGates === 1 ? 'gate' : 'gates'} locked</span>}
      {radioCue && <span className="radio-cue" role="status"><Icon name="alert" size={14} /> {radioCue}</span>}
      {status !== 'ready' && <span>{waiting.toLocaleString()} civilians waiting · {civilianAboard.toLocaleString()} boarded · {shelterLosses.toLocaleString()} lost at pickup</span>}
      {status === 'ready' ? <span>Squad falls back in the last {convoy.defense.fallbackWindow} seconds.</span>
        : <span>{eliminated} neutralized · {aboard} aboard · {lost} lost</span>}
    </div>}
    {friendlyFireLosses > 0 && <p className="radio-cue">{friendlyFireLosses.toLocaleString()} civilians killed by friendly fire</p>}
    {challenge && <div className="squad-status mission-objective">
      <strong>{objectiveReached ? 'Objective met' : status === 'finished' ? 'Objective missed' : 'Mission objective'}</strong>
      <span>{objectiveDetail}</span>
    </div>}
    {convoy.defense && !clearance && status !== 'ready' && <div className="support-stats">{assisted} escorted · {treated} treated</div>}
    {comparison && !clearance && <div className="squad-status">
      <strong>Previous run</strong>
      <span>{comparison.evacuated} / {comparison.civilians} civilians out · {comparison.aboard} / {comparison.troops} troops out</span>
      <span>{comparison.creditsSpent.toLocaleString()} credits spent</span>
      {lastResult && <span>This run: {lastResult.evacuated} / {lastResult.civilians} civilians out · {lastResult.aboard} / {lastResult.troops} troops out · {lastResult.creditsSpent.toLocaleString()} credits spent</span>}
    </div>}
    {lastResult && <button className="replay-button" onClick={() => reset(mission, groupSize, true, true)}>Replay same outbreak</button>}
  </>;

  return (
    <main className="game-screen">
      <MapView
        data={data}
        overview={overview}
        closed={closed}
        selection={selection}
        civilianSpawns={civilianPoints.map((position, index) => ({ position, count: civilianAllocation[index], removable: Array.isArray(spawns.civilians) }))}
        zombieSpawns={zombiePoints.map((position, index) => ({ position, count: zombieAllocation[index], removable: !clearance && Array.isArray(spawns.zombies) }))}
        end={convoy.defense?.center ?? data.nodes[waypoints.end]}
        deployments={convoy.defense && (status === 'ready' ? spawns.soldiers ?? [] : [])}
        defensePhase={defensePhase}
        canCommand={defensePhase === 'defend' && status === 'moving' && !selection}
        evacuatedPassengers={evacuated + aboard}
        aircraft={convoy.aircraft}
        elapsed={convoy.elapsed}
        defense={convoy.defense}
        clearance={clearance}
        supportRuns={convoy.supportRuns}
        supportStart={supportStart}
        supportType={supportType}
        groundFires={convoy.defense?.groundFires}
        night={!!operation.night}
        rescueMarkers={convoy.rescueMarkers}
        outbreakActive={!!convoy.outbreak && (status === 'moving' || status === 'holding')}
        gateQueues={convoy.gateQueueCounts}
        zoneRadius={zoneRadius}
        gates={convoy.defense?.fortifications?.gates}
        barricadeStart={barricadeStart}
        barricadeCredits={credits}
        inspectGaps={inspectGaps}
        onCancelPlacement={() => select(null)}
        placementMessage={selection ? message : undefined}
        coverage={coverage}
        onToggleGate={index => {
          const gate = convoy.defense?.fortifications?.gates[index];
          if (!gate || gate.locked || gate.integrity <= 0 || convoy.defense?.phase === 'departed') return;
          gate.open = !gate.open;
          convoy.barricadeChanged();
          refreshGates(value => value + 1);
          setMessage(`Gate ${index + 1} ${gate.open ? 'opened' : 'closed'}.`);
        }}
        onCrossing={toggleCrossing}
        onPlace={place}
        onRemoveSpawn={removeSpawn}
        frame={frame}
        hud={(
          <div className="game-hud">
            <div className="hud-mission"><h1>{operation.name}</h1><span>{status === 'ready' ? 'Ready to dispatch' : clearance ? status === 'finished' ? (clearance.secured === clearance.sectors.length ? 'District secured' : 'Operation ended') : 'Clear the district' : groupStatus}</span></div>
            <div className="hud-readouts">
              {operation.rules && <strong className="hud-timer">{timer}</strong>}
              <span>{clearance ? `${clearance.secured} / ${clearance.sectors.length} sectors secured` : `${evacuated.toLocaleString()} / ${groupSize.toLocaleString()} out`}</span>
              {operation.rules && <span className="hud-infected">{(clearance ? convoy.outbreak?.zombies.length ?? 0 : infected).toLocaleString()} infected</span>}
            </div>
          </div>
        )}
        commandBar={orders => (
          <div className="command-dock">
            <p className="command-status" aria-live="polite">{radioCue || message}</p>
            <nav className="command-bar" aria-label="Game commands">
              {missionActions}
              <div className="command-tools">
                <CommandMenu name="Bridges" icon="bridge">
                  <div className="sheet-heading"><h2>Bridges</h2><span>{data.crossings.length - closed.size} / {data.crossings.length} open</span></div>
          <div className="bridge-list">
            {data.crossings.map(crossing => (
              <button className="bridge-button" key={crossing.id} aria-pressed={closed.has(crossing.id)} onClick={() => toggleCrossing(crossing.id)}>
                <span><strong>{crossingNames[crossing.id]}</strong><small>{crossing.name}</small></span>
                <span className={`bridge-state ${closed.has(crossing.id) ? 'blocked' : ''}`}><i />{closed.has(crossing.id) ? 'Closed' : 'Open'}</span>
              </button>
            ))}
          </div>
                </CommandMenu>
                {convoy.defense && (running || status === 'ready') && <CommandMenu name="Deploy" icon="guard">
                  <div className="sheet-heading"><h2>{running && !clearance ? 'Reinforcements' : 'Deployment'}</h2><output aria-label="Available credits">{credits.toLocaleString()} credits</output></div>
                  {deploymentControls}
          {!running && !clearance && <div className="spawn-row hiring-row">
            <span>Starting squad<small>{squadCount} hired · {infantryCost} credits each</small></span>
            <div className="spawn-actions">
              <button disabled={credits < infantryCost || squadCount >= maxSquadSize} onClick={() =>
                prepare(waypoints, { ...spawns, hired: squadCount + 1 }, groupSize, 'SWAT infantry hired.')}>Hire one</button>
              <button disabled={credits < infantryCost || squadCount >= maxSquadSize} onClick={() =>
                prepare(waypoints, { ...spawns, hired: Math.min(maxSquadSize, squadCount + Math.floor(credits / infantryCost)) }, groupSize, 'Hired the largest squad the budget allows.')}>Hire max</button>
              <button disabled={squadCount <= (spawns.soldiers?.length ?? 0) || squadCount <= 1} onClick={() =>
                prepare(waypoints, { ...spawns, hired: squadCount - 1 }, groupSize, 'One unassigned soldier released.')}>Release one</button>
            </div>
          </div>}
                </CommandMenu>}
                {running && convoy.defense && <CommandMenu name="Air support" icon="guard">
                  <div className="sheet-heading"><h2>Air support</h2><span>{credits.toLocaleString()} credits</span></div>
                  <div className="unit-choices">{(Object.keys(supportTypes) as SupportType[]).map(type => <button key={type} type="button"
                    className="unit-choice support-choice" data-close-command disabled={credits < supportTypes[type].cost}
                    onClick={() => { setSupportType(type); setMessage(type === 'gunRun' ? 'Choose where the cannon run should start.' : type === 'strike' ? 'Choose the bomb impact point.' : 'Mark the patrol area.'); select('support'); }}>
                    <span className="unit-choice-copy"><strong>{supportTypes[type].label}</strong><small>{type === 'helicopter' ? '4s arrival · 12 bursts' : `${supportTypes[type].delay}s to impact`}</small></span>
                    <span className="unit-choice-price">{supportTypes[type].cost} cr</span>
                  </button>)}</div>
                </CommandMenu>}
                {orders}
                {!running && <CommandMenu name="Setup" icon="route">{setupControls}</CommandMenu>}
                <CommandMenu name="Report" icon="people">{report}</CommandMenu>
              </div>
              {speedControls}
            </nav>
          </div>
        )}
      />
    </main>
  );
}

void loadVehicleArt().then(() => createRoot(document.getElementById('root')!).render(<App />));
