import type { Point } from './routing.ts';

export type GroundFire = { point: Point; start: number; until: number; radius: number };

export function isGrass([x, y]: Point, parks: readonly Point[][]) {
  return parks.some(ring => {
    let inside = false;
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const [ax, ay] = ring[j], [bx, by] = ring[i];
      if ((ay > y) !== (by > y) && x < ax + (y - ay) * (bx - ax) / (by - ay)) inside = !inside;
    }
    return inside;
  });
}
