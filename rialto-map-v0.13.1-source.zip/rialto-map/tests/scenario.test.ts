import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import { limitCamera, type Overview } from '../src/cartography.ts';
import { EvacuationGroup, type SpawnPlan } from '../src/convoy.ts';
import { CrowdField } from '../src/crowd-field.ts';
import { encounterFrame } from '../src/civilians.ts';
import { Outbreak, riseDuration } from '../src/outbreak.ts';
import { clearSight, dangerDistance, saferPath } from '../src/pursuit.ts';
import { aimRunner, moveRunner, type TurnCurve } from '../src/runner-motion.ts';
import { Defense, hiringBudget, shotAccuracy } from '../src/defense.ts';
import { barricadeGaps } from '../src/fortifications.ts';
import { projectLocation, StreetGraph, type CrossingId, type Point, type Venice } from '../src/routing.ts';

const data: Venice = JSON.parse(readFileSync(new URL('../data/venice.json', import.meta.url), 'utf8'));
const overview: Overview = JSON.parse(readFileSync(new URL('../data/venice-overview.json', import.meta.url), 'utf8'));
const scenario: { pickup: Point; evacuation: Point; civilians: number; metersPerSecond: number } =
  JSON.parse(readFileSync(new URL('../data/rialto-scenario.json', import.meta.url), 'utf8'));
const graph = new StreetGraph(data.nodes, data.edges);
const pickup = graph.nearest(projectLocation(scenario.pickup, data.projection))!;
const evacuation = graph.nearest(projectLocation(scenario.evacuation, data.projection))!;
const terrain = new CrowdField(data, overview.water);
const allClosed = new Set<CrossingId>(['rialto', 'scalzi', 'accademia']);

function makeGroup(count = scenario.civilians, seed = 2026) {
  return new EvacuationGroup(terrain, graph, pickup, evacuation, new Set(), count, scenario.metersPerSecond, seed);
}

function simulate(group: EvacuationGroup, seconds: number) {
  for (let tick = 0; tick < seconds * 12; tick++) group.tick(1 / 12);
}

test('Rialto, Accademia and Scalzi offer progressively longer routes', () => {
  const open = graph.route(pickup, evacuation, new Set());
  const detour = graph.route(pickup, evacuation, new Set(['rialto']));
  const longDetour = graph.route(pickup, evacuation, new Set(['rialto', 'accademia']));
  assert.deepEqual(open?.crossings, ['rialto']);
  assert.deepEqual(detour?.crossings, ['accademia']);
  assert.deepEqual(longDetour?.crossings, ['scalzi']);
  assert.ok(open!.meters < detour!.meters && detour!.meters < longDetour!.meters);
  assert.equal(graph.route(pickup, evacuation, allClosed), null);
});

test('the physical crowd can use all three crossings and loses access when all close', () => {
  const goal = terrain.nearest(graph.nodes[evacuation]);
  const original = terrain.openFlow(goal);
  const start = terrain.nearest(graph.nodes[pickup], 0, original, 32);
  const buffer = new Uint16Array(terrain.cells.length);
  const shortest = original[start];
  const detour = terrain.flow(goal, terrain.mask(new Set(['rialto'])), buffer)[start];
  const longer = terrain.flow(goal, terrain.mask(new Set(['rialto', 'accademia'])), buffer)[start];
  assert.ok(shortest > 0 && shortest < detour && detour < longer);
  assert.equal(terrain.flow(goal, terrain.mask(allClosed), buffer)[start], 0);
});

test('a footprint thinner than a cell blocks movement across its wall', () => {
  const wall: Point[] = [[3.58, 1], [3.62, 1], [3.62, 19], [3.58, 19], [3.58, 1]];
  const testTerrain = new CrowdField({
    ...data,
    size: [20, 20],
    nodes: [],
    edges: [],
    terrain: { buildings: [wall], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  const west = testTerrain.cell(3.3, 10.5);
  const east = testTerrain.cell(3.9, 10.5);
  assert.ok(testTerrain.open(west) && testTerrain.open(east));
  assert.equal(testTerrain.canStep(west, 4, 0), false);
  assert.equal(testTerrain.canStep(east, 3, 0), false);
  assert.ok(testTerrain.flow(east, 0)[west] > 5, 'agents can go around the ends');
});

test('civilians spread across open ground and arrive individually', () => {
  const group = makeGroup();
  assert.equal(new Set(group.people.map(person => person.cell)).size, 12);
  group.dispatch();
  simulate(group, 5);
  assert.ok(group.people.every(person => person.status === 'moving'));
  assert.ok(new Set(group.people.map(person => person.travel.toFixed(1))).size >= 5);
  assert.ok(group.people.every(person => terrain.open(terrain.cell(person.x, person.y))));
  let partial = false;
  for (let tick = 0; tick < 12 * 650 && group.evacuated < 12; tick++) {
    group.tick(1 / 12);
    partial ||= group.evacuated > 0 && group.evacuated < 12;
  }
  assert.ok(partial);
  assert.equal(group.evacuated, 12);
  assert.equal(group.status, 'arrived');
});

test('blocking crossings stops the crowd, and reopening one lets it continue', () => {
  const group = makeGroup();
  group.dispatch();
  group.tick(0.1);
  group.replan(allClosed);
  simulate(group, 165);
  assert.equal(group.evacuated, 0);
  assert.equal(group.stranded, 12);
  assert.equal(group.status, 'holding');
  assert.ok(group.people.every(person => terrain.open(terrain.cell(person.x, person.y), terrain.mask(allClosed))));
  group.replan(new Set(['scalzi', 'accademia']));
  simulate(group, 700);
  assert.equal(group.evacuated, 12);
});

test('a 20,000-person crowd starts in separate cells and advances independently', () => {
  const group = makeGroup(20000);
  const adults = group.people.filter(person => person.profile < 2).length;
  assert.ok(Math.abs(adults / group.people.length - 2 / 3) < 0.001);
  assert.equal(new Set(group.people.map(person => person.cell)).size, 20000);
  group.dispatch();
  simulate(group, 3);
  assert.equal(group.people.filter(person => person.status === 'moving').length, 20000);
  assert.ok(group.people.every(person => terrain.open(terrain.cell(person.x, person.y))));
});

test('the same evacuation includes a mix of ages and distinctly different sustained speeds', () => {
  const group = makeGroup();
  const composition = [0, 0, 0, 0, 0, 0];
  for (const person of group.people) composition[person.profile]++;
  assert.deepEqual(composition, [4, 4, 1, 1, 1, 1]);
  const paces = group.people.map(person => person.pace);
  const speeds = paces.map(pace => pace * scenario.metersPerSecond);
  assert.ok(Math.min(...speeds) < 2.6);
  assert.ok(Math.max(...speeds) > 4.25);
  assert.notDeepEqual(makeGroup(12, 2027).people.map(person => person.pace), paces);
  group.dispatch();
  simulate(group, 15);
  assert.deepEqual(group.people.map(person => person.pace), paces);
});

test('mapped Rialto steps reduce speed and stay walkable', () => {
  const crossing = data.crossings.find(item => item.id === 'rialto')!;
  const mask = terrain.mask(new Set(['rialto']));
  let stairCells = 0;
  let bridgeCells = 0;
  terrain.visitArea(...crossing.position, 25, cell => {
    if (!terrain.open(cell) || terrain.open(cell, mask)) return;
    if (terrain.paceFactor(cell) === 0.76) stairCells++;
    if (terrain.paceFactor(cell) === 0.91) bridgeCells++;
  });
  assert.ok(stairCells > 0 && bridgeCells > 0);
});

test('city overview covers the playable district and the widescreen viewport stays on the chart', () => {
  const [left, top, right, bottom] = overview.bounds;
  assert.ok(left < 0 && top < 0 && right > data.size[0] && bottom > data.size[1]);
  assert.ok(overview.buildings.length > 1000 && overview.water.length > 0);
  const camera = limitCamera({ x: -5000, y: 9000, zoom: 0.01, width: 2560, height: 1080 }, overview.bounds);
  assert.ok(camera.x - camera.width / (2 * camera.zoom) >= left - 0.01);
  assert.ok(camera.x + camera.width / (2 * camera.zoom) <= right + 0.01);
  assert.ok(camera.y - camera.height / (2 * camera.zoom) >= top - 0.01);
  assert.ok(camera.y + camera.height / (2 * camera.zoom) <= bottom + 0.01);
});

const outbreakScenario: {
  pickup: Point; evacuation: Point; civilians: number; duration: number; downDuration: number;
  origins: { location: Point; pace: number }[];
} = JSON.parse(readFileSync(new URL('../data/rialto-outbreak.json', import.meta.url), 'utf8'));

function makeOutbreak(spawns?: SpawnPlan, count = outbreakScenario.civilians, seed = 2026) {
  const point = (location: Point) => projectLocation(location, data.projection);
  const start = graph.nearest(point(outbreakScenario.pickup))!;
  const end = graph.nearest(point(outbreakScenario.evacuation))!;
  return new EvacuationGroup(terrain, graph, start, end, new Set(), count, scenario.metersPerSecond, seed, {
    ...outbreakScenario,
    origins: outbreakScenario.origins.map(origin => ({ position: point(origin.location), pace: origin.pace })),
  }, spawns);
}

test('placed spawn areas split both populations evenly and preserve the totals', () => {
  const civilians: Point[] = [[1110.9, 909.2], [1235.6, 1010.8]];
  const zombies: Point[] = [[1086, 870], [1204, 989], [1356.6, 1047.5]];
  const group = makeOutbreak({ civilians, zombies, zombieCount: 7 }, 25);
  function countNear(points: Point[], people: { x: number; y: number }[]) {
    return points.map(([x, y]) => people.filter(person => Math.hypot(person.x - x, person.y - y) < 50).length);
  }
  assert.deepEqual(countNear(civilians, group.people), [13, 12]);
  assert.deepEqual(countNear(zombies, group.outbreak!.zombies), [3, 2, 2]);
  assert.equal(new Set(group.people.map(person => person.cell)).size, 25);
  assert.equal(new Set(group.outbreak!.zombies.map(person => person.cell)).size, 7);
});

test('random layouts scatter individuals on reachable ground and change with the run seed', () => {
  const spawns = { civilians: 'random', zombies: 'random', zombieCount: 100 } as const;
  const group = makeOutbreak(spawns, 150);
  const alternate = makeOutbreak(spawns, 150, 2027);
  const goal = terrain.nearest(projectLocation(outbreakScenario.evacuation, data.projection));
  const flow = terrain.openFlow(goal);
  for (const population of [group.people, group.outbreak!.zombies]) {
    assert.equal(new Set(population.map(person => person.cell)).size, population.length);
    assert.ok(population.every(person => terrain.open(person.cell) && flow[person.cell] > 1));
    const xs = population.map(person => person.x);
    assert.ok(Math.max(...xs) - Math.min(...xs) > 800);
  }
  assert.equal(group.people.length, 150);
  assert.equal(group.outbreak!.zombies.length, 100);
  assert.notDeepEqual(group.people.map(person => person.cell), alternate.people.map(person => person.cell));
  assert.ok(group.canDispatch && group.routes.length === 0);
  group.dispatch();
  assert.equal(group.status, 'moving');
});

test('zombies pursue on dispatch and bite, drop, and turn civilians in stages', () => {
  const group = makeOutbreak();
  group.dispatch();
  const outbreak = group.outbreak!;
  const origins = outbreak.zombies.map(zombie => [zombie.x, zombie.y]);
  assert.ok(outbreak.zombies.every(zombie => zombie.pace > scenario.metersPerSecond));
  group.tick(1 / 30);
  assert.notDeepEqual(outbreak.zombies.map(zombie => [zombie.x, zombie.y]), origins);
  while (group.elapsed < 20 && !outbreak.encounters.size) group.tick(1 / 30);
  const [scene] = outbreak.encounters;
  assert.ok(scene && scene.victim.status === 'caught' && scene.attacker.attack === scene);
  assert.equal(outbreak.infected, 0);
  assert.equal(outbreak.zombies.length, origins.length);
  assert.notEqual(encounterFrame(scene, scene.start, true), encounterFrame(scene, scene.biteEnd - 0.2, true));
  while (group.elapsed < scene.downAt + 0.1) group.tick(1 / 30);
  assert.equal(scene.victim.status, 'infected');
  assert.ok(outbreak.encounters.has(scene));
  assert.equal(encounterFrame(scene, scene.downAt + 0.1), encounterFrame(scene, scene.riseAt - 0.1));
  assert.ok(scene.riseAt - scene.downAt >= outbreakScenario.downDuration - 0.0001);
  assert.notEqual(encounterFrame(scene, scene.riseAt + 0.1), encounterFrame(scene, scene.riseAt + 0.7));
  const variants = new Set([scene.variant]);
  while (group.elapsed < scene.riseAt + riseDuration + 0.1) group.tick(1 / 30);
  assert.ok(!outbreak.encounters.has(scene));
  assert.ok(outbreak.zombies.length > origins.length);
  assert.ok(outbreak.zombies.slice(origins.length).every(zombie => zombie.pace > scenario.metersPerSecond));
  while (group.elapsed < outbreakScenario.duration + 5 && group.status !== 'finished') {
    group.tick(1 / 12);
    for (const attack of outbreak.encounters) variants.add(attack.variant);
  }
  assert.deepEqual([...variants].sort(), [0, 1, 2]);
  assert.equal(group.status, 'finished');
  assert.ok(group.evacuated > 0 && outbreak.infected > 0);
  assert.equal(group.evacuated + outbreak.infected, group.people.length);
  const meanPace = (status: 'arrived' | 'infected') => {
    const people = group.people.filter(person => person.status === status);
    return people.reduce((total, person) => total + person.pace, 0) / people.length;
  };
  assert.ok(meanPace('arrived') > meanPace('infected'));
});

test('closing Rialto before or after civilians cross changes the outbreak outcome', () => {
  const early = makeOutbreak();
  early.dispatch();
  early.replan(new Set(['rialto']));
  simulate(early, outbreakScenario.duration + 2);
  assert.equal(early.status, 'finished');
  assert.equal(early.evacuated, 0);
  assert.ok(early.outbreak!.infected < early.people.length, 'some civilians are left behind');

  const later = makeOutbreak();
  later.dispatch();
  simulate(later, 85);
  later.replan(new Set(['rialto']));
  simulate(later, outbreakScenario.duration);
  assert.equal(later.status, 'finished');
  assert.ok(later.evacuated >= 13);
});

test('pursuit and bites cannot cross a building footprint', () => {
  const wall: Point[] = [[3.58, 0], [3.62, 0], [3.62, 20], [3.58, 20], [3.58, 0]];
  const area = new CrowdField({
    ...data,
    size: [20, 20],
    nodes: [],
    edges: [],
    terrain: { buildings: [wall], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  const west = area.cell(3.3, 10.5);
  const east = area.cell(3.9, 10.5);
  const field = new Uint16Array(area.cells.length);
  area.localFlow([west], 0, 15, field);
  assert.equal(field[west], 1);
  assert.equal(field[east], 0);
  assert.equal(area.touches(west, east, 0), false);
  assert.equal(clearSight(area, west, east, 0), false);
  assert.equal(clearSight(area, west, area.cell(3.3, 12), 0), true);
});

test('a survivor can go around an infected blocking the direct route and rejoin beyond it', () => {
  const area = new CrowdField({
    ...data,
    size: [46, 30],
    nodes: [],
    edges: [],
    terrain: { buildings: [], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  const start = area.cell(14.2, 15.3);
  const infected = area.cell(19.2, 15.3);
  const flow = area.flow(area.cell(41.3, 15.3), 0);
  const danger = new Uint16Array(area.cells.length);
  area.localFlow([infected], 0, 55, danger);
  const path = saferPath(area, start, 0, flow, danger, 1, 0);
  const end = path.at(-1)!;
  assert.ok(area.x(end) > area.x(infected));
  assert.ok(flow[end] < flow[start]);
  assert.ok(path.some(cell => Math.abs(area.y(cell) - area.y(start)) > 3));
  assert.ok(path.every((cell, index) => area.touches(index ? path[index - 1] : start, cell, 0)
    && dangerDistance(danger, cell) > 4));
});

test('infected flank in pairs, survivors reroute, and a gate change clears their plans', () => {
  const group = makeOutbreak();
  const outbreak = group.outbreak!;
  let paired = false;
  let intercepted = false;
  let detoured = false;
  group.dispatch();
  while (group.elapsed < 85) {
    group.tick(1 / 12);
    for (const zombie of outbreak.zombies) {
      const cutoff = zombie.cutoff;
      if (!cutoff) continue;
      paired ||= outbreak.zombies.some(other => other !== zombie && other.focus?.prey === cutoff.prey);
      intercepted ||= zombie.cell === cutoff.plan.cells.at(-1) && zombie.target < 0;
    }
    detoured ||= group.people.some(person => person.escape && person.escape.next >= 3);
    if (paired && intercepted && detoured && outbreak.zombies.some(zombie => zombie.cutoff)) break;
  }
  assert.ok(paired && intercepted && detoured);
  group.replan(new Set(['rialto']));
  assert.ok(outbreak.zombies.every(zombie => !zombie.cutoff && !zombie.focus));
  assert.ok(group.people.filter(person => person.status === 'moving').every(person => !person.escape));
});

test('a crowded passage slows runners and still drains to extraction', () => {
  const wall = (top: number, bottom: number): Point[] => [[16, top], [19, top], [19, bottom], [16, bottom]];
  const area = new CrowdField({
    ...data, size: [40, 28], crossings: [],
    terrain: { buildings: [wall(0, 13), wall(15, 28)], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  const streets = new StreetGraph([[9, 14], [35, 14]], [[0, 1]]);
  const group = new EvacuationGroup(area, streets, 0, 1, new Set(), 140, 3.7, 2026, undefined, { civilians: [[9, 14]] });
  assert.equal(group.people.length, 140);
  group.dispatch();
  let queued = false;
  for (let step = 0; step < 90 * 24 && group.status !== 'arrived'; step++) {
    group.tick(1 / 24);
    queued ||= group.people.some(person => person.status === 'moving' && person.x > 15 && person.x < 20
      && person.stepsTaken > 5 && person.speed < 3.7 * person.pace * 0.7);
  }
  assert.ok(queued);
  assert.equal(group.evacuated, 140);
});

test('panic reaches nearby survivors and stays on their side of a wall', () => {
  const wall: Point[] = [[0, 11.9], [36, 11.9], [36, 12.1], [0, 12.1]];
  const area = new CrowdField({
    ...data, size: [36, 24], crossings: [],
    terrain: { buildings: [wall], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  const goal = area.cell(33, 10);
  const flow = area.openFlow(goal);
  const outbreak = new Outbreak(area, { duration: 20, downDuration: 3, origins: [{ position: [3.3, 10.5], pace: 4 }] }, flow);
  const template = makeGroup(1).people[0];
  const people = ([[9.9, 10.5], [13.5, 10.5], [13.5, 12.9]] as const).map(([x, y]) => ({
    ...template, x, y, cell: area.cell(x, y), status: 'moving' as const,
  }));
  outbreak.sense(people, 1, 0, flow);
  assert.ok(outbreak.separation(people[1].cell) > 13);
  assert.ok(people[0].panicUntil && people[1].panicUntil);
  assert.equal(people[2].panicUntil, undefined);
});

test('runners ease through an open turn and keep a straight step beside a wall', () => {
  const wall: Point[] = [[5.99, 1], [6.01, 1], [6.01, 18], [5.99, 18]];
  for (const buildings of [[], [wall]]) {
    const area = new CrowdField({
      ...data, size: [20, 20], crossings: [], edges: [],
      terrain: { buildings, bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
    }, []);
    const cell = area.cell(5.7, 8.1);
    const target = cell - area.columns;
    const runner = {
      cell, target: -1, x: area.x(cell), y: area.y(cell), targetX: 0, targetY: 0,
      vx: 1, vy: 0, heading: 0, speed: 4, travel: 0, curve: undefined as TurnCurve | undefined,
    };
    assert.ok(area.touches(cell, target, 0));
    aimRunner(runner, area, target, 0);
    moveRunner(runner, 0.06, 11);
    if (buildings.length) assert.equal(runner.x, area.x(cell));
    else assert.ok(runner.x > area.x(cell) && runner.heading > -0.1, 'turn starts near the incoming heading');
    assert.ok(runner.y < area.y(cell));
    while (runner.y !== runner.targetY || runner.x !== runner.targetX) {
      assert.ok(moveRunner(runner, 0.06, 11) > 0);
      assert.ok(area.open(area.cell(runner.x, runner.y)));
    }
    assert.equal(runner.x, area.x(target));
    assert.equal(runner.y, area.y(target));
  }
});

test('deployed infantry can engage on approach, patrol, and board before departure', () => {
  const area = new CrowdField({
    ...data,
    size: [85, 54],
    nodes: [[9.3, 27.3], [66.3, 27.3]],
    edges: [[0, 1]],
    crossings: [],
    terrain: { buildings: [], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  const streets = new StreetGraph([[9.3, 27.3], [66.3, 27.3]], [[0, 1]]);
  const group = new EvacuationGroup(area, streets, 0, 1, new Set(), 8, 3.7, 2026, {
    duration: 38, downDuration: 3, origins: [{ position: [19.5, 27.3], pace: 4 }],
  }, { zoneRadius: 24, soldiers: [{ position: [9.3, 27.3], type: 'infantry' }] });
  group.dispatch();
  const defense = group.defense!;
  const deployed = defense.soldiers[0];
  assert.equal(defense.soldiers.length, 4);
  assert.equal(deployed.state, 'approach');
  simulate(group, 2);
  assert.equal(defense.eliminated, 1);
  assert.equal(deployed.state, 'approach');
  simulate(group, 13);
  assert.equal(deployed.state, 'patrol');
  assert.ok(defense.active.every(soldier => defense.inside(soldier.x, soldier.y)));
  assert.ok(group.elapsed < 38 && group.status === 'moving');
  simulate(group, 17);
  assert.equal(defense.phase, 'fallback');
  assert.ok(defense.aboard > 0);
  simulate(group, 8);
  assert.equal(defense.phase, 'departed');
  assert.equal(defense.aboard, 4);
  assert.equal(group.status, 'finished');
});

test('soldier fire respects buildings and the pickup leaves stranded troops behind', () => {
  const wall: Point[] = [[19.8, 0], [20.4, 0], [20.4, 36], [19.8, 36]];
  const area = new CrowdField({
    ...data,
    size: [50, 36],
    nodes: [],
    edges: [],
    crossings: [],
    terrain: { buildings: [wall], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  const goal = area.cell(39.3, 18.3);
  const flow = area.openFlow(goal);
  const outbreak = new Outbreak(area, { duration: 30, downDuration: 3, origins: [{ position: [22.5, 18.3], pace: 4 }] }, flow);
  const defense = new Defense(area, goal, 30, [{ position: [17.7, 18.3], type: 'infantry' }]);
  defense.start(0, flow);
  const soldier = defense.soldiers[0];
  // Isolate the stranded soldier from the three default perimeter deployments.
  for (const teammate of defense.soldiers.slice(1)) teammate.state = 'aboard';
  defense.tick(1, 1 / 30, 0, outbreak);
  assert.equal(defense.shots.length, 0);
  assert.equal(soldier.ammo, 12);
  defense.depart();
  assert.equal(soldier.state, 'lost');
  assert.equal(defense.aboard, 3);
});

test('hiring capacity scales with both populations and long shots are less accurate', () => {
  assert.ok(hiringBudget(20000, 3) > hiringBudget(24, 3));
  assert.ok(hiringBudget(24, 1000) > hiringBudget(24, 3));
  assert.ok(shotAccuracy(5, 23) > shotAccuracy(15, 23));
  assert.ok(shotAccuracy(15, 23) > shotAccuracy(23, 23));
  const group = makeOutbreak();
  const target = group.outbreak!.zombies[0];
  assert.equal(group.outbreak!.hit(target, 1), false);
  assert.equal(group.outbreak!.hit(target, 1), true);
  assert.equal(group.outbreak!.hit(target, 1), false);
});

test('civilians wait for pickup and a sustained breach destroys the shelter', () => {
  const points: Point[] = [[15.3, 27.3], [44.1, 27.3]];
  const area = new CrowdField({
    ...data, size: [70, 55], nodes: points, edges: [[0, 1]], crossings: [],
    terrain: { buildings: [], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  const streets = new StreetGraph(points, [[0, 1]]);
  const make = () => new EvacuationGroup(area, streets, 0, 1, new Set(), 8, 3.7, 2026, {
    duration: 40, downDuration: 3, origins: [{ position: [5.1, 5.1], pace: 4 }],
  }, { soldiers: [], zoneRadius: 24 });
  const successful = make();
  successful.dispatch();
  successful.outbreak!.zombies.length = 0;
  simulate(successful, 24);
  assert.ok(successful.waiting > 0);
  assert.equal(successful.evacuated, 0);
  simulate(successful, 17);
  assert.equal(successful.evacuated, 8);

  const overrun = make();
  overrun.dispatch();
  const zombie = overrun.outbreak!.zombies.pop()!;
  simulate(overrun, 24);
  assert.ok(overrun.waiting > 0);
  for (const soldier of overrun.defense!.soldiers) soldier.state = 'lost';
  const pickup = overrun.defense!.center;
  zombie.x = pickup[0];
  zombie.y = pickup[1];
  zombie.cell = area.cell(...pickup);
  zombie.target = -1;
  zombie.pace = 0;
  overrun.outbreak!.zombies.push(zombie);
  simulate(overrun, 5);
  assert.equal(overrun.defense!.overrun, true);
  assert.equal(overrun.waiting, 0);
  assert.ok(overrun.shelterLosses > 0);
  simulate(overrun, 15);
  assert.equal(overrun.evacuated, 0);
});

test('a purchased barricade blocks its full span and permits movement around the ends', () => {
  const points: Point[] = [[12.3, 24.3], [40.5, 24.3]];
  const area = new CrowdField({
    ...data, size: [80, 50], nodes: points, edges: [[0, 1]], crossings: [],
    terrain: { buildings: [], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  const goal = area.cell(...points[1]);
  const flow = area.openFlow(goal);
  const empty = new Defense(area, goal, 45, []);
  empty.start(0, flow);
  assert.equal(empty.fortifications!.gates.length, 0);
  const defense = new Defense(area, goal, 45, [], 4, 19, 0, [[[30, 19], [30, 30]]]);
  defense.start(0, flow);
  const forts = defense.fortifications!;
  assert.equal(forts.gates.length, 1);
  assert.ok(defense.soldiers.some(soldier => soldier.cell === forts.gates[0].post));
  const west = area.cell(29.7, 24.3);
  const east = area.cell(30.3, 24.3);
  for (const y of [19.5, 24.3, 29.7]) {
    const left = area.cell(29.7, y);
    const right = area.cell(30.3, y);
    assert.equal(forts.allows(left, right), false);
    assert.equal(forts.allows(right, left), false);
  }
  assert.equal(forts.allows(west, east + area.columns, false), false);
  assert.equal(forts.allows(area.cell(29.7, 31.5), area.cell(30.3, 31.5)), true);
  forts.resolve(20);
  assert.equal(forts.gates[0].integrity, 0);
  assert.equal(forts.allows(west, east), true);
});

test('gate guards patrol locally and a reserve answers a gate alert', () => {
  const points: Point[] = [[9.3, 25.5], [39.9, 25.5]];
  const area = new CrowdField({
    ...data, size: [80, 56], nodes: points, edges: [[0, 1]], crossings: [],
    terrain: { buildings: [], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  const goal = area.cell(...points[1]);
  const flow = area.openFlow(goal);
  const outbreak = new Outbreak(area, { duration: 75, downDuration: 3, origins: [{ position: [7.5, 25.5], pace: 4 }] }, flow);
  const zombie = outbreak.zombies.pop()!;
  const defense = new Defense(area, goal, 75, [], 4, 19, 0, [[[25, 22], [25, 29]]]);
  defense.start(0, flow);
  const reserve = defense.soldiers.find(soldier => soldier.reserve)!;
  for (let tick = 1; tick <= 72; tick++) defense.tick(tick / 24, 1 / 24, 0, outbreak);
  assert.ok(reserve.travel > 0);
  const guard = defense.soldiers[0];
  assert.ok(guard.travel > 0);
  const gate = defense.fortifications!.gates[guard.patrol];
  zombie.x = gate.position[0];
  zombie.y = gate.position[1];
  zombie.health = 10;
  outbreak.zombies.push(zombie);
  for (let tick = 73; tick <= 108; tick++) defense.tick(tick / 24, 1 / 24, 0, outbreak);
  assert.ok(guard.responding);
  assert.ok(reserve.responding);
  outbreak.zombies.length = 0;
  for (let tick = 109; tick <= 288; tick++) defense.tick(tick / 24, 1 / 24, 0, outbreak);
  assert.equal(reserve.responding, undefined);
});

test('the barricade preview marks walkable space beside endpoints', () => {
  const area = new CrowdField({
    ...data, size: [30, 24], nodes: [], edges: [], crossings: [],
    terrain: { buildings: [], bridges: [], bridgeDecks: [], parks: [], plazas: [], streets: [], water: [], stairs: [] },
  }, []);
  assert.equal(barricadeGaps(area, [[15, 7], [15, 17]], 0, []).length, 2);
  assert.equal(barricadeGaps(area, [[15, 7], [15, 17]], 0, [[[15, 4], [15, 7]]]).length, 1);
  assert.equal(barricadeGaps(area, [[15, 0], [15, 24]], 0, []).length, 0);
});

test('guards on a real Rialto barricade keep moving during a quiet patrol', () => {
  const pickup = terrain.nearest(graph.nodes[evacuation]);
  const flow = terrain.openFlow(pickup);
  const x = terrain.x(pickup);
  const y = terrain.y(pickup);
  const defense = new Defense(terrain, pickup, 150, [], 4, 36, 2026, [[[x - 4, y], [x + 4, y]]]);
  defense.start(0, flow);
  const outbreak = makeOutbreak().outbreak!;
  outbreak.zombies.length = 0;
  assert.equal(defense.coverage[0].guards, 3);
  for (let tick = 1; tick <= 30 * 24; tick++) defense.tick(tick / 24, 1 / 24, 0, outbreak);
  assert.ok(defense.soldiers.every(soldier => soldier.travel > 15 && terrain.open(terrain.cell(soldier.x, soldier.y))));
});

test('the default defense budget leaves 1,600 credits after the starting squad', () => {
  assert.equal(hiringBudget(24, 3), 2000);
  assert.ok(hiringBudget(20000, 20000) > 16000);
});
