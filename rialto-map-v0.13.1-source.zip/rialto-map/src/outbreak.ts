import type { Fortifications } from './fortifications.ts';
import { cellSize, steps, type CrowdField } from './crowd-field.ts';
import type { Civilian } from './convoy.ts';
import type { Point } from './routing.ts';
import { scatterCells, spawnNear, splitPopulation, type SpawnLayout } from './spawn-planning.ts';
import { clearSight, cutoffPath, dangerDistance, forecast, saferPath, takeStep, type RoutePlan } from './pursuit.ts';
import { aimRunner, moveRunner, runnerTargetOpen } from './runner-motion.ts';

export interface OutbreakRules {
  duration: number;
  downDuration: number;
  origins: { position: Point; pace: number }[];
}

export interface Zombie extends Civilian {
  health?: number;
  nextBite: number;
  attack?: Encounter;
  cutoff?: { prey: Civilian; plan: RoutePlan };
  focus?: { prey: Civilian; cell: number; expires: number; seenAt: number; searchEnd?: number };
}

export const bites = [
  { bite: 0.88, fall: 0.42, collapse: 0.64 },
  { bite: 1.04, fall: 0.46, collapse: 0.62 },
  { bite: 1.16, fall: 0, collapse: 0.27 },
] as const;
export const riseDuration = 0.82;

export interface Encounter {
  victim: Civilian;
  attacker: Zombie;
  variant: number;
  heading: number;
  fallHeading: number;
  start: number;
  biteEnd: number;
  downAt: number;
  riseAt: number;
}

const scanInterval = 0.36;
const scentRadius = 55;
const panicRadius = 13;
const reactionRadius = 8;
const biteRadius = 0.88;
const defaultChasePace = 4.45;
const turnedMinimumPace = 4.05;
const turnedPaceSpread = 0.65;

export class Outbreak {
  readonly zombies: Zombie[] = [];
  readonly encounters = new Set<Encounter>();
  infected = 0;
  private readonly terrain: CrowdField;
  private readonly rules: OutbreakRules;
  private danger?: Uint16Array;
  private scent?: Uint16Array;
  private alarm?: Uint16Array;
  private readonly buckets = new Map<number, number>();
  private nextOccupant?: Int32Array;
  private nextScan = 0;
  private nextCutoff = 0;
  private escapeBudget = 0;
  private escapeChecks = 0;
  private activeCount = 0;

  constructor(terrain: CrowdField, rules: OutbreakRules, baseline: Uint16Array, layout?: SpawnLayout,
    total = rules.origins.length, mask = 0, seed = 0) {
    this.terrain = terrain;
    this.rules = rules;
    const points = Array.isArray(layout) ? layout : rules.origins.map(origin => origin.position);
    let cells: number[];
    if (layout === 'random') {
      cells = scatterCells(terrain, baseline, mask, total, seed ^ 0x6d2b79f5);
    } else if (!layout && total === rules.origins.length) {
      cells = points.map(point => terrain.nearest(point, 0, baseline, 26));
    } else {
      const allocation = splitPopulation(total, points.length);
      const nearby = new Uint16Array(terrain.cells.length);
      const used = new Set<number>();
      cells = points.flatMap((point, index) => {
        const size = allocation[index];
        if (size === 1) {
          const cell = terrain.nearest(point, mask, baseline, 20);
          if (cell >= 0 && !used.has(cell) && baseline[cell] > 1) {
            used.add(cell);
            return [cell];
          }
        }
        return spawnNear(terrain, baseline, mask, point, size, Math.min(150, 3 + Math.sqrt(size) * 0.6),
          seed + index, used, nearby);
      });
    }
    for (const [index, cell] of cells.entries()) {
      if (cell < 0) continue;
      const x = terrain.x(cell);
      const y = terrain.y(cell);
      this.zombies.push({
        x, y, cell, targetX: x, targetY: y, target: -1, heading: 0, travel: 0,
        status: 'holding', vx: 0, vy: 0, pace: rules.origins[index % rules.origins.length]?.pace ?? defaultChasePace, profile: index,
        speed: 0, release: 0, pauseUntil: 0, nextPause: 0, random: index, stepsTaken: 0,
        nextBite: 0,
      });
    }
  }

  get duration() { return this.rules.duration; }

  hit(zombie: Zombie, damage: number) {
    if (zombie.health === 0) return false;
    zombie.health = Math.max(0, (zombie.health ?? 2) - damage);
    if (zombie.health > 0) return false;
    const index = this.zombies.indexOf(zombie);
    if (index < 0) return false;
    this.zombies.splice(index, 1);
    if (this.zombies.length < 128) this.nextScan = 0;
    return true;
  }

  private alert(cell: number) {
    const distance = this.danger?.[cell] ?? 0;
    return distance > 0 && distance <= panicRadius;
  }

  separation(cell: number) {
    return this.danger ? dangerDistance(this.danger, cell) : 23;
  }

  escapeStep(person: Civilian, elapsed: number, mask: number, flow: Uint16Array) {
    if (!this.danger) return -1;
    const { cell } = person;
    const existing = person.escape;
    if (existing && existing.expires > elapsed) {
      const next = existing.cells[existing.next];
      if (next !== undefined && (this.separation(next) > 5 || this.separation(next) >= this.separation(cell))) {
        const target = takeStep(this.terrain, mask, cell, existing);
        if (target >= 0) return target;
      }
    }
    person.escape = undefined;
    if (!this.escapeChecks || !this.escapeBudget || elapsed < (person.checkEscapeAt ?? 0) || this.separation(cell) >= 23) return -1;
    person.checkEscapeAt = elapsed + 0.72 + ((person.random >>> 3) & 7) * 0.07;
    const ahead = forecast(this.terrain, cell, flow, mask, 15, person.vx, person.vy);
    if (this.separation(cell) > 8 && ahead.every(next => this.separation(next) > 12)) return -1;
    this.escapeBudget--;
    this.escapeChecks--;
    const cells = saferPath(this.terrain, cell, mask, flow, this.danger, person.vx, person.vy);
    if (!cells.length) return -1;
    const duration = Math.max(2.9, Math.min(8.5, cells.length * cellSize / Math.max(2, person.speed) + 1));
    person.escape = { cells, next: 0, expires: elapsed + duration };
    return takeStep(this.terrain, mask, cell, person.escape);
  }

  gatesChanged(mask: number) {
    this.nextScan = 0;
    this.nextCutoff = 0;
    for (const zombie of this.zombies) {
      zombie.cutoff = undefined;
      zombie.focus = undefined;
      const current = this.terrain.cell(zombie.x, zombie.y);
      if (zombie.target < 0 || !this.terrain.open(current, mask) || runnerTargetOpen(zombie, this.terrain, mask)) continue;
      aimRunner(zombie, this.terrain, zombie.cell, mask);
    }
  }

  sense(people: Civilian[], elapsed: number, mask: number, flow: Uint16Array, defenders: readonly Point[] = []) {
    this.escapeChecks = people.length >= 2048 ? 3 : 18;
    if (elapsed < this.nextScan) return;
    this.nextScan = elapsed + scanInterval;
    this.escapeBudget = 18;
    const danger = this.danger ??= new Uint16Array(this.terrain.cells.length);
    const scent = this.scent ??= new Uint16Array(this.terrain.cells.length);
    const alarm = this.alarm ??= new Uint16Array(this.terrain.cells.length);
    const sources = [];
    for (const zombie of this.zombies) {
      const cell = this.terrain.cell(zombie.x, zombie.y);
      sources.push(cell);
      const focus = zombie.focus;
      if (!focus) continue;
      if (focus.expires <= elapsed || focus.prey.status !== 'moving') {
        zombie.focus = undefined;
        continue;
      }
      const seen = this.terrain.cell(focus.prey.x, focus.prey.y);
      if ((focus.prey.x - zombie.x) ** 2 + (focus.prey.y - zombie.y) ** 2 <= 15 ** 2
        && clearSight(this.terrain, cell, seen, mask)) {
        focus.cell = seen;
        focus.seenAt = elapsed;
        focus.searchEnd = undefined;
      }
    }
    this.activeCount = sources.length;
    this.terrain.localFlow(sources, mask, scentRadius, danger);
    const prey = defenders.map(([x, y]) => this.terrain.cell(x, y));
    const panicked = [];
    const candidates: Civilian[] = [];
    for (const person of people) {
      if (person.status === 'arrived' || person.status === 'infected' || person.status === 'caught' || person.status === 'lost') continue;
      const cell = this.terrain.cell(person.x, person.y);
      if (danger[cell]) {
        prey.push(cell);
        if (person.status === 'moving' && person.speed > 1.4 && flow[cell] > 1) candidates.push(person);
      }
      if (this.alert(cell)) panicked.push(cell);
    }
    // Only people directly threatened by the infected spread alarm.
    if (panicked.length) {
      this.terrain.localFlow(panicked, mask, reactionRadius, alarm);
      for (const person of people) {
        if (person.status !== 'moving' && person.status !== 'holding') continue;
        if (!alarm[this.terrain.cell(person.x, person.y)]) continue;
        if ((person.panicUntil ?? 0) <= elapsed && elapsed - (person.glanceAt ?? -10) >= 3) person.glanceAt = elapsed;
        person.panicUntil = elapsed + 1.3;
      }
    }
    this.terrain.localFlow(prey, mask, scentRadius, scent);
    if (elapsed >= this.nextCutoff && candidates.length) {
      this.nextCutoff = elapsed + 0.72;
      this.assignCutoffs(candidates, elapsed, mask, flow);
    }
  }

  private assignCutoffs(people: Civilian[], elapsed: number, mask: number, flow: Uint16Array) {
    const total = this.zombies.length;
    const claims = new Map<Civilian, number>();
    for (const zombie of this.zombies) {
      if (zombie.cutoff && zombie.cutoff.plan.expires > elapsed && zombie.cutoff.prey.status === 'moving') {
        const prey = zombie.cutoff.prey;
        claims.set(prey, (claims.get(prey) ?? 0) + 1);
      }
    }
    let attempts = 0;
    const offset = Math.floor(elapsed / 0.72) % total;
    for (let i = 0; i < total && attempts < 8; i++) {
      const index = (i + offset) % total;
      const zombie = this.zombies[index];
      if (index % 3 === 0 || zombie.attack || zombie.cutoff || zombie.focus || !this.scent?.[zombie.cell]) continue;
      attempts++;
      const position = this.terrain.cell(zombie.x, zombie.y);
      let seen: Civilian | undefined;
      let closest = 15 ** 2;
      for (const person of people) {
        const distance = (person.x - zombie.x) ** 2 + (person.y - zombie.y) ** 2;
        if (distance >= closest || distance < 2.6 ** 2 || (claims.get(person) ?? 0) >= 1) continue;
        const cell = this.terrain.cell(person.x, person.y);
        if (cell < 0 || !clearSight(this.terrain, position, cell, mask)) continue;
        closest = distance;
        seen = person;
      }
      if (!seen) continue;
      const prey = seen;
      const sighting = this.terrain.cell(prey.x, prey.y);
      const support = this.zombies.find(other => other !== zombie && !other.cutoff && !other.attack && !other.focus
        && (prey.x - other.x) ** 2 + (prey.y - other.y) ** 2 <= 15 ** 2
        && clearSight(this.terrain, this.terrain.cell(other.x, other.y), sighting, mask));
      if (!support) continue;
      const anchor = zombie.target < 0 ? zombie.cell : zombie.target;
      const cells = cutoffPath(this.terrain, mask, flow, anchor, sighting, prey.vx, prey.vy,
        Math.max(2.3, prey.speed), zombie.pace, index % 2 ? 1 : -1);
      if (!cells.length) continue;
      claims.set(prey, 1);
      zombie.cutoff = { prey, plan: { cells, next: 0, expires: elapsed + 4.6 } };
      support.focus = { prey, cell: sighting, expires: elapsed + 4.6, seenAt: elapsed };
    }
  }

  tick(people: Civilian[], elapsed: number, seconds: number, mask: number, baseline: Uint16Array, safe: Uint16Array, onCatch: (person: Civilian) => void, forts?: Fortifications) {
    this.advanceEncounters(elapsed);
    if (elapsed >= this.duration) return;
    if (!this.activeCount) return;
    this.buckets.clear();
    const links = this.nextOccupant ??= new Int32Array(people.length);
    for (let index = people.length - 1; index >= 0; index--) {
      const person = people[index];
      if (person.status === 'arrived' || person.status === 'infected' || person.status === 'caught' || person.status === 'lost') continue;
      const cell = this.terrain.cell(person.x, person.y);
      if (!this.danger?.[cell] || (!forts && safe[cell] === 1)) continue;
      links[index] = this.buckets.get(cell) ?? -1;
      this.buckets.set(cell, index);
    }
    const population = this.zombies.length;
    for (let i = 0; i < population; i++) {
      const zombie = this.zombies[i];
      if (zombie.attack) continue;
      const moving = this.advance(zombie, elapsed, seconds, mask, baseline, safe, forts);
      zombie.status = moving ? 'moving' : 'holding';
      if (elapsed < zombie.nextBite) continue;
      const victim = this.findVictim(zombie, mask, people, links, forts);
      if (!victim) continue;
      onCatch(victim);
      this.startEncounter(zombie, victim, elapsed, mask);
    }
  }

  private startEncounter(attacker: Zombie, victim: Civilian, elapsed: number, mask: number) {
    const variant = ((victim.random ^ (victim.random >>> 11)) >>> 0) % bites.length;
    const timing = bites[variant];
    const heading = Math.atan2(victim.y - attacker.y, victim.x - attacker.x);
    const cell = this.terrain.cell(victim.x, victim.y);
    const fallHeading = [heading, heading + Math.PI / 2, heading - Math.PI / 2, heading + Math.PI].find(angle => {
      const next = this.terrain.cell(victim.x + Math.cos(angle) * 0.48, victim.y + Math.sin(angle) * 0.48);
      return this.terrain.touches(cell, next, mask);
    }) ?? heading;
    const biteEnd = elapsed + timing.bite;
    const downAt = biteEnd + timing.fall;
    const encounter = {
      attacker, victim, variant, heading, fallHeading, start: elapsed, biteEnd, downAt,
      riseAt: downAt + this.rules.downDuration + ((victim.random >>> 16) & 31) / 31 * 0.45,
    };
    attacker.target = -1;
    attacker.cell = this.terrain.cell(attacker.x, attacker.y);
    attacker.speed = 0;
    attacker.cutoff = undefined;
    attacker.focus = undefined;
    attacker.attack = encounter;
    this.encounters.add(encounter);
  }

  advanceEncounters(elapsed: number) {
    for (const scene of this.encounters) {
      const { attacker, victim } = scene;
      if (elapsed >= scene.biteEnd && victim.status === 'caught') {
        victim.status = 'infected';
        this.infected++;
        attacker.attack = undefined;
        attacker.nextBite = elapsed + 0.5;
      }
      if (elapsed < scene.riseAt + riseDuration) continue;
      const cell = this.terrain.cell(victim.x, victim.y);
      this.zombies.push({
        ...victim, cell, heading: scene.fallHeading, target: -1, status: 'holding', speed: 0,
        curve: undefined, vx: 0, vy: 0,
        pace: turnedMinimumPace + ((victim.random >>> 5) & 31) / 31 * turnedPaceSpread, nextBite: elapsed,
      });
      this.encounters.delete(scene);
      // Let a wave of reanimations share the next scheduled scan.
      if (this.zombies.length < 128) this.nextScan = 0;
    }
  }

  private findVictim(zombie: Zombie, mask: number, people: Civilian[], links: Int32Array, forts?: Fortifications) {
    const cell = this.terrain.cell(zombie.x, zombie.y);
    let victim: Civilian | undefined;
    let closest = biteRadius * biteRadius;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const next = cell + dy * this.terrain.columns + dx;
      const head = this.buckets.get(next);
      if (head === undefined || (!this.terrain.touches(cell, next, mask) || (forts && !forts.allows(cell, next, false)))) continue;
      for (let index = head; index >= 0; index = links[index]) {
        const person = people[index];
        if (person.status === 'infected' || person.status === 'caught' || person.status === 'arrived' || person.status === 'lost') continue;
        const distance = (person.x - zombie.x) ** 2 + (person.y - zombie.y) ** 2;
        if (distance >= closest) continue;
        closest = distance;
        victim = person;
      }
    }
    return victim;
  }

  private advance(zombie: Zombie, elapsed: number, seconds: number, mask: number, baseline: Uint16Array, safe: Uint16Array, forts?: Fortifications) {
    const scent = this.scent;
    if (zombie.cutoff && (zombie.cutoff.plan.expires <= elapsed || zombie.cutoff.prey.status !== 'moving')) zombie.cutoff = undefined;
    const pursuing = zombie.cutoff || zombie.focus || scent?.[zombie.cell];
    const limit = zombie.pace * (pursuing ? 1 : 0.68) * this.terrain.paceFactor(zombie.cell);
    zombie.speed = Math.max(zombie.speed - seconds * 5, Math.min(limit, zombie.speed + seconds * 3.4));
    let remaining = seconds * zombie.speed;
    let moving = false;
    while (remaining > 0.0001) {
      if (zombie.target < 0) {
        const { cell } = zombie;
        const localMask = this.terrain.open(cell, mask) ? mask : 0;
        const plan = zombie.cutoff?.plan;
        if (plan) {
          if (plan.next >= plan.cells.length) {
            zombie.speed = 0;
            return moving;
          }
          zombie.target = takeStep(this.terrain, localMask, cell, plan);
          if (zombie.target < 0) zombie.cutoff = undefined;
        }
        const focus = zombie.focus;
        if (zombie.target < 0 && focus && focus.expires > elapsed && clearSight(this.terrain, cell, focus.cell, localMask)) {
          const destination = focus.searchEnd ?? focus.cell;
          const x = this.terrain.x(destination);
          const y = this.terrain.y(destination);
          const gap = (next: number) => (this.terrain.x(next) - x) ** 2 + (this.terrain.y(next) - y) ** 2;
          let best = gap(cell);
          for (let direction = 0; direction < steps.length; direction++) {
            const [dx, dy] = steps[direction];
            const next = cell + dy * this.terrain.columns + dx;
            if ((!forts && safe[next] === 1) || !this.terrain.canStep(cell, direction, localMask)) continue;
            const distance = gap(next);
            if (distance >= best) continue;
            best = distance;
            zombie.target = next;
          }
          if (zombie.target < 0 && elapsed - focus.seenAt >= scanInterval && focus.searchEnd === undefined) {
            focus.searchEnd = cell;
            // Check a nearby opening after reaching the last sighting.
            const preferred = Math.round(zombie.heading / (Math.PI / 4));
            let alignment = -Infinity;
            for (let direction = 0; direction < steps.length; direction++) {
              const [dx, dy] = steps[direction];
              const next = cell + dy * this.terrain.columns + dx;
              if ((!forts && safe[next] === 1) || !this.terrain.canStep(cell, direction, localMask)) continue;
              const angle = Math.atan2(dy, dx) - preferred * Math.PI / 4;
              const score = Math.cos(angle) + Math.sin(angle) * (zombie.random % 2 ? 0.35 : -0.35);
              if (score <= alignment) continue;
              alignment = score;
              zombie.target = next;
              focus.searchEnd = next;
              const stride = next - cell;
              for (let step = 1; step < 4 && this.terrain.canStep(focus.searchEnd, direction, localMask)
                && (forts || safe[focus.searchEnd + stride] !== 1); step++) focus.searchEnd += stride;
            }
          }
          if (zombie.target < 0 && focus.searchEnd !== undefined && elapsed < focus.seenAt + 1.15) {
            zombie.speed = 0;
            return moving;
          }
        }
        if (zombie.target < 0) {
          const field = scent?.[cell] ? scent : baseline;
          const distance = field[cell];
          if (!distance) return moving;
          let best = -Infinity;
          for (let direction = 0; direction < steps.length; direction++) {
            const [dx, dy] = steps[direction];
            const next = cell + dy * this.terrain.columns + dx;
            if ((!forts && safe[next] === 1) || !field[next] || field[next] >= distance || !this.terrain.canStep(cell, direction, localMask)) continue;
            const ahead = (dx * zombie.vx + dy * zombie.vy) * (dx && dy ? Math.SQRT1_2 : 1);
            const score = distance - field[next] + ahead * 0.42;
            if (score <= best) continue;
            best = score;
            zombie.target = next;
          }
        }
        if (zombie.target < 0) {
          zombie.speed = 0;
          return moving;
        }
        if (forts && !forts.allows(cell, zombie.target)) {
          zombie.target = -1;
          zombie.speed = 0;
          zombie.cutoff = undefined;
          return moving;
        }
        aimRunner(zombie, this.terrain, zombie.target, mask);
      }
      const movement = moveRunner(zombie, remaining, 9);
      remaining -= movement;
      moving ||= movement > 0;
      if (zombie.x !== zombie.targetX || zombie.y !== zombie.targetY) break;
      zombie.cell = zombie.target;
      zombie.target = -1;
    }
    return moving;
  }
}
