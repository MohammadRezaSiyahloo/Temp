import { cellSize, steps, type CrowdField } from './crowd-field.ts';
import type { Point } from './routing.ts';

export type Barricade = [Point, Point];

export interface ZoneGate {
  position: Point;
  post: number;
  span: Barricade;
  alertUntil: number;
  integrity: number;
  pressure: number;
}

export const gateIntegrity = 12;
export const minBarricadeLength = 2;
export const maxBarricadeLength = 40;

export function barricadeCost([start, end]: Barricade) {
  return 45 + Math.ceil(Math.hypot(end[0] - start[0], end[1] - start[1])) * 5;
}

export function barricadeEdges(terrain: CrowdField, [start, end]: Barricade, mask = 0) {
  const dx = end[0] - start[0];
  const dy = end[1] - start[1];
  const length = Math.hypot(dx, dy);
  const center: Point = [(start[0] + end[0]) / 2, (start[1] + end[1]) / 2];
  const edges = new Map<number, number>();
  if (length < minBarricadeLength || length > maxBarricadeLength) return edges;
  terrain.visitArea(...center, length / 2 + cellSize * 2, cell => {
    const x = terrain.x(cell) - start[0];
    const y = terrain.y(cell) - start[1];
    const side = dx * y - dy * x;
    if (side < -1e-8 || side > length * cellSize * Math.SQRT2 + 1e-8) return;
    for (const [direction, [sx, sy]] of steps.entries()) {
      if (!terrain.canStep(cell, direction, mask)) continue;
      const next = cell + sy * terrain.columns + sx;
      const nextSide = side + cellSize * (dx * sy - dy * sx);
      if (nextSide >= -1e-8) continue;
      const along = Math.max(0, side) / (side - nextSide);
      const offset = ((x + along * sx * cellSize) * dx + (y + along * sy * cellSize) * dy) / (length * length);
      if (offset < -1e-8 || offset > 1 + 1e-8) continue;
      edges.set(cell * 8 + direction, next);
      edges.set(next * 8 + 7 - direction, cell);
    }
  });
  return edges;
}

export class Fortifications {
  readonly gates: ZoneGate[] = [];
  private readonly crossings = new Map<number, ZoneGate>();
  private readonly terrain: CrowdField;

  constructor(terrain: CrowdField, center: Point, flow: Uint16Array, barricades: readonly Barricade[]) {
    this.terrain = terrain;
    for (const span of barricades) {
      const edges = barricadeEdges(terrain, span);
      const [start, end] = span;
      const position: Point = [(start[0] + end[0]) / 2, (start[1] + end[1]) / 2];
      const dx = end[0] - start[0];
      const dy = end[1] - start[1];
      const protectedSide = Math.sign(dx * (center[1] - start[1]) - dy * (center[0] - start[0]));
      let post = -1;
      let best = Infinity;
      for (const cell of edges.values()) {
        const x = terrain.x(cell);
        const y = terrain.y(cell);
        if (!flow[cell] || protectedSide * (dx * (y - start[1]) - dy * (x - start[0])) < -1e-8) continue;
        const score = (x - position[0]) ** 2 + (y - position[1]) ** 2;
        if (score >= best) continue;
        best = score;
        post = cell;
      }
      if (post < 0) continue;
      const gate: ZoneGate = { position, post, span, integrity: gateIntegrity, pressure: 0, alertUntil: 0 };
      this.gates.push(gate);
      for (const key of edges.keys()) this.crossings.set(key, gate);
    }
  }

  allows(cell: number, next: number, pressure = true) {
    if (cell === next) return true;
    const dx = next % this.terrain.columns - cell % this.terrain.columns;
    const dy = Math.floor(next / this.terrain.columns) - Math.floor(cell / this.terrain.columns);
    if (Math.abs(dx) > 1 || Math.abs(dy) > 1) return true;
    const direction = dy < 0 ? dx + 1 : dy > 0 ? dx + 6 : dx < 0 ? 3 : 4;
    const gate = this.crossings.get(cell * 8 + direction);
    if (!gate || gate.integrity <= 0) return true;
    if (pressure) gate.pressure++;
    return false;
  }

  resolve(seconds: number, elapsed = 0) {
    for (const gate of this.gates) {
      if (gate.pressure) gate.alertUntil = elapsed + 6;
      gate.integrity = Math.max(0, gate.integrity - Math.min(5, gate.pressure) * seconds);
      gate.pressure = 0;
    }
  }
}

export function barricadeGaps(terrain: CrowdField, span: Barricade, mask: number, existing: readonly Barricade[]) {
  const [a, b] = span;
  const length = Math.hypot(b[0] - a[0], b[1] - a[1]);
  if (length < minBarricadeLength || length > maxBarricadeLength) return [];
  const x = (b[0] - a[0]) / length;
  const y = (b[1] - a[1]) / length;
  const blocked = new Set(barricadeEdges(terrain, span, mask).keys());
  for (const wall of existing) {
    for (const edge of barricadeEdges(terrain, wall, mask).keys()) blocked.add(edge);
  }
  const gaps: Point[] = [];
  for (const [point, direction] of [[a, -1], [b, 1]] as const) {
    const extension: Point = [point[0] + x * direction * 2.4, point[1] + y * direction * 2.4];
    const continuation = barricadeEdges(terrain, direction < 0 ? [extension, point] : [point, extension], mask);
    let best = Infinity;
    let gap: Point | undefined;
    for (const [edge, next] of continuation) {
      if (blocked.has(edge)) continue;
      const cell = Math.floor(edge / 8);
      const middle: Point = [(terrain.x(cell) + terrain.x(next)) / 2, (terrain.y(cell) + terrain.y(next)) / 2];
      const distance = (point[0] - middle[0]) ** 2 + (point[1] - middle[1]) ** 2;
      if (distance >= best) continue;
      best = distance;
      gap = middle;
    }
    if (gap) gaps.push(gap);
  }
  return gaps;
}
