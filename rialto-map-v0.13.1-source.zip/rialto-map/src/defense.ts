import { steps, type CrowdField } from './crowd-field.ts';
import { clearSight, localPath } from './pursuit.ts';
import { aimRunner, moveRunner, runnerTargetOpen, type RunnerMotion } from './runner-motion.ts';
import type { Outbreak, Zombie } from './outbreak.ts';
import { Fortifications, gateIntegrity, type Barricade, type ZoneGate } from './fortifications.ts';
import { random } from './spawn-planning.ts';
import type { Point } from './routing.ts';

export const evacuationRadius = 36;
export const maxSquadSize = 160;
export const infantryCost = 100;

export function hiringBudget(civilians: number, infected: number) {
  return 2000 + Math.floor(civilians / 120) * 100 + Math.floor(infected / 60) * 100;
}

export function shotAccuracy(distance: number, range: number) {
  return 0.96 - 0.58 * Math.min(1, distance / range) ** 1.6;
}
export const squadSize = 4;
export const fallbackSeconds = 12;

export const weapons = {
  carbine: { range: 23, interval: 0.48, magazine: 12, reload: 2.2, damage: 1 },
} as const;

export const soldierTypes = {
  infantry: { label: 'SWAT infantry', weapon: 'carbine', speed: 4.25, patrolSpeed: 1.8, health: 3 },
} as const satisfies Record<string, { label: string; weapon: keyof typeof weapons; speed: number; patrolSpeed: number; health: number }>;

export type Deployment = { position: Point; type: keyof typeof soldierTypes };
export type Soldier = RunnerMotion & {
  type: Deployment['type'];
  state: 'approach' | 'patrol' | 'fallback' | 'aboard' | 'lost';
  ammo: number;
  reloadUntil: number;
  nextShot: number;
  health: number;
  patrol: number;
  path: number[];
  pathIndex: number;
  retryAt: number;
  nextWound: number;
  seed: number;
  roundsFired: number;
  aimUntil: number;
  reserve: boolean;
  patrolTurn: number;
  responding?: ZoneGate;
};

export type Shot = { from: Point; to: Point; start: number; until: number };
type Impact = { shot: Shot; target: Zombie; damage: number; at: number; origin: Point };

export class Defense {
  readonly soldiers: Soldier[] = [];
  readonly shots: Shot[] = [];
  readonly center: Point;
  fortifications?: Fortifications;
  overrun = false;
  private exposedFor = 0;
  phase: 'defend' | 'fallback' | 'departed' = 'defend';
  eliminated = 0;
  private readonly impacts: Impact[] = [];
  readonly fallbackWindow: number;
  readonly radius: number;
  readonly count: number;
  private readonly seed: number;
  private posts: number[] = [];
  private readonly patrolPaths = new Map<number, number[][]>();
  private rally: Uint16Array = new Uint16Array(0);
  private nextSweep = 0;
  private nextRadio = 0;
  private readonly routes = new Map<number, number[]>();
  private readonly nearby = new Map<number, Zombie[]>();
  private readonly terrain: CrowdField;
  private readonly goal: number;
  private readonly duration: number;
  private readonly barricades: readonly Barricade[];
  private readonly deployments: readonly Deployment[];

  constructor(terrain: CrowdField, goal: number, duration: number, deployments: readonly Deployment[], count = squadSize, radius = evacuationRadius, seed = 0, barricades: readonly Barricade[] = []) {
    this.terrain = terrain;
    this.goal = goal;
    this.duration = duration;
    this.deployments = deployments;
    this.count = count;
    this.radius = radius;
    this.seed = seed;
    this.barricades = barricades;
    this.fallbackWindow = Math.max(fallbackSeconds, Math.ceil(radius * 0.52));
    this.center = [terrain.x(goal), terrain.y(goal)];
  }

  get aboard() { return this.soldiers.filter(soldier => soldier.state === 'aboard').length; }
  get lost() { return this.soldiers.filter(soldier => soldier.state === 'lost').length; }
  get coverage() {
    const guards = new Map<number | undefined, number>();
    const responders = new Map<ZoneGate, number>();
    for (const soldier of this.soldiers) {
      if (soldier.state !== 'patrol' && soldier.state !== 'approach') continue;
      if (!soldier.reserve) {
        const post = this.posts[soldier.patrol];
        guards.set(post, (guards.get(post) ?? 0) + 1);
      } else if (soldier.responding) {
        responders.set(soldier.responding, (responders.get(soldier.responding) ?? 0) + 1);
      }
    }
    return (this.fortifications?.gates ?? []).map(gate => ({
      guards: guards.get(gate.post) ?? 0, responders: responders.get(gate) ?? 0,
      integrity: Math.ceil(gate.integrity / gateIntegrity * 100),
    }));
  }

  get active() { return this.soldiers.filter(soldier => soldier.state !== 'aboard' && soldier.state !== 'lost'); }

  start(mask: number, flow: Uint16Array, baseline = flow) {
    if (this.soldiers.length) return;
    this.preparePerimeter(baseline);
    this.replan(mask, flow);
    for (let index = 0; index < this.count; index++) {
      const deployment = this.deployments[index];
      const type = deployment?.type ?? 'infantry';
      const unit = soldierTypes[type];
      const placed = deployment ? this.terrain.nearest(deployment.position, mask, undefined, 3) : -1;
      const reserveCount = Math.min(Math.floor(this.count / 2), Math.max(this.count - this.posts.length, 0), Math.max(1, Math.floor(this.count / 4)));
      const guards = this.count - reserveCount;
      const reserve = index >= guards;
      const post = reserve ? -1 : Math.floor(index * this.posts.length / guards);
      const cell = placed >= 0 ? placed : reserve ? this.goal : this.posts[post] ?? this.goal;
      const x = this.terrain.x(cell);
      const y = this.terrain.y(cell);
      this.soldiers.push({
        type, cell, x, y, target: -1, targetX: x, targetY: y, heading: (index % 4 - 2) * Math.PI / 2,
        vx: 0, vy: 0, speed: 0, travel: 0, ammo: weapons[unit.weapon].magazine, reloadUntil: 0, nextShot: 0,
        health: unit.health, state: placed < 0 || this.inside(x, y) ? 'patrol' : 'approach', patrol: post, path: [], pathIndex: 0, retryAt: 0, nextWound: 0, seed: this.seed ^ Math.imul(index + 1, 0x9e3779b1), roundsFired: 0, aimUntil: 0, reserve, patrolTurn: index,
      });
    }
  }

  preparePerimeter(baseline: Uint16Array) {
    this.fortifications ??= new Fortifications(this.terrain, this.center, baseline, this.barricades);
  }

  inside(x: number, y: number) {
    return (x - this.center[0]) ** 2 + (y - this.center[1]) ** 2 <= this.radius ** 2;
  }

  replan(mask: number, flow: Uint16Array) {
    this.rally = flow;
    this.routes.clear();
    this.patrolPaths.clear();
    const previousPosts = this.posts;
    this.posts = this.fortifications?.gates.map(gate => gate.post).filter(post => flow[post]) ?? [];
    if (!this.posts.length && flow[this.goal]) this.posts.push(this.goal);
    for (const [index, soldier] of this.active.entries()) {
      const previous = this.posts.indexOf(previousPosts[soldier.patrol]);
      soldier.patrol = soldier.reserve ? -1 : previous >= 0 ? previous : index % Math.max(1, this.posts.length);
      soldier.responding = undefined;
      soldier.path = [];
      soldier.pathIndex = 0;
      soldier.retryAt = 0;
      if (soldier.target >= 0 && this.terrain.open(this.terrain.cell(soldier.x, soldier.y), mask)
        && !runnerTargetOpen(soldier, this.terrain, mask)) aimRunner(soldier, this.terrain, soldier.cell, mask);
    }
  }

  tick(elapsed: number, seconds: number, mask: number, outbreak: Outbreak) {
    this.fortifications?.resolve(seconds, elapsed);
    if (!this.overrun) {
      const occupied = outbreak.zombies.some(zombie => this.rally[this.terrain.cell(zombie.x, zombie.y)] === 1);
      this.exposedFor = occupied ? this.exposedFor + seconds : 0;
      this.overrun = this.exposedFor >= 3;
    }
    let pending = 0;
    for (const impact of this.impacts) {
      if (impact.at > elapsed) {
        this.impacts[pending++] = impact;
        continue;
      }
      const { shot, target } = impact;
      if ((target.x - shot.to[0]) ** 2 + (target.y - shot.to[1]) ** 2 <= 1.6 ** 2
        && clearSight(this.terrain, this.terrain.cell(...impact.origin), this.terrain.cell(target.x, target.y), mask)
        && outbreak.hit(target, impact.damage)) this.eliminated++;
    }
    this.impacts.length = pending;
    if (elapsed >= this.duration - this.fallbackWindow) this.phase = 'fallback';
    while (this.shots.length && this.shots[0].until <= elapsed) this.shots.shift();
    const fire = elapsed >= this.nextSweep;
    if (fire) {
      this.nextSweep = elapsed + 0.12;
      this.nearby.clear();
      for (const zombie of outbreak.zombies) {
        const key = this.bucket(zombie.x, zombie.y);
        const occupants = this.nearby.get(key);
        if (occupants) occupants.push(zombie);
        else this.nearby.set(key, [zombie]);
      }
    }
    if (this.phase === 'defend' && elapsed >= this.nextRadio) {
      this.nextRadio = elapsed + 0.65;
      this.radio(elapsed, mask);
    }
    for (const soldier of this.active) {
      if (this.phase === 'fallback' && soldier.state !== 'fallback') {
        soldier.state = 'fallback';
        soldier.responding = undefined;
        soldier.path = [];
      }
      if (elapsed >= soldier.aimUntil) this.move(soldier, elapsed, seconds, mask);
      if (soldier.reloadUntil && elapsed >= soldier.reloadUntil) {
        soldier.reloadUntil = 0;
        soldier.ammo = weapons[soldierTypes[soldier.type].weapon].magazine;
      }
      if (fire && soldier.state !== 'aboard') {
        const candidates = this.targets(soldier.x, soldier.y, weapons[soldierTypes[soldier.type].weapon].range);
        this.fire(soldier, elapsed, mask, candidates);
        this.checkContact(soldier, elapsed, mask, candidates);
      }
    }
  }

  private move(soldier: Soldier, elapsed: number, seconds: number, mask: number) {
    const unit = soldierTypes[soldier.type];
    soldier.speed = (soldier.state === 'patrol' && !soldier.responding ? unit.patrolSpeed : unit.speed) * this.terrain.paceFactor(soldier.cell);
    let remaining = soldier.speed * seconds;
    while (remaining > 0.0001) {
      if (soldier.target < 0) {
        if (soldier.state === 'fallback' && this.rally[soldier.cell] === 1) {
          soldier.state = 'aboard';
          soldier.speed = 0;
          return;
        }
        if (soldier.state === 'approach' && this.rally[soldier.cell]
          && (this.inside(soldier.x, soldier.y) || soldier.cell === this.posts[soldier.patrol])) soldier.state = 'patrol';
        const localMask = this.terrain.open(soldier.cell, mask) ? mask : 0;
        const next = soldier.state === 'patrol' ? this.patrolStep(soldier, elapsed, localMask) : this.rallyStep(soldier, localMask);
        if (next < 0) {
          soldier.speed = 0;
          return;
        }
        aimRunner(soldier, this.terrain, next, mask);
      }
      remaining -= moveRunner(soldier, remaining, 10);
      if (soldier.x !== soldier.targetX || soldier.y !== soldier.targetY) return;
      soldier.cell = soldier.target;
      soldier.target = -1;
    }
  }

  private rallyStep(soldier: Soldier, mask: number) {
    const flow = this.rally;
    let best = -Infinity;
    let target = -1;
    for (const [direction, [dx, dy]] of steps.entries()) {
      const next = soldier.cell + dy * this.terrain.columns + dx;
      if (!flow[next] || (flow[soldier.cell] && flow[next] >= flow[soldier.cell]) || !this.terrain.canStep(soldier.cell, direction, mask)) continue;
      const score = -flow[next] + (dx * soldier.vx + dy * soldier.vy) * 0.25;
      if (score > best) { best = score; target = next; }
    }
    return target;
  }

  private radio(elapsed: number, mask: number) {
    const available = this.active.filter(soldier => soldier.state === 'patrol');
    const gates = (this.fortifications?.gates ?? []).filter(gate => this.rally[gate.post]);
    for (const gate of gates) {
      const [x, y] = gate.position;
      const seen = this.targets(x, y, 14).some(zombie =>
        (x - zombie.x) ** 2 + (y - zombie.y) ** 2 <= 14 ** 2
        && clearSight(this.terrain, gate.post, this.terrain.cell(zombie.x, zombie.y), mask));
      if (seen) gate.alertUntil = elapsed + 6;
    }
    for (const soldier of available) {
      const home = this.posts[soldier.patrol];
      const alert = soldier.reserve ? soldier.responding : gates.find(gate => gate.post === home);
      this.assignResponse(soldier, alert && alert.alertUntil > elapsed ? alert : undefined);
    }
    for (const gate of gates.filter(gate => gate.alertUntil > elapsed).sort((a, b) => a.integrity - b.integrity)) {
      if (available.some(soldier => soldier.reserve && soldier.responding === gate)) continue;
      let nearest: Soldier | undefined;
      let best = Infinity;
      for (const soldier of available) {
        if (!soldier.reserve || soldier.responding) continue;
        const distance = (soldier.x - gate.position[0]) ** 2 + (soldier.y - gate.position[1]) ** 2;
        if (distance >= best || (soldier.cell !== gate.post && !this.route(soldier.cell, gate.post, mask).length)) continue;
        best = distance;
        nearest = soldier;
      }
      if (nearest) this.assignResponse(nearest, gate);
    }
  }

  private assignResponse(soldier: Soldier, gate: ZoneGate | undefined) {
    if (soldier.responding === gate) return;
    soldier.responding = gate;
    soldier.path = [];
    soldier.pathIndex = 0;
    soldier.retryAt = 0;
  }

  private route(start: number, end: number, mask: number) {
    const key = (start * this.terrain.cells.length + end) * 16 + mask;
    let path = this.routes.get(key);
    if (!path) {
      path = localPath(this.terrain, start, end, mask, cell => !!this.rally[cell]
        && (this.inside(this.terrain.x(cell), this.terrain.y(cell)) || this.posts.includes(end)));
      if (this.routes.size >= 1024) this.routes.clear();
      this.routes.set(key, path);
    }
    return path;
  }

  private patrolStep(soldier: Soldier, elapsed: number, mask: number) {
    if (soldier.pathIndex < soldier.path.length) return soldier.path[soldier.pathIndex++];
    if (elapsed < soldier.retryAt) return -1;
    soldier.retryAt = elapsed + 0.85;
    let home = this.posts[soldier.patrol] ?? this.goal;
    const hasCoverage = this.soldiers.some(other => other !== soldier && other.patrol === soldier.patrol
      && (other.state === 'patrol' || other.state === 'approach'));
    if (!soldier.reserve && !soldier.responding && (hasCoverage || !this.posts[soldier.patrol])) {
      const vacant = this.posts.findIndex(post => !this.soldiers.some(other => other !== soldier
        && (other.state === 'patrol' || other.state === 'approach') && this.posts[other.patrol] === post));
      if (vacant >= 0 && this.posts[vacant] !== home) {
        const next = this.posts[vacant];
        const path = this.route(soldier.cell, next, mask);
        if (path.length) {
          soldier.patrol = vacant;
          home = next;
        }
      }
    }
    if (soldier.reserve && !soldier.responding && soldier.patrolTurn % 4 === 0) {
      const vacant = this.posts.find(post => !this.soldiers.some(other => !other.reserve
        && (other.state === 'patrol' || other.state === 'approach') && this.posts[other.patrol] === post));
      if (vacant !== undefined && this.route(soldier.cell, vacant, mask).length) home = vacant;
    }
    const post = soldier.responding?.post ?? home;
    const radius = soldier.responding ? 4 : soldier.reserve || home === this.goal ? Math.min(15, this.radius * 0.52) : 8;
    const distance = Math.hypot(soldier.x - this.terrain.x(post), soldier.y - this.terrain.y(post));
    const route = distance > (soldier.responding ? 3 : radius) ? this.route(soldier.cell, post, mask) : [];
    if (route.length) {
      soldier.path = route;
      soldier.pathIndex = 1;
      return route[0];
    }
    const options = this.roamingPaths(soldier.cell, post, radius, mask);
    if (!options.length) return -1;
    const index = Math.floor(random(soldier.seed + ++soldier.patrolTurn * 91) * options.length);
    soldier.path = options[index];
    soldier.pathIndex = 1;
    return soldier.path[0];
  }

  private roamingPaths(start: number, post: number, radius: number, mask: number) {
    const key = ((start * this.terrain.cells.length + post) * 16 + mask) * 4 + (radius === 4 ? 0 : radius === 8 ? 1 : 2);
    const cached = this.patrolPaths.get(key);
    if (cached) return cached;
    const queue = [start];
    const parents = new Map<number, number>([[start, -1]]);
    const x = this.terrain.x(post);
    const y = this.terrain.y(post);
    const destinations: number[] = [];
    let nearest = Infinity;
    let fallback = -1;
    for (let index = 0; index < queue.length && index < 340 && destinations.length < 12; index++) {
      const cell = queue[index];
      const distance = (this.terrain.x(cell) - x) ** 2 + (this.terrain.y(cell) - y) ** 2;
      if (cell !== start && distance < nearest) {
        nearest = distance;
        fallback = cell;
      }
      if (index >= 42 && distance <= radius ** 2
        && Math.hypot(this.terrain.x(cell) - this.terrain.x(start), this.terrain.y(cell) - this.terrain.y(start)) > 2.4) {
        destinations.push(cell);
      }
      for (const [direction, [dx, dy]] of steps.entries()) {
        const next = cell + dy * this.terrain.columns + dx;
        if (parents.has(next) || !this.rally[next] || !this.terrain.canStep(cell, direction, mask)) continue;
        parents.set(next, cell);
        queue.push(next);
      }
    }
    if (!destinations.length && fallback >= 0) destinations.push(fallback);
    const paths = destinations.map(destination => {
      const path: number[] = [];
      for (let cell = destination; cell !== start; cell = parents.get(cell)!) path.push(cell);
      return path.reverse();
    });
    if (this.patrolPaths.size >= 1024) this.patrolPaths.clear();
    this.patrolPaths.set(key, paths);
    return paths;
  }

  private bucket(x: number, y: number) {
    return Math.floor(x / 24) + Math.floor(y / 24) * 4096;
  }

  private targets(worldX: number, worldY: number, range: number) {
    const candidates: Zombie[] = [];
    for (let y = Math.floor((worldY - range) / 24); y <= Math.floor((worldY + range) / 24); y++) {
      for (let x = Math.floor((worldX - range) / 24); x <= Math.floor((worldX + range) / 24); x++) {
        for (const zombie of this.nearby.get(x + y * 4096) ?? []) candidates.push(zombie);
      }
    }
    return candidates;
  }

  private fire(soldier: Soldier, elapsed: number, mask: number, candidates: Zombie[]) {
    if (soldier.reloadUntil || soldier.nextShot > elapsed) return;
    const weapon = weapons[soldierTypes[soldier.type].weapon];
    const origin = this.terrain.cell(soldier.x, soldier.y);
    let target: Zombie | undefined;
    let range = weapon.range ** 2;
    for (const zombie of candidates) {
      const distance = (zombie.x - soldier.x) ** 2 + (zombie.y - soldier.y) ** 2;
      if (distance >= range || !clearSight(this.terrain, origin, this.terrain.cell(zombie.x, zombie.y), mask)) continue;
      target = zombie;
      range = distance;
    }
    if (!target) return;
    if (soldier.responding && soldier.cell !== soldier.responding.post && range > 9 ** 2
      && (soldier.target >= 0 || soldier.pathIndex < soldier.path.length)) return;
    const angle = Math.atan2(target.y - soldier.y, target.x - soldier.x);
    const turn = Math.atan2(Math.sin(angle - soldier.heading), Math.cos(angle - soldier.heading));
    if (Math.abs(turn) > 0.16) {
      soldier.heading += Math.max(-0.72, Math.min(0.72, turn));
      soldier.speed = 0;
      soldier.aimUntil = elapsed + 0.17;
      return;
    }
    soldier.heading = angle;
    soldier.speed = 0;
    soldier.aimUntil = elapsed + 0.22;
    const roll = random(soldier.seed ^ Math.imul(++soldier.roundsFired, 0x85ebca6b));
    const hits = roll < shotAccuracy(Math.sqrt(range), weapon.range);
    const offset = hits ? 0 : (roll < 0.8 ? -1 : 1) * (1.4 + Math.sqrt(range) * 0.09);
    const to: Point = [target.x - Math.sin(angle) * offset, target.y + Math.cos(angle) * offset];
    // Clip a missed tracer at the first blocked patch of ground.
    if (!hits) {
      const dx = to[0] - soldier.x;
      const dy = to[1] - soldier.y;
      const samples = Math.max(1, Math.ceil(Math.hypot(dx, dy) / 0.6));
      let previous = origin;
      for (let i = 1; i <= samples; i++) {
        const cell = this.terrain.cell(soldier.x + dx * i / samples, soldier.y + dy * i / samples);
        if (!this.terrain.touches(previous, cell, mask)) {
          to[0] = soldier.x + dx * (i - 1) / samples;
          to[1] = soldier.y + dy * (i - 1) / samples;
          break;
        }
        previous = cell;
      }
    }
    const muzzle: Point = [soldier.x + Math.cos(angle) * 0.63, soldier.y + Math.sin(angle) * 0.63];
    const shot = { from: muzzle, to, start: elapsed, until: elapsed + 0.15 };
    this.shots.push(shot);
    if (hits) this.impacts.push({ shot, target, damage: weapon.damage, at: elapsed + 0.075, origin: [soldier.x, soldier.y] });
    soldier.ammo--;
    soldier.nextShot = elapsed + weapon.interval;
    if (!soldier.ammo) soldier.reloadUntil = elapsed + weapon.reload;
  }

  private checkContact(soldier: Soldier, elapsed: number, mask: number, candidates: Zombie[]) {
    if (soldier.nextWound > elapsed) return;
    const cell = this.terrain.cell(soldier.x, soldier.y);
    const grabbed = candidates.some(zombie => !zombie.attack && (zombie.x - soldier.x) ** 2 + (zombie.y - soldier.y) ** 2 <= 0.9 ** 2
      && this.terrain.touches(cell, this.terrain.cell(zombie.x, zombie.y), mask)
      && (this.fortifications?.allows(this.terrain.cell(zombie.x, zombie.y), cell, false) ?? true));
    if (!grabbed) return;
    soldier.health--;
    soldier.nextWound = elapsed + 0.85;
    if (!soldier.health) soldier.state = 'lost';
  }

  depart() {
    if (this.phase === 'departed') return;
    for (const soldier of this.active) soldier.state = 'lost';
    this.shots.length = 0;
    this.impacts.length = 0;
    this.phase = 'departed';
  }
}
