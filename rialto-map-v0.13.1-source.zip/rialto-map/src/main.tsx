import { useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource-variable/dm-sans';
import '@fontsource/barlow-condensed/latin-600.css';
import '@fontsource/barlow-condensed/latin-700.css';
import '@fontsource/ibm-plex-mono/latin-500.css';
import mapData from '../data/venice.json';
import overviewData from '../data/venice-overview.json';
import scenario from '../data/rialto-scenario.json';
import outbreakScenario from '../data/rialto-outbreak.json';
import type { Overview } from './cartography.ts';
import { CrowdField } from './crowd-field.ts';
import { EvacuationGroup, type ConvoyStatus, type SpawnPlan } from './convoy.ts';
import { Icon } from './icons.tsx';
import { MapView } from './MapView.tsx';
import type { OutbreakRules } from './outbreak.ts';
import { projectLocation, StreetGraph, type CrossingId, type Point, type Venice } from './routing.ts';
import { splitPopulation } from './spawn-planning.ts';
import { evacuationRadius, hiringBudget, infantryCost, maxSquadSize, squadSize, soldierTypes } from './defense.ts';
import { barricadeCost, barricadeEdges, barricadeGaps, maxBarricadeLength, minBarricadeLength, type Barricade } from './fortifications.ts';
import './styles.css';

const data = mapData as unknown as Venice;
const overview = overviewData as unknown as Overview;
const graph = new StreetGraph(data.nodes, data.edges);
const terrain = new CrowdField(data, overview.water);
const pickup = graph.nearest(projectLocation(scenario.pickup as Point, data.projection));
const evacuation = graph.nearest(projectLocation(scenario.evacuation as Point, data.projection));
if (pickup === undefined || evacuation === undefined) throw new Error('Scenario waypoints must be on the street graph.');
const defaults = { start: pickup, end: evacuation };
const outbreakPickup = graph.nearest(projectLocation(outbreakScenario.pickup as Point, data.projection));
const outbreakExit = graph.nearest(projectLocation(outbreakScenario.evacuation as Point, data.projection));
if (outbreakPickup === undefined || outbreakExit === undefined) throw new Error('The outbreak requires pickup and extraction points.');
const missions = {
  outbreak: { waypoints: { start: outbreakPickup, end: outbreakExit }, count: outbreakScenario.civilians, objective: outbreakScenario.objective },
  drill: { waypoints: defaults, count: scenario.civilians, objective: scenario.objective },
};
type Mission = keyof typeof missions;
type Placement = 'civilians' | 'zombies' | 'soldiers' | 'barricade' | 'end';
const outbreakRules: OutbreakRules = {
  duration: outbreakScenario.duration,
  downDuration: outbreakScenario.downDuration,
  origins: outbreakScenario.origins.map(origin => ({
    position: projectLocation(origin.location as Point, data.projection),
    pace: origin.pace,
  })),
};
const crossingNames: Record<CrossingId, string> = {
  rialto: 'Rialto',
  scalzi: 'Scalzi',
  accademia: 'Accademia',
};
const defaultZombiePoints = outbreakRules.origins.map(origin => origin.position);

function makeGroup(waypoints: typeof defaults, closed: ReadonlySet<CrossingId>, count: number, mission: Mission, spawns: SpawnPlan, seed: number) {
  return new EvacuationGroup(terrain, graph, waypoints.start, waypoints.end, closed, count, scenario.metersPerSecond,
    seed, mission === 'outbreak' ? { ...outbreakRules, duration: spawns.roundSeconds ?? outbreakRules.duration } : undefined,
    mission === 'outbreak' ? { ...spawns, soldiers: spawns.soldiers ?? [] } : spawns);
}

const readyMessage = (mission: Mission) => mission === 'outbreak'
  ? `Place up to ${squadSize} soldiers. Any unassigned soldiers start at extraction.`
  : 'Choose which crossings to keep open, then dispatch the group.';
const startingStats = { evacuated: 0, infected: 0, remaining: outbreakRules.duration, eliminated: 0, aboard: 0, lost: 0, patrol: 0, reloading: 0, waiting: 0, shelterLosses: 0, overrun: false, breached: 0, responding: 0, coverage: '' };

type RunResult = { evacuated: number; aboard: number; civilians: number; troops: number; creditsSpent: number };

function App() {
  const [playSpeed, setPlaySpeed] = useState(1);
  const [mission, setMission] = useState<Mission>('outbreak');
  const [closed, setClosed] = useState<ReadonlySet<CrossingId>>(new Set());
  const [waypoints, setWaypoints] = useState(missions.outbreak.waypoints);
  const [spawns, setSpawns] = useState<SpawnPlan>({});
  const [selection, setSelection] = useState<Placement | null>(null);
  const [barricadeStart, setBarricadeStart] = useState<Point | null>(null);
  function select(next: Placement | null) {
    setBarricadeStart(null);
    setSelection(next);
  }
  const [status, setStatus] = useState<ConvoyStatus>('ready');
  const [{ evacuated, infected, remaining, eliminated, aboard, lost, patrol, reloading, waiting, shelterLosses, overrun, breached, responding }, setStats] = useState(startingStats);
  const [groupSize, setGroupSize] = useState(missions.outbreak.count);
  const [message, setMessage] = useState(readyMessage('outbreak'));
  const [seed] = useState(() => Math.floor(Math.random() * 0x100000000));
  const runSeed = useRef(seed);
  const frameTime = useRef(0);
  const startCrossings = useRef<ReadonlySet<CrossingId>>(new Set());
  const [lastResult, setLastResult] = useState<RunResult>();
  const [comparison, setComparison] = useState<RunResult>();
  const convoyRef = useRef<EvacuationGroup | null>(null);
  convoyRef.current ??= makeGroup(waypoints, closed, groupSize, mission, spawns, runSeed.current);
  const convoy = convoyRef.current;
  const route = convoy.route;
  const civilianPoints = spawns.civilians === 'random' ? [] : spawns.civilians ?? [data.nodes[waypoints.start]];
  const zombiePoints = spawns.zombies === 'random' || mission !== 'outbreak' ? [] : spawns.zombies ?? defaultZombiePoints;
  const zombieTotal = spawns.zombieCount ?? defaultZombiePoints.length;
  const roundSeconds = spawns.roundSeconds ?? outbreakRules.duration;
  const zoneRadius = spawns.zoneRadius ?? evacuationRadius;
  const squadCount = convoy.defense?.count ?? squadSize;
  const budget = hiringBudget(groupSize, zombieTotal);
  const barricades = spawns.barricades ?? [];
  const barricadeSpend = barricades.reduce((total, span) => total + barricadeCost(span), 0);
  const credits = budget - squadCount * infantryCost - barricadeSpend;

  function prepare(nextWaypoints: typeof defaults, nextSpawns: SpawnPlan, count: number, feedback: string) {
    if (mission === 'outbreak') {
      const spend = (nextSpawns.barricades ?? []).reduce((total, span) => total + barricadeCost(span), 0);
      const capacity = Math.min(maxSquadSize, Math.floor((hiringBudget(count, nextSpawns.zombieCount ?? defaultZombiePoints.length) - spend) / infantryCost));
      if (capacity < 1) {
        setMessage('Remove a barricade before reducing the population. The new budget must cover at least one soldier.');
        return;
      }
      const hired = Math.min(capacity, nextSpawns.hired ?? squadSize);
      nextSpawns = { ...nextSpawns, hired, soldiers: nextSpawns.soldiers?.slice(0, hired) };
    }
    convoyRef.current = makeGroup(nextWaypoints, closed, count, mission, nextSpawns, runSeed.current);
    frameTime.current = 0;
    setWaypoints(nextWaypoints);
    setSpawns(nextSpawns);
    setGroupSize(count);
    setStatus('ready');
    setStats({ ...startingStats, remaining: convoyRef.current.outbreak?.duration ?? outbreakRules.duration });
    setMessage(feedback);
  }

  function toggleCrossing(id: CrossingId) {
    const next = new Set(closed);
    const opening = next.delete(id);
    if (!opening) next.add(id);
    const previous = convoy.route;
    convoy.replan(next);
    setClosed(next);
    setStatus(convoy.status);
    if (convoy.status === 'arrived' || convoy.status === 'finished') return;
    if (spawns.civilians === 'random') {
      setMessage(`${crossingNames[id]} ${opening ? 'reopened' : 'closed'}.${convoy.stranded ? ` ${convoy.stranded} civilians have no route.` : ''}`);
    } else if (!convoy.route) {
      setMessage(convoy.status === 'moving'
        ? 'All routes to evacuation are blocked. The group will stop at the last reachable point.'
        : 'There is no open route. Reopen a crossing to connect the two points.');
    } else if (convoy.stranded) {
      setMessage(`${convoy.stranded} of ${groupSize} civilians have no route. The others can continue.`);
    } else if (civilianPoints.length > 1) {
      setMessage(`${convoy.routes.length} of ${civilianPoints.length} civilian spawn routes are open.`);
    } else if (!previous || previous.crossings.join() !== convoy.route.crossings.join()) {
      const crossing = convoy.route.crossings.map(item => crossingNames[item]).join(', ');
      setMessage(crossing ? `Route updated via ${crossing}.` : 'A new route is open.');
    } else {
      setMessage(`${crossingNames[id]} ${opening ? 'reopened' : 'closed'}. Current route is still clear.`);
    }
  }

  function place(point: Point) {
    if (!selection) return;
    if (selection === 'barricade') {
      if (terrain.cell(...point) < 0) {
        setMessage('Choose an endpoint inside the playable district.');
        return;
      }
      const endpoint: Point = [Math.round(point[0] * 10) / 10, Math.round(point[1] * 10) / 10];
      if (!barricadeStart) {
        setBarricadeStart(endpoint);
        setMessage('Choose the other end of the barricade.');
        return;
      }
      const span: Barricade = [barricadeStart, endpoint];
      const length = Math.hypot(endpoint[0] - barricadeStart[0], endpoint[1] - barricadeStart[1]);
      if (length < minBarricadeLength || length > maxBarricadeLength) {
        setMessage(`Draw a barricade between ${minBarricadeLength} and ${maxBarricadeLength} meters long.`);
        return;
      }
      const cost = barricadeCost(span);
      if (cost > credits) {
        setMessage(`This barricade costs ${cost} credits. Shorten it or release a soldier.`);
        return;
      }
      const edges = barricadeEdges(terrain, span);
      const flow = terrain.openFlow(terrain.nearest(data.nodes[waypoints.end]));
      if (![...edges.values()].some(cell => flow[cell])) {
        setMessage('Draw across walkable ground connected to extraction.');
        return;
      }
      if (barricades.some(existing => [...barricadeEdges(terrain, existing).keys()].some(edge => edges.has(edge)))) {
        setMessage('That span overlaps a barricade you already placed.');
        return;
      }
      prepare(waypoints, { ...spawns, barricades: [...barricades, span] }, groupSize, `Barricade placed for ${cost} credits.`);
      setBarricadeStart(null);
      return;
    }
    if (selection === 'end') {
      const node = graph.nearest(point, 38);
      if (node === undefined) {
        setMessage('Choose a street or footpath in the playable district.');
        return;
      }
      const goal = terrain.nearest(data.nodes[node]);
      const flow = terrain.openFlow(goal);
      if (goal < 0 || [...civilianPoints, ...zombiePoints].some(position => {
        const cell = terrain.nearest(position, 0, flow, 20);
        return cell < 0 || flow[cell] === 1;
      })) {
        setMessage('Choose an evacuation point outside the spawn areas and reachable with the bridges open.');
        return;
      }
      prepare({ ...waypoints, end: node }, spawns, groupSize, 'Evacuation moved.');
      select(null);
      return;
    }
    const flow = terrain.openFlow(terrain.nearest(data.nodes[waypoints.end]));
    const mask = terrain.mask(closed);
    if (selection === 'soldiers') {
      const deployments = spawns.soldiers ?? [];
      const cell = terrain.cell(...point);
      if (!terrain.open(cell, mask) || !flow[cell]) {
        setMessage('Place infantry on a street with a route to extraction.');
        return;
      }
      if (deployments.length >= squadCount) return;
      if (deployments.some(({ position }) => terrain.cell(...position) === cell)) {
        setMessage('A soldier is already assigned to this position.');
        return;
      }
      const soldiers = [...deployments, { position: [terrain.x(cell), terrain.y(cell)] as Point, type: 'infantry' as const }];
      prepare(waypoints, { ...spawns, soldiers }, groupSize, `${soldiers.length} of ${squadCount} deployment positions set.`);
      if (soldiers.length === squadCount) select(null);
      return;
    }
    const cell = terrain.nearest(point, mask, flow, 12);
    if (cell < 0 || flow[cell] <= 1) {
      setMessage('Choose walkable ground outside the evacuation zone.');
      return;
    }
    const layout = spawns[selection];
    const points = Array.isArray(layout) ? layout : [];
    if (points.some(position => terrain.cell(...position) === cell)) {
      setMessage('There is already a spawn point here.');
      return;
    }
    const limit = selection === 'civilians' ? groupSize : 20000;
    if (points.length >= limit) {
      setMessage(selection === 'civilians' ? 'Increase the crowd size to add another civilian spawn.' : 'The zombie spawn list is full.');
      return;
    }
    const next = [...points, [terrain.x(cell), terrain.y(cell)] as Point];
    prepare(waypoints, { ...spawns, [selection]: next,
      zombieCount: selection === 'zombies' ? Math.max(zombieTotal, next.length) : spawns.zombieCount,
    }, groupSize, `${next.length} ${selection === 'civilians' ? 'civilian' : 'zombie'} spawn ${next.length === 1 ? 'point' : 'points'} set.`);
  }

  function reset(nextMission = mission, count = groupSize, keepLayout = true, replay = false) {
    const open = replay ? new Set(startCrossings.current) : new Set<CrossingId>();
    if (!replay) runSeed.current = Math.floor(Math.random() * 0x100000000);
    setComparison(replay ? lastResult : undefined);
    setLastResult(undefined);
    const initial = keepLayout ? waypoints : missions[nextMission].waypoints;
    const layout = keepLayout ? spawns : {};
    convoyRef.current = makeGroup(initial, open, count, nextMission, layout, runSeed.current);
    frameTime.current = 0;
    setMission(nextMission);
    setGroupSize(count);
    setWaypoints(initial);
    setSpawns(layout);
    setClosed(open);
    setStatus('ready');
    setStats({ ...startingStats, remaining: convoyRef.current.outbreak?.duration ?? outbreakRules.duration });
    select(null);
    setMessage(replay ? 'Same outbreak ready. Adjust your defenses or dispatch to retry.' : readyMessage(nextMission));
  }

  function frame(seconds: number) {
    const active = convoyRef.current!;
    const before = active.status;
    const previousSample = Math.floor(active.elapsed * 6);
    // A fixed step keeps replay outcomes independent of render rate and speed.
    const step = 1 / 30;
    const large = active.initialPopulation >= 6000;
    const elapsed = Math.min(seconds, large ? step : 0.1) * playSpeed;
    if (before === 'ready' || before === 'finished' || before === 'arrived') frameTime.current = 0;
    else frameTime.current += elapsed;
    while (frameTime.current >= step) {
      active.tick(step);
      frameTime.current -= step;
    }
    if (active.status !== before || Math.floor(active.elapsed * 6) !== previousSample) {
      const next = {
        evacuated: active.evacuated,
        waiting: active.waiting,
        shelterLosses: active.shelterLosses,
        overrun: active.defense?.overrun ?? false,
        coverage: active.defense?.coverage.map(gate => [gate.guards, gate.responders, gate.integrity].join('/')).join(',') ?? '',
        responding: active.defense?.active.filter(soldier => soldier.responding).length ?? 0,
        breached: active.defense?.fortifications?.gates.filter(gate => gate.integrity <= 0).length ?? 0,
        infected: active.outbreak?.infected ?? 0,
        remaining: Math.max(0, Math.ceil((active.outbreak?.duration ?? 0) - active.elapsed)),
        eliminated: active.defense?.eliminated ?? 0,
        aboard: active.defense?.aboard ?? 0,
        lost: active.defense?.lost ?? 0,
        patrol: active.defense?.soldiers.filter(soldier => soldier.state === 'patrol').length ?? 0,
        reloading: active.defense?.active.filter(soldier => soldier.reloadUntil > active.elapsed).length ?? 0,
      };
      setStats(old => (Object.keys(next) as (keyof typeof next)[]).every(key => old[key] === next[key]) ? old : next);
    }
    if (active.status !== before) {
      setStatus(active.status);
      if (active.status === 'finished') {
        const infected = active.outbreak?.infected ?? 0;
        if (active.defense) setLastResult({
          evacuated: active.evacuated, aboard: active.defense.aboard, civilians: groupSize,
          troops: active.defense.count, creditsSpent: active.defense.count * infantryCost + barricadeSpend,
        });
        const squad = active.defense ? ` ${active.defense.aboard}/${active.defense.count} soldiers extracted.` : '';
        setMessage(`${active.evacuated} evacuated · ${infected} infected · ${active.people.length - active.evacuated - infected - active.shelterLosses} left behind.${active.shelterLosses ? ` ${active.shelterLosses} lost at pickup.` : ''}${squad}`);
      } else if (active.status === 'arrived') {
        setMessage(`All ${groupSize} civilians reached the evacuation point.`);
      } else if (active.status === 'holding') {
        setMessage('Civilians are holding. Reopen a crossing to give them a route.');
      } else {
        setMessage('Civilians are moving toward extraction.');
      }
    }
    return active;
  }

  function dispatch() {
    if (convoy.people.length !== groupSize || (convoy.outbreak && convoy.outbreak.zombies.length !== zombieTotal)) {
      setMessage('A spawn area could not fit its assigned group. Move the point onto open ground.');
      return;
    }
    startCrossings.current = new Set(closed);
    convoy.dispatch();
    setStatus(convoy.status);
    setMessage(convoy.defense ? 'The squad is moving to cover extraction. You can still change crossings.'
      : 'Civilians are finding their own way to evacuation. You can still change crossings.');
  }

  function resizeCrowd(count: number) {
    prepare(waypoints, spawns, count, readyMessage(mission));
  }

  const editing = status === 'ready' || status === 'arrived' || status === 'finished';
  const routeLength = spawns.civilians === 'random' ? 'Random' : civilianPoints.length > 1
    ? `${convoy.routes.length} / ${civilianPoints.length} open`
    : route ? (route.meters >= 1000 ? `${(route.meters / 1000).toFixed(2)} km` : `${Math.round(route.meters)} m`) : 'Blocked';
  const groupStatus = { ready: 'Awaiting dispatch', moving: 'In transit', holding: 'Holding position', arrived: 'Evacuated', finished: 'Extraction ended' }[status];
  const timer = status === 'finished' ? 'Extraction closed' : `${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, '0')} left`;
  function changeLayout(kind: 'civilians' | 'zombies', layout: SpawnPlan['civilians'], feedback: string) {
    prepare(waypoints, {
      ...spawns, [kind]: layout,
      zombieCount: kind === 'zombies' && layout === undefined ? Math.max(zombieTotal, defaultZombiePoints.length) : spawns.zombieCount,
    }, groupSize, feedback);
  }

  function removeSpawn(kind: 'civilians' | 'zombies' | 'soldiers', index: number) {
    if (selection !== kind) return;
    if (kind === 'soldiers') {
      prepare(waypoints, { ...spawns, soldiers: spawns.soldiers?.filter((_, current) => current !== index) }, groupSize,
        'Deployment removed. That soldier will start at extraction.');
      return;
    }
    const points = spawns[kind];
    if (!Array.isArray(points)) return;
    const next = points.filter((_, current) => current !== index);
    changeLayout(kind, next.length ? next : undefined, next.length ? 'Spawn point removed.' : 'Default spawn points restored.');
  }

  function spawnControls(kind: 'civilians' | 'zombies', count: number) {
    const layout = spawns[kind];
    const name = kind === 'civilians' ? 'Civilian spawns' : 'Zombie spawns';
    const selected = selection === kind;
    return (
      <div className="spawn-row">
        <span><i className={kind === 'civilians' ? 'point-dot pickup-dot' : 'point-dot zombie-dot'} />{name}<small>{layout === 'random' ? 'Random' : count}</small></span>
        <div className="spawn-actions">
          <button disabled={!editing} aria-pressed={selected} aria-label={selected ? `Done placing ${kind}` : `Place ${name.toLowerCase()}`}
            onClick={() => select(selected ? null : kind)}>{selected ? 'Done' : 'Place'}</button>
          <button disabled={!editing} aria-pressed={layout === 'random'} aria-label={`Randomize ${name.toLowerCase()}`} onClick={() => {
            select(null);
            changeLayout(kind, layout === 'random' ? undefined : 'random', layout === 'random'
              ? 'Default spawn points restored.'
              : `${kind === 'civilians' ? 'Civilians' : 'Zombies'} will spawn across the district.`);
          }}>Random</button>
          {layout && layout !== 'random' && <button disabled={!editing} aria-label={`Restore default ${name.toLowerCase()}`} onClick={() => {
            select(null);
            changeLayout(kind, undefined, 'Default spawn points restored.');
          }}>Default</button>}
        </div>
      </div>
    );
  }

  const civilianAllocation = splitPopulation(groupSize, civilianPoints.length);
  const zombieAllocation = splitPopulation(zombieTotal, zombiePoints.length);
  const defensePhase = convoy.defense?.phase;
  const defenseStatus = defensePhase === 'departed' ? 'Transport departed' : defensePhase === 'fallback' ? 'Falling back to transport'
    : status === 'ready' ? `${zoneRadius * 2} m extraction zone` : `${patrol} on patrol · ${responding} responding · ${reloading} reloading`;
  const speedControls = <div className="speed-controls" role="group" aria-label="Simulation speed">
    {[1, 2, 4].map(speed => <button key={speed} aria-pressed={playSpeed === speed} onClick={() => setPlaySpeed(speed)}>{speed}×</button>)}
  </div>;
  const coverage = status === 'ready' ? undefined : convoy.defense?.coverage;
  const inspectGaps = (span: Barricade) => barricadeGaps(terrain, span, terrain.mask(closed), barricades);
  const missionActions = (
    <div className="mission-actions">
      <button className="dispatch" disabled={status !== 'ready' || !convoy.canDispatch || !!selection} onClick={dispatch}><Icon name="play" size={21} /> Dispatch group</button>
      <button className="reset" aria-label="Reset scenario" title="Reset scenario" onClick={() => reset()}><Icon name="reset" size={21} /></button>
    </div>
  );

  return (
    <main className="shell">
      <header className="topbar">
        <div className="brand-mark" aria-hidden="true"><Icon name="bridge" size={28} /></div>
        <div className="brand"><h1>RIALTO</h1><span>EVACUATION CONTROL</span></div>
        <div className="top-location"><span /> VENICE, ITALY</div>
      </header>
      <div className="console">
        <aside className="panel" aria-label="Evacuation controls">
          <div className="panel-heading">
            <h2>{mission === 'outbreak' ? 'Rialto outbreak' : 'Evacuation drill'}</h2>
            <p>{waypoints === missions[mission].waypoints ? missions[mission].objective : 'Guide the group between your selected waypoints.'}</p>
            <label className="crowd-size">Mission
              <select value={mission} onChange={event => {
                const next = event.currentTarget.value as Mission;
                reset(next, missions[next].count, false);
              }}><option value="outbreak">Rialto outbreak</option><option value="drill">Evacuation drill</option></select>
            </label>
          </div>
          <section className="panel-section">
            <div className="section-title"><Icon name="route" size={18} /><h3>Spawn plan</h3><output className={route || spawns.civilians === 'random' ? '' : 'blocked'}>{status === 'arrived' ? 'Complete' : routeLength}</output></div>
            <div className="spawn-layouts">
              {spawnControls('civilians', civilianPoints.length)}
              {mission === 'outbreak' && spawnControls('zombies', zombiePoints.length)}
            </div>
            {convoy.defense && <div className="spawn-row squad-row">
              <span><i className="point-dot evacuation-dot" />Deployment<small>{spawns.soldiers?.length ?? 0} / {squadCount} placed</small></span>
              <div className="spawn-actions"><button disabled={!editing} aria-pressed={selection === 'soldiers'}
                onClick={() => select(selection === 'soldiers' ? null : 'soldiers')}>{selection === 'soldiers' ? 'Done' : 'Deploy soldiers'}</button></div>
            </div>}
            <div className="waypoint-actions spawn-evac">
              <button disabled={!editing} aria-pressed={selection === 'end'} onClick={() => select(selection === 'end' ? null : 'end')}><span className="point-dot evacuation-dot" />Set evacuation</button>
            </div>
            {selection && selection !== 'barricade' && <div className="select-help" role="status">{selection === 'end' ? 'Select an evacuation point on the map.'
              : selection === 'soldiers' ? 'Click a street or the extraction zone to deploy. Click an infantry pin to remove it.'
                : 'Click walkable ground to place points. Click a numbered pin to remove it. Choose Done when finished.'}</div>}
          </section>
          {convoy.defense && <section className="panel-section">
            <div className="section-title"><Icon name="people" size={18} /><h3>Defense budget</h3><output>{credits.toLocaleString()} credits</output></div>
            <div className="spawn-row">
              <span>{soldierTypes.infantry.label}<small>{infantryCost} credits each</small></span>
              <div className="spawn-actions">
                <button disabled={!editing || credits < infantryCost || squadCount >= maxSquadSize} onClick={() =>
                  prepare(waypoints, { ...spawns, hired: squadCount + 1 }, groupSize, 'SWAT infantry hired.')}>Hire one</button>
                <button disabled={!editing || credits < infantryCost || squadCount >= maxSquadSize} onClick={() =>
                  prepare(waypoints, { ...spawns, hired: Math.min(maxSquadSize, squadCount + Math.floor(credits / infantryCost)) }, groupSize, 'Hired the largest squad the budget allows.')}>Hire max</button>
                <button disabled={!editing || squadCount <= (spawns.soldiers?.length ?? 0) || squadCount <= 1} onClick={() =>
                  prepare(waypoints, { ...spawns, hired: squadCount - 1 }, groupSize, 'One unassigned soldier released.')}>Release one</button>
              </div>
            </div>
            <div className="spawn-row barricade-purchase">
              <span>Barricade gate<small>45 credits + 5/m</small></span>
              <div className="spawn-actions">
                <button disabled={!editing || (credits < 55 && selection !== 'barricade')} aria-pressed={selection === 'barricade'}
                  onClick={() => select(selection === 'barricade' ? null : 'barricade')}>
                  {selection === 'barricade' ? 'Done drawing' : 'Draw barricade'}
                </button>
                {barricades.length > 0 && <button disabled={!editing} onClick={() =>
                  prepare(waypoints, { ...spawns, barricades: barricades.slice(0, -1) }, groupSize, 'Last barricade removed. Credits refunded.')
                }>Undo barricade</button>}
              </div>
            </div>
            {selection === 'barricade' && <p className="select-help">
              {barricadeStart ? 'Click the other side of the street to buy and place it.' : 'Click one side of a street to start drawing.'}
            </p>}
            <label className="crowd-size">Round length (seconds)
              <input key={roundSeconds} type="number" min={45} max={900} defaultValue={roundSeconds} disabled={!editing}
                onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}
                onBlur={event => {
                  const seconds = Number.parseInt(event.currentTarget.value, 10);
                  const value = Number.isFinite(seconds) ? Math.max(45, Math.min(900, seconds)) : roundSeconds;
                  event.currentTarget.value = String(value);
                  if (value !== roundSeconds) prepare(waypoints, { ...spawns, roundSeconds: value }, groupSize, 'Round length updated.');
                }} />
            </label>
            <label className="crowd-size">Extraction radius (m)
              <input key={zoneRadius} type="number" min={24} max={70} defaultValue={zoneRadius} disabled={!editing}
                onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}
                onBlur={event => {
                  const meters = Number.parseInt(event.currentTarget.value, 10);
                  const value = Number.isFinite(meters) ? Math.max(24, Math.min(70, meters)) : zoneRadius;
                  event.currentTarget.value = String(value);
                  if (value !== zoneRadius) prepare(waypoints, { ...spawns, zoneRadius: value }, groupSize, 'Extraction radius updated.');
                }} />
            </label>
          </section>}
          <section className="panel-section crossings">
            <div className="section-title"><Icon name="bridge" size={18} /><h3>Crossings</h3><output>{data.crossings.length - closed.size} / {data.crossings.length} open</output></div>
            <div className="bridge-list">
              {data.crossings.map(crossing => (
                <button className="bridge-button" key={crossing.id} aria-pressed={closed.has(crossing.id)} onClick={() => toggleCrossing(crossing.id)}>
                  <span><strong>{crossingNames[crossing.id]}</strong><small>{crossing.name}</small></span>
                  <span className={`bridge-state ${closed.has(crossing.id) ? 'blocked' : ''}`}><i />{closed.has(crossing.id) ? 'Closed' : 'Open'}</span>
                </button>
              ))}
            </div>
          </section>
          <section className="panel-section group">
            <div className="section-title"><Icon name="people" size={18} /><h3>Civilian group</h3><output>{status === 'ready' ? `${groupSize.toLocaleString()} people` : `${evacuated.toLocaleString()} / ${groupSize.toLocaleString()} out`}</output></div>
            <label className="crowd-size">Crowd size
              <select value={groupSize} disabled={!editing} onChange={event => resizeCrowd(Number(event.currentTarget.value))}>
                {[missions[mission].count, 1000, 10000, 20000].map(count => <option key={count} value={count} disabled={count < civilianPoints.length}>{count.toLocaleString()}</option>)}
              </select>
            </label>
            {mission === 'outbreak' && <label className="crowd-size">Starting zombies
              <input key={zombieTotal} type="number" min={Math.max(1, zombiePoints.length)} max={20000} step={1}
                defaultValue={zombieTotal} disabled={!editing}
                onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}
                onBlur={event => {
                  const value = Number.parseInt(event.currentTarget.value, 10);
                  const count = Number.isFinite(value) ? Math.min(20000, Math.max(1, zombiePoints.length, value)) : zombieTotal;
                  event.currentTarget.value = String(count);
                  if (count !== zombieTotal) {
                    prepare(waypoints, { ...spawns, zombieCount: count }, groupSize, `${count.toLocaleString()} starting zombies.`);
                    event.currentTarget.value = String(convoyRef.current?.outbreak?.zombies.length ?? zombieTotal);
                  }
                }} />
            </label>}
            {mission === 'outbreak' && <div className="outbreak-stats"><span>{infected.toLocaleString()} infected</span><span>{timer}</span></div>}
            {convoy.defense && <div className="squad-status">
              <span>{convoy.defense.fortifications?.gates.length ?? 0} gates · {breached} breached</span>
              <strong>{overrun && defensePhase !== 'departed' ? 'Pickup overrun' : defenseStatus}</strong>
              {status !== 'ready' && <span>{waiting.toLocaleString()} civilians waiting · {shelterLosses.toLocaleString()} lost at pickup</span>}
              {status === 'ready' ? <span>Squad falls back in the last {convoy.defense.fallbackWindow} seconds.</span>
                : <span>{eliminated} neutralized · {aboard} aboard · {lost} lost</span>}
            </div>}
            <div className="group-status" aria-live="polite"><strong className={status === 'holding' ? 'blocked' : ''}>{groupStatus}</strong><p>{message}</p></div>
            {comparison && <div className="squad-status">
              <strong>Previous run</strong>
              <span>{comparison.evacuated} / {comparison.civilians} civilians out · {comparison.aboard} / {comparison.troops} troops out</span>
              <span>{comparison.creditsSpent.toLocaleString()} credits spent</span>
              {lastResult && <span>This run: {lastResult.evacuated} / {lastResult.civilians} civilians out · {lastResult.aboard} / {lastResult.troops} troops out · {lastResult.creditsSpent.toLocaleString()} credits spent</span>}
            </div>}
            {lastResult && <button className="replay-button" onClick={() => reset(mission, groupSize, true, true)}>Replay same outbreak</button>}
            {speedControls}
            {missionActions}
          </section>
        </aside>
        <MapView
          data={data}
          overview={overview}
          closed={closed}
          selection={selection}
          civilianSpawns={civilianPoints.map((position, index) => ({ position, count: civilianAllocation[index], removable: Array.isArray(spawns.civilians) }))}
          zombieSpawns={zombiePoints.map((position, index) => ({ position, count: zombieAllocation[index], removable: Array.isArray(spawns.zombies) }))}
          end={convoy.defense?.center ?? data.nodes[waypoints.end]}
          deployments={convoy.defense && (status === 'ready' ? spawns.soldiers ?? [] : [])}
          defensePhase={defensePhase}
          zoneRadius={zoneRadius}
          gates={convoy.defense?.fortifications?.gates}
          barricadeStart={barricadeStart}
          barricadeCredits={credits}
          inspectGaps={inspectGaps}
          coverage={coverage}
          onCrossing={toggleCrossing}
          onPlace={place}
          onRemoveSpawn={removeSpawn}
          frame={frame}
          fullscreenControls={(
            <div className="fullscreen-mission">
              <div><strong>{groupStatus}</strong><span>{evacuated} / {groupSize} out</span></div>
              {mission === 'outbreak' && <div className="outbreak-stats"><span>{infected} infected</span><span>{timer}</span></div>}
              {convoy.defense && <div><strong>{defenseStatus}</strong><span>{aboard} / {squadCount} soldiers aboard</span></div>}
              {lastResult && <button className="replay-button" onClick={() => reset(mission, groupSize, true, true)}>Replay same outbreak</button>}
              {speedControls}
              {missionActions}
            </div>
          )}
        />
      </div>
      <footer className="footer">
        <span><i /> <strong>Route</strong> <span className="footer-person"><Icon name="person" size={16} /></span> Civilian {mission === 'outbreak' && <><span className="footer-person infected"><Icon name="person" size={16} /></span> Infected</>} <i className="footer-open" /> Open crossing <i className="footer-closed" /> Closed crossing</span>
        <span>Drag to pan <b>·</b> Scroll to zoom</span>
        <nav className="map-credit-links" aria-label="Map credits">
          <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">© OpenStreetMap contributors</a>
          <a href="https://openfreemap.org/" target="_blank" rel="noreferrer">OpenFreeMap</a>
          <a href="https://openmaptiles.org/" target="_blank" rel="noreferrer">© OpenMapTiles</a>
        </nav>
      </footer>
    </main>
  );
}

createRoot(document.getElementById('root')!).render(<App />);
