import type { ReactNode } from 'react';

const paths: Record<string, ReactNode> = {
  route: <><circle cx="5" cy="5" r="2"/><circle cx="19" cy="19" r="2"/><path d="M7 5h8a3 3 0 0 1 0 6H9a4 4 0 0 0 0 8h8"/></>,
  bridge: <><path d="M3 18h18M5 18V6m14 12V6M3 11h18M5 7q7 9 14 0M9 11v7m6-7v7"/></>,
  crosshair: <><circle cx="12" cy="12" r="7"/><path d="M12 2v5m0 10v5M2 12h5m10 0h5"/></>,
  plus: <path d="M12 5v14M5 12h14"/>,
  minus: <path d="M5 12h14"/>,
  reset: <><path d="M5 9a8 8 0 1 1 0 6M5 3v6h6"/></>,
  play: <path d="m8 5 12 7-12 7z" fill="currentColor" stroke="none"/>,
  people: <><circle cx="9" cy="8" r="3"/><path d="M3 20v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2M16 5a3 3 0 0 1 0 6m2 3a4 4 0 0 1 3 4v2"/></>,
  person: <><circle cx="12" cy="5" r="2.5"/><path d="m7 12 3-3h4l3 3m-5-3v6m0 0-4 5m4-5 4 5"/></>,
  exit: <><path d="M12 4H5v16h7m-2-8h11m-4-4 4 4-4 4"/></>,
  guard: <path d="M12 3 4 6v5c0 4 3 8 8 10 5-2 8-6 8-10V6zM8 12l3 3 5-6"/>,
  transport: <path d="M2 15h20l-4 5H6zM6 15l2-6h8l3 6M10 9V5h4v4M2 22h20"/>,
  arrow: <path d="M4 12h15m-6-6 6 6-6 6"/>,
  close: <path d="m6 6 12 12M18 6 6 18"/>,
  alert: <><path d="M10.5 4.7 3 18a1 1 0 0 0 .9 1.5h16.2A1 1 0 0 0 21 18L13.5 4.7a1.75 1.75 0 0 0-3 0Z"/><path d="M12 9v4m0 3h.01"/></>,
  expand: <path d="M8 4H4v4m12-4h4v4M4 16v4h4m12-4v4h-4"/>,
  collapse: <path d="M4 8h4V4m12 4h-4V4M8 20v-4H4m12 4v-4h4"/>,
};

export function Icon({ name, size = 20 }: { name: string; size?: number }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}
