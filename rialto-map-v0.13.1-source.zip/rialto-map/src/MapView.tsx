import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { Application, Graphics, Particle, ParticleContainer, Rectangle, Sprite, Texture } from 'pixi.js';
import { drawAtlas, limitCamera, type Camera, type Overview } from './cartography.ts';
import {
  atlasFrameCount, civilianAnchor, civilianCell, civilianFrame, civilianFrameOrigin,
  civilianPixelsPerMeter, civilianScale, drawCivilianAtlas, encounterFrame, soldierFrame,
} from './civilians.ts';
import { Icon } from './icons.tsx';
import type { EvacuationGroup } from './convoy.ts';
import type { CrossingId, Point, Venice } from './routing.ts';
import { barricadeCost, gateIntegrity, maxBarricadeLength, minBarricadeLength } from './fortifications.ts';
import type { Barricade, ZoneGate } from './fortifications.ts';
import type { Deployment, Shot } from './defense.ts';

type SpawnMarker = { position: Point; count: number; removable: boolean };

type Props = {
  data: Venice;
  overview: Overview;
  closed: ReadonlySet<CrossingId>;
  selection: 'civilians' | 'zombies' | 'soldiers' | 'barricade' | 'end' | null;
  deployments?: Deployment[];
  zoneRadius: number;
  gates?: readonly ZoneGate[];
  barricadeStart: Point | null;
  barricadeCredits: number;
  inspectGaps: (span: Barricade) => Point[];
  coverage?: { guards: number; responders: number; integrity: number }[];
  defensePhase?: 'defend' | 'fallback' | 'departed';
  civilianSpawns: SpawnMarker[];
  zombieSpawns: SpawnMarker[];
  end: Point;
  onPlace: (point: Point) => void;
  onCrossing: (id: CrossingId) => void;
  onRemoveSpawn: (kind: 'civilians' | 'zombies' | 'soldiers', index: number) => void;
  frame: (seconds: number) => EvacuationGroup;
  fullscreenControls: ReactNode;
};

const project = ([x, y]: Point, camera: Camera): Point => [
  (x - camera.x) * camera.zoom + camera.width / 2,
  (y - camera.y) * camera.zoom + camera.height / 2,
];
const unproject = ([x, y]: Point, camera: Camera): Point => [
  (x - camera.width / 2) / camera.zoom + camera.x,
  (y - camera.height / 2) / camera.zoom + camera.y,
];

function bulletTrace(shot: Shot, elapsed: number, camera: Camera) {
  const progress = Math.min(1, (elapsed - shot.start) / 0.075);
  const tail = Math.max(0, progress - 0.07);
  const [x, y] = project(shot.from, camera);
  const dx = (shot.to[0] - shot.from[0]) * camera.zoom;
  const dy = (shot.to[1] - shot.from[1]) * camera.zoom;
  return { x, y, headX: x + dx * progress, headY: y + dy * progress,
    tailX: x + dx * tail, tailY: y + dy * tail, flash: elapsed - shot.start < 0.032,
    angle: Math.atan2(dy, dx), flashSize: Math.max(1, Math.min(4, camera.zoom * 0.7)) };
}

function BarricadeModel({ gate, camera, index }: { gate: ZoneGate; camera: Camera; index: number }) {
  const [[x, y], [endX, endY]] = gate.span.map(point => project(point, camera));
  const length = Math.hypot(endX - x, endY - y);
  const angle = Math.atan2(endY - y, endX - x) * 180 / Math.PI;
  const depth = Math.max(3.4, camera.zoom * 1.05);
  const opening = Math.min(length * 0.58, Math.max(4, camera.zoom * 2.8));
  const wing = (length - opening) / 2;
  const breached = gate.integrity <= 0;
  const seams = Math.floor(wing / Math.max(5, camera.zoom * 1.6));
  return <g className={`zone-gate ${breached ? 'breached' : ''}`} transform={`translate(${x} ${y}) rotate(${angle})`}>
    <title>Barricade {index + 1} · {Math.ceil(gate.integrity / gateIntegrity * 100)}%</title>
    <path className="blockade-shadow" d={`M0 2 H${length}`} strokeWidth={depth + 2} />
    {[0, wing + opening].map((offset, side) => <g key={side} transform={`translate(${offset} 0)`}>
      <rect className="blockade-concrete" y={-depth / 2} width={wing} height={depth} rx={0.8} />
      <path className="blockade-cap" d={`M0 ${-depth * 0.22} H${wing}`} strokeWidth={depth * 0.26} />
      {Array.from({ length: seams }, (_, panel) => {
        const joint = (panel + 1) * wing / (seams + 1);
        return <line key={panel} className="blockade-seam" x1={joint} x2={joint} y1={-depth / 2} y2={depth / 2} />;
      })}
    </g>)}
    <g transform={`translate(${wing} 0)`}>
      <rect className="blockade-door" y={-depth / 2} width={opening} height={depth} rx={0.6} />
      <path className="blockade-brace" d={`M0 0 H${opening} M0 ${depth * 0.34} L${opening / 2} ${-depth * 0.34} L${opening} ${depth * 0.34}`} />
      {[0, opening].map(post => <rect key={post} className="blockade-post" x={post - depth / 3}
        y={-depth * 0.72} width={depth * 0.66} height={depth * 1.44} rx={0.6} />)}
    </g>
  </g>;
}

function initialView(width: number, height: number): Camera {
  return {
    x: 1200,
    y: 995,
    zoom: Math.max(width / 680, height / 530),
    width,
    height,
  };
}

const runnerScale = civilianScale / civilianPixelsPerMeter;
const densityColors = [0xffbd65, 0xf17d39] as const;

function crowdDensity(group: EvacuationGroup) {
  const tiles = new Map<string, { x: number; y: number; count: number }>();
  for (const person of group.people) {
    if (person.status !== 'moving' && person.status !== 'holding' && person.status !== 'sheltered') continue;
    const key = `${Math.floor(person.x / 8)},${Math.floor(person.y / 8)}`;
    const tile = tiles.get(key);
    if (tile) tile.count++;
    else tiles.set(key, { x: person.x, y: person.y, count: 1 });
  }
  return Array.from(tiles.values()).filter(tile => tile.count >= 4);
}

function forEachRunner(group: EvacuationGroup, camera: Camera, draw: (x: number, y: number, frame: number) => void) {
  const [left, top] = unproject([-20, -20], camera);
  const [right, bottom] = unproject([camera.width + 20, camera.height + 20], camera);
  for (const scene of group.outbreak?.encounters ?? []) {
    const { x, y } = scene.victim;
    if (x < left || x > right || y < top || y > bottom) continue;
    draw(x, y, encounterFrame(scene, group.elapsed));
  }
  for (let index = 0; index < group.people.length; index++) {
    const person = group.people[index];
    if (person.status !== 'moving' && person.status !== 'holding' && person.status !== 'sheltered') continue;
    if (person.x < left || person.x > right || person.y < top || person.y > bottom) continue;
    draw(person.x, person.y, civilianFrame(person, index, group.elapsed));
  }
  const zombies = group.outbreak?.zombies ?? [];
  group.defense?.soldiers.forEach((soldier, index) => {
    if (soldier.state === 'aboard' || soldier.state === 'lost' || soldier.x < left || soldier.x > right || soldier.y < top || soldier.y > bottom) return;
    draw(soldier.x, soldier.y, soldierFrame(soldier, index, group.elapsed));
  });
  for (let index = 0; index < zombies.length; index++) {
    const zombie = zombies[index];
    if (zombie.x < left || zombie.x > right || zombie.y < top || zombie.y > bottom) continue;
    const attack = zombie.attack;
    if (!attack) {
      draw(zombie.x, zombie.y, civilianFrame(zombie, index, group.elapsed, true));
      continue;
    }
    const progress = (group.elapsed - attack.start) / (attack.biteEnd - attack.start);
    const reach = Math.sin(Math.PI * Math.max(0, Math.min(1, progress))) * 0.34;
    draw(zombie.x + (attack.victim.x - zombie.x) * reach, zombie.y + (attack.victim.y - zombie.y) * reach,
      encounterFrame(attack, group.elapsed, true));
  }
}

function drawRoutes(layer: Graphics, trails: Point[][]) {
  layer.clear();
  if (trails.length) {
    for (const [color, width] of [[0x142023, 8], [0xf9c878, 3]]) {
      for (const trail of trails) {
        layer.moveTo(...trail[0]);
        for (const point of trail.slice(1)) layer.lineTo(...point);
      }
      layer.stroke({ color, width, cap: 'round', join: 'round' });
    }
  }
}

function Compass() {
  return <div className="compass" aria-hidden="true"><span>N</span><svg width="31" height="36" viewBox="0 0 32 36"><path d="M16 2 26 29 16 23 6 29Z" fill="#283333" stroke="#b9b9a6"/><path d="M16 2v21L6 29Z" fill="#d9d7bf"/></svg></div>;
}

export function MapView(props: Props) {
  const { data, overview, closed, selection, civilianSpawns, zombieSpawns, end, deployments, defensePhase, zoneRadius, gates, barricadeStart, barricadeCredits, inspectGaps, coverage, onPlace, onCrossing, onRemoveSpawn, fullscreenControls } = props;
  const [showCoverage, setShowCoverage] = useState(false);
  const [barricadeCursor, setBarricadeCursor] = useState<Point | null>(null);
  const [camera, setCamera] = useState(() => initialView(1000, 700));
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(false);
  const [showDensity, setShowDensity] = useState(false);
  const densityEnabled = useRef(false);
  const [screen, setScreen] = useState<'window' | 'native' | 'viewport'>('window');
  const map = useRef<HTMLDivElement>(null);
  const surface = useRef<HTMLDivElement>(null);
  const fallback = useRef<HTMLCanvasElement>(null);
  const view = useRef(camera);
  const latest = useRef(props);
  const drag = useRef<{ origin: Point; x: number; y: number; moved: boolean } | null>(null);

  function update(camera: Camera) {
    const next = limitCamera(camera, overview.bounds);
    view.current = next;
    setCamera(next);
  }

  function zoom(factor: number, point?: Point) {
    const current = view.current;
    const nextZoom = limitCamera({ ...current, zoom: current.zoom * factor }, overview.bounds).zoom;
    const target: Point = point ?? [current.width / 2, current.height / 2];
    const [x, y] = unproject(target, current);
    update({
      ...current,
      zoom: nextZoom,
      x: x - (target[0] - current.width / 2) / nextZoom,
      y: y - (target[1] - current.height / 2) / nextZoom,
    });
  }

  async function toggleFullscreen() {
    const panel = map.current;
    if (!panel) return;
    if (screen === 'viewport') {
      setScreen('window');
    } else if (document.fullscreenElement === panel) {
      await document.exitFullscreen();
    } else {
      try {
        await panel.requestFullscreen();
      } catch {
        setScreen('viewport');
      }
    }
  }

  useEffect(() => {
    function onFullscreenChange() {
      setScreen(mode => document.fullscreenElement === map.current ? 'native' : mode === 'native' ? 'window' : mode);
    }
    document.addEventListener('fullscreenchange', onFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', onFullscreenChange);
  }, []);

  useEffect(() => {
    if (screen !== 'viewport') return;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    function onEscape(event: KeyboardEvent) {
      if (event.key === 'Escape') setScreen('window');
    }
    window.addEventListener('keydown', onEscape);
    return () => {
      document.body.style.overflow = overflow;
      window.removeEventListener('keydown', onEscape);
    };
  }, [screen]);

  function fitRoute() {
    const current = view.current;
    const group = latest.current.frame(0);
    const points = [...group.trails().flat(), end, ...civilianSpawns.map(spawn => spawn.position), ...zombieSpawns.map(spawn => spawn.position)];
    if (!civilianSpawns.length || (group.outbreak && !zombieSpawns.length)) points.push([0, 0], data.size);
    const xs = points.map(point => point[0]);
    const ys = points.map(point => point[1]);
    const left = Math.min(...xs);
    const right = Math.max(...xs);
    const top = Math.min(...ys);
    const bottom = Math.max(...ys);
    update({
      ...current,
      x: (left + right) / 2,
      y: (top + bottom) / 2,
      zoom: Math.min(
        1.75,
        (current.width - 72) / Math.max(1, right - left),
        (current.height - 100) / Math.max(1, bottom - top),
      ),
    });
  }

  function streetView() {
    const group = latest.current.frame(0);
    const runner = group.people.find(person => person.status === 'moving' || person.status === 'holding')
      ?? (civilianSpawns.length ? undefined : group.people[0]);
    const [x, y] = runner ? [runner.x, runner.y] : civilianSpawns[0]?.position ?? end;
    update({ ...view.current, x, y, zoom: 6 });
  }

  useEffect(() => {
    latest.current = props;
  }, [props]);

  useEffect(() => {
    const host = surface.current;
    const panel = map.current;
    if (!host || !panel) return;
    let active = true;
    let started = false;
    let animation = 0;
    let releaseTextures = () => {};
    const atlas = drawAtlas(data, overview);
    const civilianAtlas = drawCivilianAtlas();
    let sampledGroup: EvacuationGroup | undefined;
    let sampledAt = -1;
    let tiles: ReturnType<typeof crowdDensity> = [];
    function drawDensity(group: EvacuationGroup, camera: Camera, draw: (x: number, y: number, radius: number, crowded: boolean) => void) {
      if (!densityEnabled.current) return;
      const sample = Math.floor(group.elapsed * 4);
      if (sampledGroup !== group || sampledAt !== sample) {
        sampledGroup = group;
        sampledAt = sample;
        tiles = crowdDensity(group);
      }
      const radius = Math.max(5, Math.min(18, 4 * camera.zoom));
      for (const tile of tiles) {
        const [x, y] = project([tile.x, tile.y], camera);
        if (x < -radius || y < -radius || x > camera.width + radius || y > camera.height + radius) continue;
        draw(x, y, radius, tile.count >= 12);
      }
    }
    const [left, top, right, bottom] = overview.bounds;
    const chartWidth = right - left;
    const chartHeight = bottom - top;
    const app = new Application();
    const resolution = Math.min(devicePixelRatio || 1, 2.5);
    let detailCamera: Camera | undefined;
    let detailSince = 0;
    let detail: HTMLCanvasElement | undefined;

    function detailedView(camera: Camera, now: number) {
      if (camera !== detailCamera) {
        detailCamera = camera;
        detailSince = now;
        detail = undefined;
      }
      if (!detail && now - detailSince > 140 && camera.zoom * resolution > atlas.width / chartWidth) {
        const dpr = Math.min(resolution, 3800 / Math.max(camera.width, camera.height));
        const [x, y] = project([0, 0], camera);
        detail = drawAtlas(data, overview, {
          width: camera.width * dpr,
          height: camera.height * dpr,
          x: x * dpr,
          y: y * dpr,
          scale: camera.zoom * dpr,
        });
      }
      return detail;
    }

    const observer = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect;
      if (!width || !height) return;
      const current = view.current;
      update(started ? { ...current, width, height } : initialView(width, height));
      if (app.renderer) app.renderer.resize(width, height);
    });
    observer.observe(panel);
    const wheel = (event: WheelEvent) => {
      event.preventDefault();
      const rect = panel.getBoundingClientRect();
      zoom(Math.exp(-event.deltaY * (event.deltaMode === 1 ? 0.06 : 0.0014)), [event.clientX - rect.left, event.clientY - rect.top]);
    };
    panel.addEventListener('wheel', wheel, { passive: false });
    const width = panel.clientWidth;
    const height = panel.clientHeight;
    update(initialView(width, height));

    function useCanvasFallback() {
      const canvas = fallback.current;
      const context = canvas?.getContext('2d');
      if (!canvas || !context) {
        setError(true);
        return;
      }
      canvas.hidden = false;
      let previous = performance.now();
      function draw(time: number) {
        if (!active || !canvas || !context) return;
        const camera = view.current;
        const width = Math.round(camera.width * resolution);
        const height = Math.round(camera.height * resolution);
        if (canvas.width !== width || canvas.height !== height) {
          canvas.width = width;
          canvas.height = height;
        }
        const group = latest.current.frame(Math.min((time - previous) / 1000, 0.25));
        previous = time;
        const [x, y] = project([left, top], camera);
        context.setTransform(resolution, 0, 0, resolution, 0, 0);
        context.fillStyle = '#182123';
        context.fillRect(0, 0, camera.width, camera.height);
        const sharp = detailedView(camera, time);
        if (sharp) context.drawImage(sharp, 0, 0, camera.width, camera.height);
        else context.drawImage(atlas, x, y, chartWidth * camera.zoom, chartHeight * camera.zoom);
        drawDensity(group, camera, (x, y, radius, crowded) => {
          context.beginPath();
          context.arc(x, y, radius, 0, Math.PI * 2);
          context.fillStyle = crowded ? '#f17d397a' : '#ffbd6552';
          context.fill();
        });
        const trails = group.status === 'ready' ? group.trails() : [];
        if (trails.length) {
          context.beginPath();
          for (const trail of trails) {
            context.moveTo(...project(trail[0], camera));
            for (const point of trail.slice(1)) context.lineTo(...project(point, camera));
          }
          context.lineJoin = 'round';
          context.lineCap = 'round';
          context.strokeStyle = '#142023';
          context.lineWidth = 8;
          context.stroke();
          context.strokeStyle = '#f9c878';
          context.lineWidth = 3;
          context.stroke();
        }
        if (group.defense) {
          for (const soldier of group.defense.active) {
            const [sx, sy] = project([soldier.x, soldier.y], camera);
            context.beginPath();
            context.arc(sx, sy, 3.8, 0, Math.PI * 2);
            context.strokeStyle = soldier.reloadUntil ? '#ffc88d' : '#b7e0ba';
            context.lineWidth = 1.2;
            context.stroke();
          }
          context.beginPath();
          for (const shot of group.defense.shots) {
            const trace = bulletTrace(shot, group.elapsed, camera);
            context.beginPath();
            if (trace.flash) {
              context.save();
              context.translate(trace.x, trace.y);
              context.rotate(trace.angle);
              context.fillStyle = '#ffdf9ad9';
              context.beginPath();
              context.moveTo(0, 0);
              context.lineTo(trace.flashSize * 2, -trace.flashSize);
              context.lineTo(trace.flashSize * 3, 0);
              context.lineTo(trace.flashSize * 2, trace.flashSize);
              context.fill();
              context.restore();
              context.beginPath();
            }
            context.moveTo(trace.tailX, trace.tailY);
            context.lineTo(trace.headX, trace.headY);
            context.strokeStyle = '#eacdaa9c';
            context.lineWidth = 0.9;
            context.stroke();
          }
        }
        const spriteSize = civilianCell * runnerScale * camera.zoom;
        const originX = camera.width / 2 - camera.x * camera.zoom - spriteSize * civilianAnchor[0];
        const originY = camera.height / 2 - camera.y * camera.zoom - spriteSize * civilianAnchor[1];
        forEachRunner(group, camera, (x, y, frame) => {
          const [sourceX, sourceY] = civilianFrameOrigin(frame);
          context.drawImage(
            civilianAtlas, sourceX, sourceY, civilianCell, civilianCell,
            originX + x * camera.zoom, originY + y * camera.zoom, spriteSize, spriteSize,
          );
        });
        animation = requestAnimationFrame(draw);
      }
      started = true;
      setReady(true);
      animation = requestAnimationFrame(draw);
    }

    app.init({ width, height, background: 0x182123, resolution, autoDensity: true, antialias: true, preference: 'webgl' }).then(() => {
      if (!active) {
        app.destroy(true, { children: true });
        return;
      }
      const sprite = new Sprite(Texture.from(atlas));
      const sharpSprite = new Sprite();
      let sharpCanvas: HTMLCanvasElement | undefined;
      const layer = new Graphics();
      const densityLayer = new Graphics();
      const shotLayer = new Graphics();
      let densityCamera: Camera | undefined;
      let densitySample = -1;
      let densityGroup: EvacuationGroup | undefined;
      let routeCamera: Camera | undefined;
      let routes: EvacuationGroup['routes'] | undefined;
      const sheet = Texture.from(civilianAtlas);
      const frames = Array.from({ length: atlasFrameCount }, (_, index) => {
        const [x, y] = civilianFrameOrigin(index);
        return new Texture({ source: sheet.source, frame: new Rectangle(x, y, civilianCell, civilianCell) });
      });
      const crowdLayer = new ParticleContainer<Particle>({
        texture: sheet,
        dynamicProperties: { position: true, uvs: true },
      });
      const pool: Particle[] = [];
      const chartTexture = sprite.texture;
      releaseTextures = () => {
        chartTexture.destroy(true);
        if (sharpCanvas) sharpSprite.texture.destroy(true);
        for (const texture of frames) texture.destroy(false);
        sheet.destroy(true);
      };
      app.stage.addChild(sprite, sharpSprite, densityLayer, layer, shotLayer, crowdLayer);
      host.appendChild(app.canvas);
      app.renderer.resize(view.current.width, view.current.height);
      started = true;
      setReady(true);
      app.ticker.add(ticker => {
        const camera = view.current;
        sprite.position.set(...project([left, top], camera));
        sprite.width = chartWidth * camera.zoom;
        sprite.height = chartHeight * camera.zoom;
        const sharp = detailedView(camera, performance.now());
        if (sharpCanvas !== sharp) {
          if (sharpCanvas) sharpSprite.texture.destroy(true);
          sharpSprite.texture = sharp ? Texture.from(sharp) : Texture.EMPTY;
          sharpCanvas = sharp;
        }
        sharpSprite.visible = !!sharp;
        if (sharp) {
          sharpSprite.width = camera.width;
          sharpSprite.height = camera.height;
        }
        const group = latest.current.frame(Math.min(ticker.elapsedMS / 1000, 0.25));
        if (group.defense) {
          shotLayer.clear();
          for (const soldier of group.defense.active) {
            const [sx, sy] = project([soldier.x, soldier.y], camera);
            shotLayer.circle(sx, sy, 3.8).stroke({ color: soldier.reloadUntil ? 0xffc88d : 0xb7e0ba, width: 1.2 });
          }
          for (const shot of group.defense.shots) {
            const trace = bulletTrace(shot, group.elapsed, camera);
            if (trace.flash) {
              const dx = Math.cos(trace.angle) * trace.flashSize;
              const dy = Math.sin(trace.angle) * trace.flashSize;
              shotLayer.poly([trace.x, trace.y, trace.x + 2 * dx - dy, trace.y + 2 * dy + dx,
                trace.x + 3 * dx, trace.y + 3 * dy, trace.x + 2 * dx + dy, trace.y + 2 * dy - dx])
                .fill({ color: 0xffdf9a, alpha: 0.85 });
            }
            shotLayer.moveTo(trace.tailX, trace.tailY).lineTo(trace.headX, trace.headY)
              .stroke({ color: 0xffe7a1, alpha: 0.62, width: 0.9 });
          }

        }
        densityLayer.visible = densityEnabled.current;
        const sample = Math.floor(group.elapsed * 4);
        if (densityLayer.visible && (densityGroup !== group || densityCamera !== camera || densitySample !== sample)) {
          densityCamera = camera;
          densityGroup = group;
          densitySample = sample;
          densityLayer.clear();
          drawDensity(group, camera, (x, y, radius, crowded) => {
            densityLayer.circle(x, y, radius).fill({ color: densityColors[Number(crowded)], alpha: crowded ? 0.48 : 0.32 });
          });
        }
        const nextRoutes = group.status === 'ready' ? group.routes : undefined;
        if (routes !== nextRoutes || (nextRoutes && routeCamera !== camera)) {
          routes = nextRoutes;
          routeCamera = camera;
          drawRoutes(layer, nextRoutes ? group.trails().map(trail => trail.map(point => project(point, camera))) : []);
        }
        crowdLayer.position.set(...project([0, 0], camera));
        crowdLayer.scale.set(camera.zoom);
        const visible = crowdLayer.particleChildren;
        const previousCount = visible.length;
        let count = 0;
        forEachRunner(group, camera, (x, y, frame) => {
          const actor = pool[count] ??= new Particle({
            texture: frames[frame],
            anchorX: civilianAnchor[0], anchorY: civilianAnchor[1],
            scaleX: runnerScale, scaleY: runnerScale,
          });
          actor.x = x;
          actor.y = y;
          actor.texture = frames[frame];
          visible[count++] = actor;
        });
        if (previousCount !== count) {
          visible.length = count;
          crowdLayer.update();
        }
      });
    }).catch(() => {
      if (active) useCanvasFallback();
    });

    return () => {
      active = false;
      observer.disconnect();
      panel.removeEventListener('wheel', wheel);
      cancelAnimationFrame(animation);
      if (app.renderer && started) {
        releaseTextures();
        app.destroy(true, { children: true });
      }
    };
  }, [data, overview]);

  function localPoint(event: React.PointerEvent<HTMLDivElement>): Point {
    const rect = event.currentTarget.getBoundingClientRect();
    return [event.clientX - rect.left, event.clientY - rect.top];
  }

  const labelStyle = (point: Point) => {
    const [x, y] = project(point, camera);
    return { left: x, top: y };
  };

  const placedPins: Point[] = [];
  function spawnPins(kind: 'civilians' | 'zombies', markers: SpawnMarker[]) {
    return markers.map(({ position, count, removable }, index) => {
      const zombie = kind === 'zombies';
      const label = `${zombie ? 'Zombie' : 'Civilian'} spawn ${index + 1}`;
      const canRemove = removable && selection === kind;
      const content = <>
        <span className="waypoint-glyph"><Icon name={canRemove ? 'close' : zombie ? 'alert' : 'crosshair'} size={17} /></span>
        <span>{label} · {count.toLocaleString()}</span>
      </>;
      const className = `waypoint spawn-marker ${zombie ? 'outbreak-origin' : 'pickup'}`;
      const key = position.join(',');
      const [left, top] = project(position, camera);
      let lift = 0;
      while (lift < 90 && top - lift > 60 && placedPins.some(([x, y]) => Math.abs(x - left) < 142 && Math.abs(y - top + lift) < 26)) lift += 30;
      placedPins.push([left, top - lift]);
      const style = { left, top: top - lift, '--spawn-lift': `${lift}px` } as CSSProperties;
      return canRemove
        ? <button key={key} className={`${className} removable`} style={style}
            aria-label={`Remove ${label.toLowerCase()}`} onClick={() => onRemoveSpawn(kind, index)}>{content}</button>
        : <div key={key} className={className} style={style}>{content}</div>;
    });
  }

  const scaleMeters = [500, 250, 100, 50, 25, 10, 5].find(meters => meters * camera.zoom <= 120) ?? 5;
  const fullscreen = screen !== 'window';
  const fullscreenLabel = fullscreen ? 'Exit fullscreen' : 'Fullscreen map';
  const closeView = camera.zoom >= 0.37;

  return (
    <div className={`map ${screen === 'viewport' ? 'map-viewport-expanded' : ''}`} ref={map} aria-label="Interactive street map of Venice">
      <div className="map-surface" ref={surface} />
      <canvas className="map-fallback" ref={fallback} hidden />
      <div className="map-grid" />
      <div
        className={`map-input${selection ? ' selecting' : ''}`}
        tabIndex={0}
        aria-label="Map viewport. Use the arrow keys to pan."
        onKeyDown={event => {
          if (event.target !== event.currentTarget) return;
          const directions: Record<string, Point> = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
          const direction = directions[event.key];
          if (!direction) return;
          event.preventDefault();
          const current = view.current;
          update({ ...current, x: current.x + direction[0] * 64 / current.zoom, y: current.y + direction[1] * 64 / current.zoom });
        }}
        onPointerDown={event => {
          if (event.button !== 0 || (event.target as HTMLElement).closest('button')) return;
          const current = view.current;
          drag.current = { origin: localPoint(event), x: current.x, y: current.y, moved: false };
          event.currentTarget.setPointerCapture(event.pointerId);
        }}
        onPointerMove={event => {
          if (selection === 'barricade' && barricadeStart && !drag.current) {
            const [x, y] = unproject(localPoint(event), view.current);
            setBarricadeCursor([Math.round(x * 10) / 10, Math.round(y * 10) / 10]);
          }
          if (!drag.current) return;
          const [x, y] = localPoint(event);
          const dx = x - drag.current.origin[0];
          const dy = y - drag.current.origin[1];
          if (Math.hypot(dx, dy) > 5) drag.current.moved = true;
          if (!drag.current.moved) return;
          const current = view.current;
          update({ ...current, x: drag.current.x - dx / current.zoom, y: drag.current.y - dy / current.zoom });
        }}
        onPointerUp={event => {
          if (!drag.current) return;
          if (!drag.current.moved && selection) onPlace(unproject(localPoint(event), view.current));
          drag.current = null;
        }}
        onPointerLeave={() => setBarricadeCursor(null)}
        onPointerCancel={() => { drag.current = null; }}
      >
        {ready && overview.labels.map(([name, x, y]) => (
          <span className="district-label surrounding-label" style={labelStyle([x, y])} key={name}>{name}</span>
        ))}
        {ready && closeView && data.labels.districts.map(([name, x, y]) => (
          <span className="district-label" style={labelStyle([x, y])} key={name}>{name}</span>
        ))}
        {ready && closeView && data.labels.landmarks.map(([name, x, y]) => (
          <span className="landmark-label" style={labelStyle([x, y])} key={name}>{name}</span>
        ))}
        {ready && closeView && <span className="canal-label" style={labelStyle([976, 1240])}>Canal Grande</span>}
        {ready && data.crossings.map(crossing => (
          <button
            className={`crossing-marker ${crossing.id} ${closed.has(crossing.id) ? 'closed' : ''}`}
            style={labelStyle(crossing.position)}
            key={crossing.id}
            aria-label={`${closed.has(crossing.id) ? 'Open' : 'Close'} ${crossing.name} on map`}
            title={crossing.name}
            onClick={() => onCrossing(crossing.id)}
          >
            <span className="crossing-glyph"><Icon name={closed.has(crossing.id) ? 'close' : 'bridge'} size={16} /></span>
            {closeView && <span className="crossing-name">{crossing.id}</span>}
          </button>
        ))}
        {ready && spawnPins('civilians', civilianSpawns)}
        {ready && deployments && <div aria-hidden="true" className={`evac-zone ${defensePhase ?? 'defend'}`}
          style={{ ...labelStyle(end), width: zoneRadius * 2 * camera.zoom, height: zoneRadius * 2 * camera.zoom }} />}
        {ready && <svg className="zone-blockades" width={camera.width} height={camera.height} aria-label="Barricades">
          {gates?.map((gate, index) => {
            const [x, y] = project(gate.position, camera);
            const data = coverage?.[index];
            return <g key={index}>
              <BarricadeModel gate={gate} camera={camera} index={index} />
              {showCoverage && <text className="guard-coverage" x={x} y={y - 10} textAnchor="middle">
                {data ? `${data.guards} assigned · ${data.responders} reinforcing · ${data.integrity}%` : 'Guard assignments start at dispatch'}
              </text>}
            </g>;
          })}
          {selection === 'barricade' && barricadeStart && (() => {
            const [x, y] = project(barricadeStart, camera);
            if (!barricadeCursor) return <circle className="barricade-anchor" cx={x} cy={y} r={4} />;
            const [endX, endY] = project(barricadeCursor, camera);
            const meters = Math.hypot(endX - x, endY - y) / camera.zoom;
            const cost = barricadeCost([barricadeStart, barricadeCursor]);
            const valid = meters >= minBarricadeLength && meters <= maxBarricadeLength && cost <= barricadeCredits;
            const gaps = valid ? inspectGaps([barricadeStart, barricadeCursor]) : [];
            return <g className={`barricade-preview ${valid ? '' : 'invalid'}`}>
              <line x1={x} y1={y} x2={endX} y2={endY} />
              <circle className="barricade-anchor" cx={x} cy={y} r={4} />
              {gaps.map(point => {
                const [gapX, gapY] = project(point, camera);
                return <circle key={point.join(',')} className="barricade-gap" cx={gapX} cy={gapY} r={5} />;
              })}
              <text x={(x + endX) / 2} y={(y + endY) / 2 - 9} textAnchor="middle">
                {meters.toFixed(1)} m · {cost} credits{valid && (gaps.length ? ` · ${gaps.length} open ${gaps.length === 1 ? 'end' : 'ends'}` : ' · ends covered')}
              </text>
            </g>;
          })()}
        </svg>}
        {ready && <div className={`waypoint evacuation ${defensePhase ?? ''}`} style={labelStyle(end)}><span className="waypoint-glyph"><Icon name={deployments ? 'transport' : 'exit'} size={18} /></span>
          <span>{defensePhase === 'departed' ? 'Transport departed' : deployments ? 'Extraction transport' : 'Evacuation'}</span></div>}
        {ready && spawnPins('zombies', zombieSpawns)}
        {ready && deployments?.map(({ position }, index) => (
          <button key={index} className="soldier-pin" style={labelStyle(position)} disabled={selection !== 'soldiers'}
            aria-label={`Remove infantry deployment ${index + 1}`} onClick={() => onRemoveSpawn('soldiers', index)}>{index + 1}</button>
        ))}
      </div>
      {!ready && <p className="map-loading">{error ? 'This browser could not render the map.' : 'Loading Venice map…'}</p>}
      <div className="map-title">
        <span className="map-kicker"><i /> SECTOR MAP</span>
        <strong>Venezia, Italia</strong>
      </div>
      <Compass />
      <div className="map-controls" aria-label="Map controls">
        <button title={fullscreenLabel} aria-label={fullscreenLabel} aria-pressed={fullscreen} onClick={toggleFullscreen}><Icon name={fullscreen ? 'collapse' : 'expand'} /></button>
        <button title="Zoom in" aria-label="Zoom in" onClick={() => zoom(1.26)}><Icon name="plus" /></button>
        <button title="Zoom out" aria-label="Zoom out" onClick={() => zoom(1 / 1.26)}><Icon name="minus" /></button>
        <button title="Street view" aria-label="Street view" onClick={streetView}><Icon name="person" size={18} /></button>
        <button title="Fit route in view" aria-label="Fit route in view" onClick={fitRoute}><Icon name="route" size={18} /></button>
        <button title="Crowd density" aria-label="Crowd density" aria-pressed={showDensity} onClick={() => {
          densityEnabled.current = !showDensity;
          setShowDensity(!showDensity);
        }}><Icon name="people" size={18} /></button>
        {!!gates?.length && <button title="Guard coverage" aria-label="Guard coverage" aria-pressed={showCoverage}
          onClick={() => setShowCoverage(value => !value)}><Icon name="guard" size={19} /></button>}
        <button title="Reset map view" aria-label="Reset map view" onClick={() => update(initialView(camera.width, camera.height))}><Icon name="crosshair" /></button>
      </div>
      {fullscreen && fullscreenControls}
      {showDensity && <div className="density-legend"><span /> Crowded <span /> Packed</div>}
      <div className="map-scale"><span style={{ width: scaleMeters * camera.zoom }} />{scaleMeters} m</div>
    </div>
  );
}
