import type { CrowdField } from './crowd-field.ts';

export interface TurnCurve {
  startX: number;
  startY: number;
  offsetX: number;
  offsetY: number;
  length: number;
  traveled: number;
}

export interface RunnerMotion {
  cell: number;
  target: number;
  targetX: number;
  targetY: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  heading: number;
  targetHeading?: number;
  speed: number;
  travel: number;
  curve?: TurnCurve;
}

const fullTurn = 2 * Math.PI;

function wrapAngle(angle: number) {
  return angle > Math.PI ? angle - fullTurn : angle < -Math.PI ? angle + fullTurn : angle;
}

export function aimRunner(runner: RunnerMotion, terrain: CrowdField, target: number, mask: number) {
  runner.target = target;
  runner.targetX = terrain.x(target);
  runner.targetY = terrain.y(target);
  if (runner.curve) runner.curve.length = 0;
  const dx = runner.targetX - runner.x;
  const dy = runner.targetY - runner.y;
  const length = Math.sqrt(dx * dx + dy * dy);
  if (!length) return;
  runner.targetHeading = Math.atan2(dy, dx);
  const hasDirection = runner.vx !== 0 || runner.vy !== 0;
  if (!hasDirection) runner.heading = runner.targetHeading;
  const alignment = (dx * runner.vx + dy * runner.vy) / length;
  // Keep reversals, wall edges, and gate returns on their original straight steps.
  if (alignment >= -0.001 && alignment < 0.995 && hasDirection
    && runner.x === terrain.x(runner.cell) && runner.y === terrain.y(runner.cell)
    && terrain.hasTurnSpace(runner.cell, target, mask)) {
    const offsetX = (runner.vx * length - dx) / 3;
    const offsetY = (runner.vy * length - dy) / 3;
    const curve = runner.curve ??= { startX: 0, startY: 0, offsetX: 0, offsetY: 0, length: 0, traveled: 0 };
    curve.startX = runner.x;
    curve.startY = runner.y;
    curve.offsetX = offsetX;
    curve.offsetY = offsetY;
    curve.length = length * (1 + (1 - alignment) * 0.09);
    curve.traveled = 0;
  }
  runner.vx = dx / length;
  runner.vy = dy / length;
}

export function runnerTargetOpen(runner: RunnerMotion, terrain: CrowdField, mask: number) {
  if (!terrain.open(runner.target, mask)) return false;
  if (!terrain.open(runner.cell, mask)) return true;
  return runner.curve?.length
    ? terrain.hasTurnSpace(runner.cell, runner.target, mask)
    : terrain.touches(runner.cell, runner.target, mask);
}

export function moveRunner(runner: RunnerMotion, budget: number, turnRate: number) {
  const curve = runner.curve;
  const curved = curve && curve.length > 0;
  const dx = runner.targetX - runner.x;
  const dy = runner.targetY - runner.y;
  const distance = curved ? curve.length - curve.traveled : Math.sqrt(dx * dx + dy * dy);
  const movement = Math.min(distance, budget);
  if (movement <= 0) return 0;

  let nextX = runner.targetX;
  let nextY = runner.targetY;
  if (curved) {
    curve.traveled += movement;
    if (movement < distance) {
      const t = curve.traveled / curve.length;
      const bend = 3 * t * (1 - t) ** 2;
      nextX = curve.startX + (runner.targetX - curve.startX) * t + bend * curve.offsetX;
      nextY = curve.startY + (runner.targetY - curve.startY) * t + bend * curve.offsetY;
    } else {
      curve.length = 0;
    }
  } else if (movement < distance) {
    nextX = runner.x + dx * movement / distance;
    nextY = runner.y + dy * movement / distance;
  }

  const movedX = nextX - runner.x;
  const movedY = nextY - runner.y;
  const desired = curved ? Math.atan2(movedY, movedX) : runner.targetHeading ?? runner.heading;
  const angle = wrapAngle(desired - runner.heading);
  const seconds = movement / runner.speed;
  const eased = angle * seconds / (0.15 + seconds);
  const limit = seconds * turnRate;
  runner.heading = wrapAngle(runner.heading + Math.max(-limit, Math.min(limit, eased)));
  runner.x = nextX;
  runner.y = nextY;
  runner.travel += curved ? Math.sqrt(movedX * movedX + movedY * movedY) : movement;
  return movement;
}
