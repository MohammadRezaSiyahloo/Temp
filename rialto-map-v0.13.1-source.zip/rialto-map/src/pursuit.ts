import { cellSize, steps, type CrowdField } from './crowd-field.ts';
import { Queue } from './routing.ts';

export interface RoutePlan {
  cells: number[];
  next: number;
  expires: number;
}

export function clearSight(terrain: CrowdField, start: number, end: number, mask: number) {
  if (!terrain.open(start, mask) || !terrain.open(end, mask)) return false;
  let x = start % terrain.columns;
  let y = Math.floor(start / terrain.columns);
  const tx = end % terrain.columns;
  const ty = Math.floor(end / terrain.columns);
  const dx = Math.abs(tx - x);
  const dy = -Math.abs(ty - y);
  const sx = Math.sign(tx - x);
  const sy = Math.sign(ty - y);
  let error = dx + dy;
  let cell = start;
  while (cell !== end) {
    const doubled = 2 * error;
    let stepX = 0;
    let stepY = 0;
    if (doubled >= dy) { error += dy; stepX = sx; }
    if (doubled <= dx) { error += dx; stepY = sy; }
    const direction = stepY < 0 ? stepX + 1 : stepY > 0 ? stepX + 6 : stepX < 0 ? 3 : 4;
    if (!terrain.canStep(cell, direction, mask)) return false;
    x += stepX;
    y += stepY;
    cell = y * terrain.columns + x;
  }
  return true;
}

export function forecast(terrain: CrowdField, cell: number, flow: Uint16Array, mask: number, count: number, vx: number, vy: number) {
  const path: number[] = [];
  for (let step = 0; step < count && flow[cell] > 1; step++) {
    let best = -Infinity;
    let next = -1;
    let nextX = 0;
    let nextY = 0;
    for (let direction = 0; direction < steps.length; direction++) {
      const [dx, dy] = steps[direction];
      const candidate = cell + dy * terrain.columns + dx;
      if (!flow[candidate] || flow[candidate] >= flow[cell] || !terrain.canStep(cell, direction, mask)) continue;
      const length = dx && dy ? Math.SQRT1_2 : 1;
      const score = (dx * vx + dy * vy) * length - (1 - length) * 0.3;
      if (score <= best) continue;
      best = score;
      next = candidate;
      nextX = dx * length;
      nextY = dy * length;
    }
    if (next < 0) break;
    path.push(next);
    cell = next;
    vx = nextX;
    vy = nextY;
  }
  return path;
}

interface SearchOptions {
  budget: number;
  limit: number;
  penalty: (cell: number) => number;
  priority?: (cell: number) => number;
  visit: (cell: number, cost: number) => boolean;
  destination: () => number;
}

function search(terrain: CrowdField, start: number, mask: number, options: SearchOptions) {
  const queue = new Queue();
  const costs = new Map([[start, 0]]);
  const parents = new Map<number, number>();
  const priority = options.priority ?? (() => 0);
  queue.push([start, priority(start)]);
  let visited = 0;
  while (queue.entries.length && visited < options.budget) {
    const [cell, estimate] = queue.pop();
    const cost = costs.get(cell)!;
    if (estimate > cost + priority(cell)) continue;
    visited++;
    if (options.visit(cell, cost)) break;
    for (let direction = 0; direction < steps.length; direction++) {
      const [dx, dy] = steps[direction];
      const next = cell + dy * terrain.columns + dx;
      if (!terrain.canStep(cell, direction, mask)) continue;
      const nextCost = cost + (dx && dy ? Math.SQRT2 : 1) + options.penalty(next);
      if (nextCost > options.limit || nextCost >= (costs.get(next) ?? Infinity)) continue;
      costs.set(next, nextCost);
      parents.set(next, cell);
      queue.push([next, nextCost + priority(next)]);
    }
  }
  const end = options.destination();
  if (!parents.has(end)) return [];
  const path = [];
  for (let cell = end; cell !== start; cell = parents.get(cell)!) path.push(cell);
  return path.reverse();
}

const riskRange = 14;
const bufferRange = 23;
export function dangerDistance(danger: Uint16Array, cell: number) {
  return Math.min(bufferRange, danger[cell] || bufferRange);
}

export function saferPath(terrain: CrowdField, start: number, mask: number, flow: Uint16Array, danger: Uint16Array, vx = 0, vy = 0) {
  const initial = dangerDistance(danger, start);
  const original = flow[start];
  if (original <= 1 || initial >= bufferRange) return [];
  const penalty = (cell: number) => {
    if (!flow[cell]) return Infinity;
    if (flow[cell] === 1) return 0;
    const space = dangerDistance(danger, cell);
    if (space <= 4 && space <= initial) return Infinity;
    return Math.max(0, riskRange - space) * 0.62;
  };

  // Look for a safe point beyond the threat, where the runner can rejoin the exit route.
  const ahead = forecast(terrain, start, flow, mask, 33, vx, vy);
  const checkpoint = ahead.find((cell, index) => index >= 13 && (dangerDistance(danger, cell) >= riskRange || flow[cell] === 1));
  if (checkpoint !== undefined) {
    const x = terrain.x(checkpoint);
    const y = terrain.y(checkpoint);
    let found = false;
    const route = search(terrain, start, mask, {
      budget: 1600,
      limit: 75,
      penalty,
      priority: cell => Math.hypot(terrain.x(cell) - x, terrain.y(cell) - y) / cellSize * 1.25,
      visit: cell => (found = cell === checkpoint),
      destination: () => found ? checkpoint : start,
    });
    if (route.length) return route;
  }

  let best = 0;
  let destination = start;
  return search(terrain, start, mask, {
    budget: 360,
    limit: 34,
    penalty,
    visit: (cell, cost) => {
      if (cell === start) return false;
      const space = dangerDistance(danger, cell);
      const gain = space - initial;
      const progress = original - flow[cell];
      const value = progress * 0.92 + gain * (initial < riskRange ? 2.15 : 0.45)
        + Math.min(0, space - riskRange) * 1.65 - cost * 0.63;
      if (value > best && (progress > 3 || gain > 3)) {
        destination = cell;
        best = value;
      }
      return progress >= 14 && space >= riskRange && destination === cell;
    },
    destination: () => destination,
  });
}

export function cutoffPath(
  terrain: CrowdField, mask: number, flow: Uint16Array, hunter: number, prey: number, vx: number, vy: number,
  preySpeed: number, hunterSpeed: number, flank: number,
) {
  const prediction = forecast(terrain, prey, flow, mask, Math.max(12, Math.min(24, Math.round(preySpeed * 3 / cellSize))), vx, vy);
  const lead = prediction.at(-1);
  if (lead === undefined || prediction.length < 9 || flow[lead] <= 1) return [];
  const px = terrain.x(prey);
  const py = terrain.y(prey);
  const lateral = (cell: number) => (terrain.y(cell) - py) * vx - (terrain.x(cell) - px) * vy;
  const distance = (a: number, b: number) => Math.hypot(terrain.x(a) - terrain.x(b), terrain.y(a) - terrain.y(b));
  const headingSide = Math.sign(lateral(hunter)) || flank;
  const side = headingSide === flank || Math.abs(lateral(hunter)) > 2 ? headingSide : flank;
  const reach = Math.min(22, hunterSpeed * (prediction.length * cellSize * 1.12 / preySpeed + 0.75));
  if (distance(hunter, lead) > reach || distance(hunter, prey) < 2.6 || distance(prey, lead) < 4) return [];

  const goal = terrain.nearest([terrain.x(lead) - vy * side * 0.95, terrain.y(lead) + vx * side * 0.95], mask, flow, 1.6);
  if (goal < 0 || flow[goal] <= 1) return [];
  let reached = false;
  const path = search(terrain, hunter, mask, {
    budget: 400,
    limit: reach / cellSize + 4,
    priority: cell => distance(cell, goal) / cellSize,
    penalty: cell => {
      if (flow[cell] <= 1 || distance(cell, prey) < 2.2) return Infinity;
      return lateral(cell) * side < 0.65 && distance(cell, lead) > 2.4 ? 0.55 : 0;
    },
    visit: cell => (reached = cell === goal),
    destination: () => reached ? goal : hunter,
  });
  const length = path.reduce((meters, cell, index) => meters + distance(cell, index ? path[index - 1] : hunter), 0);
  return length <= reach && path.some(cell => lateral(cell) * side >= 1.8) ? path : [];
}

export function takeStep(terrain: CrowdField, mask: number, cell: number, plan: RoutePlan) {
  const next = plan.cells[plan.next];
  if (next === undefined || next === cell || !terrain.touches(cell, next, mask)) return -1;
  plan.next++;
  return next;
}

export function localPath(terrain: CrowdField, start: number, goal: number, mask: number, allowed: (cell: number) => boolean) {
  if (start === goal || !allowed(goal)) return [];
  const x = terrain.x(goal);
  const y = terrain.y(goal);
  let found = false;
  return search(terrain, start, mask, {
    budget: 4200,
    limit: 110,
    priority: cell => Math.hypot(terrain.x(cell) - x, terrain.y(cell) - y) / cellSize,
    penalty: cell => allowed(cell) ? 0 : Infinity,
    visit: cell => (found = cell === goal),
    destination: () => found ? goal : start,
  });
}
