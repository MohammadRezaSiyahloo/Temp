import type { Barricade } from './fortifications.ts';
import { cellSize, steps, type CrowdField } from './crowd-field.ts';
import { civilianProfiles } from './civilian-profiles.ts';
import { Outbreak, type OutbreakRules } from './outbreak.ts';
import type { CrossingId, Point, Route, StreetGraph } from './routing.ts';
import { random, scatterCells, spawnNear, splitPopulation, type SpawnLayout } from './spawn-planning.ts';
import type { RoutePlan } from './pursuit.ts';
import { aimRunner, moveRunner, runnerTargetOpen, type TurnCurve } from './runner-motion.ts';
import { Defense, type Deployment } from './defense.ts';

export type ConvoyStatus = 'ready' | 'moving' | 'holding' | 'arrived' | 'finished';

export interface Civilian {
  x: number;
  y: number;
  heading: number;
  targetHeading?: number;
  travel: number;
  status: Exclude<ConvoyStatus, 'finished'> | 'caught' | 'infected' | 'sheltered' | 'lost';
  cell: number;
  target: number;
  targetX: number;
  targetY: number;
  vx: number;
  vy: number;
  pace: number;
  profile: number;
  speed: number;
  release: number;
  pauseUntil: number;
  nextPause: number;
  random: number;
  stepsTaken: number;
  escape?: RoutePlan;
  checkEscapeAt?: number;
  resumeAt?: number;
  panicUntil?: number;
  glanceAt?: number;
  curve?: TurnCurve;
}

export interface SpawnPlan {
  barricades?: Barricade[];
  soldiers?: Deployment[];
  hired?: number;
  roundSeconds?: number;
  zoneRadius?: number;
  civilians?: SpawnLayout;
  zombies?: SpawnLayout;
  zombieCount?: number;
}

export class EvacuationGroup {
  readonly people: Civilian[];
  readonly initialPopulation: number;
  elapsed = 0;
  evacuated = 0;
  waiting = 0;
  shelterLosses = 0;
  stranded = 0;
  status: ConvoyStatus = 'ready';
  routes: Route[];
  readonly outbreak?: Outbreak;
  readonly defense?: Defense;
  private readonly terrain: CrowdField;
  private readonly graph: StreetGraph;
  private readonly starts: number[];
  private readonly end: number;
  private readonly goal: number;
  private readonly baseSpeed: number;
  private readonly baseline: Uint16Array;
  private flow: Uint16Array;
  private alternate?: Uint16Array;
  private alternateMask = 0;
  private mask: number;
  private readonly occupancy: Uint16Array | Map<number, number>;

  constructor(terrain: CrowdField, graph: StreetGraph, start: number, end: number, closed: ReadonlySet<CrossingId>, count: number, speed: number, seed = Math.floor(Math.random() * 0x100000000), outbreak?: OutbreakRules, spawns?: SpawnPlan) {
    this.terrain = terrain;
    this.occupancy = count >= 2048 ? new Uint16Array(terrain.cells.length) : new Map();
    this.graph = graph;
    this.starts = Array.isArray(spawns?.civilians)
      ? spawns.civilians.flatMap(point => {
        const node = graph.nearest(point);
        return node === undefined ? [] : [node];
      })
      : spawns?.civilians === 'random' ? [] : [start];
    this.end = end;
    this.baseSpeed = speed;
    this.goal = terrain.nearest(graph.nodes[end]);
    this.baseline = terrain.openFlow(this.goal);
    this.mask = terrain.mask(closed);
    this.flow = this.evacuationFlow();
    this.people = this.spawn(count, seed, graph.nodes[start], spawns?.civilians);
    this.routes = this.planRoutes(closed);
    if (outbreak) {
      this.outbreak = new Outbreak(terrain, outbreak, this.baseline, spawns?.zombies, spawns?.zombieCount, this.mask, seed);
      if (spawns?.soldiers) {
        this.defense = new Defense(terrain, this.goal, outbreak.duration, spawns.soldiers, spawns.hired, spawns.zoneRadius, seed, spawns.barricades);
        this.defense.preparePerimeter(this.baseline);
      }
    }
    this.initialPopulation = this.people.length + (this.outbreak?.zombies.length ?? 0);
  }

  private spawn(count: number, runSeed: number, start: Point, layout?: SpawnLayout): Civilian[] {
    let cells: number[];
    if (layout === 'random') {
      cells = scatterCells(this.terrain, this.baseline, this.mask, count, runSeed);
    } else if (layout) {
      const allocation = splitPopulation(count, layout.length);
      const used = new Set<number>();
      const nearby = new Uint16Array(this.terrain.cells.length);
      cells = layout.flatMap((point, index) => {
        const size = allocation[index];
        const radius = size <= 12 ? 23 : Math.min(295, 27 + Math.sqrt(size) * 1.55);
        return spawnNear(this.terrain, this.baseline, this.mask, point, size, radius, runSeed + index, used, nearby);
      });
    } else {
      cells = this.defaultSpawnCells(start, count, runSeed);
    }
    const profiles = civilianProfiles.flatMap((profile, index) => Array<number>(profile.spawnWeight).fill(index));
    for (let index = profiles.length - 1; index > 0; index--) {
      const pick = Math.floor(random(runSeed ^ Math.imul(index, 0x27d4eb2d)) * (index + 1));
      [profiles[index], profiles[pick]] = [profiles[pick], profiles[index]];
    }
    return cells.map((cell, index) => {
      const seed = Math.imul(index + 1, 0x9e3779b1) ^ runSeed;
      const x = this.terrain.x(cell);
      const y = this.terrain.y(cell);
      const heading = random(seed + 1) * Math.PI * 2;
      const profile = profiles[index % profiles.length];
      const pace = (0.6 + (random(seed ^ 0x42872e13) + random(seed ^ 0x16f371bb)) * 0.41) * civilianProfiles[profile].pace;
      this.occupy(cell, 1);
      return {
        x, y, heading, travel: 0, status: 'ready', cell, target: -1, targetX: x, targetY: y,
        vx: 0, vy: 0, pace, profile, speed: speedAtRest,
        release: index ? random(seed + 3) * 2.15 : 0,
        pauseUntil: 0, nextPause: 5 + random(seed + 4) * 19,
        random: seed, stepsTaken: 0,
      };
    });
  }

  private defaultSpawnCells([x, y]: Point, count: number, runSeed: number) {
    const origin = this.terrain.nearest([x, y], 0, this.baseline, 32);
    if (origin < 0) return [];
    const candidates = [origin];
    const radius = count <= 12 ? 23 : Math.min(295, 27 + Math.sqrt(count) * 1.55);
    this.terrain.visitArea(x, y, radius, (cell, distance) => {
      if (cell === origin || this.baseline[cell] < 2) return;
      if (count <= 12 && (distance < 9 || Math.abs(this.baseline[cell] - this.baseline[origin]) > 85)) return;
      candidates.push(cell);
    });
    return Array.from({ length: count }, (_, index) => {
      const seed = Math.imul(index + 1, 0x9e3779b1) ^ runSeed;
      const slot = index % candidates.length;
      const pick = slot + Math.floor(random(seed) * (candidates.length - slot));
      [candidates[slot], candidates[pick]] = [candidates[pick], candidates[slot]];
      return candidates[slot];
    });
  }

  private occupy(cell: number, amount: number) {
    if (this.occupancy instanceof Uint16Array) {
      this.occupancy[cell] += amount;
      return;
    }
    const count = (this.occupancy.get(cell) ?? 0) + amount;
    if (count) this.occupancy.set(cell, count);
    else this.occupancy.delete(cell);
  }

  private load(cell: number) {
    return this.occupancy instanceof Uint16Array ? this.occupancy[cell] : (this.occupancy.get(cell) ?? 0);
  }

  private planRoutes(closed: ReadonlySet<CrossingId>) {
    return this.people.length ? this.starts.flatMap(start => this.graph.route(start, this.end, closed) ?? []) : [];
  }

  get route() { return this.routes[0] ?? null; }

  get canDispatch() {
    return this.people.length > 0 && (this.routes.length > 0 || this.outbreak !== undefined
      || this.people.some(person => this.flow[person.cell] > 0));
  }

  trails(): Point[][] {
    return this.routes.map(route => route.nodes.map(node => this.graph.nodes[node]));
  }

  dispatch() {
    if (this.status === 'ready' && this.canDispatch) {
      this.defense?.start(this.mask, this.flow, this.baseline);
      this.status = 'moving';
    }
  }

  private evacuationFlow() {
    if (!this.mask) return this.baseline;
    if (!this.alternate || this.alternateMask !== this.mask) {
      this.alternate = this.terrain.flow(this.goal, this.mask, this.alternate);
      this.alternateMask = this.mask;
    }
    return this.alternate;
  }

  replan(closed: ReadonlySet<CrossingId>) {
    this.mask = this.terrain.mask(closed);
    this.flow = this.evacuationFlow();
    this.routes = this.planRoutes(closed);
    this.outbreak?.gatesChanged(this.mask);
    this.defense?.replan(this.mask, this.flow);
    if (this.status === 'ready' || this.status === 'arrived' || this.status === 'finished') return;
    this.stranded = 0;
    let continuing = false;
    for (const person of this.people) {
      if (person.status === 'arrived' || person.status === 'infected' || person.status === 'caught' || person.status === 'sheltered' || person.status === 'lost') continue;
      person.escape = undefined;
      person.checkEscapeAt = undefined;
      person.resumeAt = undefined;
      const actual = this.terrain.cell(person.x, person.y);
      if (!this.flow[actual]) this.stranded++;
      if (person.target >= 0 && person.target !== person.cell
        && this.terrain.open(actual, this.mask) && !runnerTargetOpen(person, this.terrain, this.mask)) {
        this.occupy(person.target, -1);
        aimRunner(person, this.terrain, person.cell, this.mask);
      }
      if (person.status === 'holding') person.status = 'moving';
      continuing = true;
    }
    if (continuing) this.status = 'moving';
  }

  private chooseTarget(person: Civilian) {
    const { cell } = person;
    // A runner already inside a closing gate may finish that crossing.
    const mask = this.terrain.open(cell, this.mask) ? this.mask : 0;
    const flow = mask && this.flow[cell] ? this.flow : this.baseline;
    const distance = flow[cell];
    if (distance <= 1) return -1;
    const planned = this.outbreak?.escapeStep(person, this.elapsed, mask, flow) ?? -1;
    if (planned >= 0) return planned;
    const separation = this.outbreak?.separation(cell) ?? 23;
    const threatened = separation < 23;
    const preference = Math.floor(random(person.random) * steps.length);
    const [biasX, biasY] = steps[preference];
    const maySidestep = this.load(cell) > 1 && this.flow[cell] > 0;
    const forwardX = person.vx * 0.5 + Math.cos(person.heading) * 0.5;
    const forwardY = person.vy * 0.5 + Math.sin(person.heading) * 0.5;
    let best = -Infinity;
    let target = -1;
    for (let direction = 0; direction < steps.length; direction++) {
      const [dx, dy] = steps[direction];
      const next = cell + dy * this.terrain.columns + dx;
      const progress = distance - flow[next];
      const space = threatened ? this.outbreak!.separation(next) : 23;
      const escape = threatened ? space - separation : 0;
      if (!flow[next] || (progress < 0 && escape <= 0) || (!progress && !maySidestep && escape <= 0)
        || (space <= 4 && escape < 0)
        || !this.terrain.canStep(cell, direction, mask)) continue;
      const diagonal = dx && dy ? Math.SQRT1_2 : 1;
      const ahead = (dx * forwardX + dy * forwardY) * diagonal;
      const drift = (dx * biasX + dy * biasY) * diagonal;
      const occupied = Math.min(5, this.load(next));
      // Keep the exit draining when a queue has nowhere else to go.
      const crowdCost = flow[next] === 1 ? 0 : occupied * 1.22 + Math.max(0, occupied - 1) * 1.1;
      const jitter = random(person.random + next) * 0.16;
      const score = progress * 1.42 + ahead * 1.7 + drift * 0.28 - crowdCost + jitter
        + escape * (separation <= 13 ? 2.4 : 0.9) - Math.max(0, 10 - space) * 0.45;
      if (score <= best) continue;
      best = score;
      target = next;
    }
    return target;
  }

  private advance(person: Civilian, seconds: number) {
    const panic = (person.panicUntil ?? 0) > this.elapsed;
    if (panic) person.pauseUntil = 0;
    if (person.pauseUntil > this.elapsed) return;
    const density = Math.max(1, this.load(person.cell), person.target < 0 ? 0 : this.load(person.target));
    const space = 1 / (1 + Math.min(7, density - 1) * 0.19);
    const targetSpeed = this.baseSpeed * person.pace * this.terrain.paceFactor(person.cell) * space;
    person.speed = Math.max(person.speed - seconds * 5, Math.min(targetSpeed, person.speed + seconds * 3.4));
    let remaining = seconds * person.speed;
    while (remaining > 0.0001) {
      if (person.target < 0) {
        if (this.flow[person.cell] === 1) {
          if (this.defense) {
            person.status = this.defense.overrun ? 'lost' : 'sheltered';
            if (person.status === 'lost') {
              this.occupy(person.cell, -1);
              this.shelterLosses++;
            } else this.waiting++;
            person.speed = 0;
          } else {
            this.occupy(person.cell, -1);
            person.status = 'arrived';
            this.evacuated++;
          }
          return;
        }
        if (!panic && this.elapsed >= person.nextPause && this.flow[person.cell]) {
          const hesitation = random(person.random + person.stepsTaken);
          person.pauseUntil = this.elapsed + 0.15 + hesitation * 0.28;
          person.nextPause = this.elapsed + 9 + hesitation * 18;
          person.speed *= 0.45;
          return;
        }
        const target = this.chooseTarget(person);
        if (target < 0) {
          person.status = 'holding';
          person.speed = speedAtRest;
          person.resumeAt = this.elapsed + 0.45;
          return;
        }
        const load = this.load(target);
        if (!panic && load >= 4 && this.flow[target] > 1 && load > this.load(person.cell)) {
          person.pauseUntil = this.elapsed + 0.12 + random(person.random + person.stepsTaken) * 0.12;
          person.speed *= 0.55;
          return;
        }
        aimRunner(person, this.terrain, target, this.mask);
        this.occupy(target, 1);
      }
      remaining -= moveRunner(person, remaining, 11);
      if (person.x !== person.targetX || person.y !== person.targetY) return;
      if (person.cell !== person.target) this.occupy(person.cell, -1);
      person.cell = person.target;
      person.target = -1;
      person.stepsTaken++;
    }
  }

  tick(seconds: number) {
    if (seconds <= 0 || this.status === 'ready' || this.status === 'arrived' || this.status === 'finished') return;
    if (!this.outbreak) {
      this.step(seconds);
      return;
    }
    if (this.elapsed >= this.outbreak.duration - 0.0001) {
      this.depart();
      this.elapsed += seconds;
      this.outbreak.advanceEncounters(this.elapsed);
      if (!this.outbreak.encounters.size) this.status = 'finished';
      return;
    }
    // Keep pursuit and collision sampling consistent when a browser frame runs long.
    let remaining = Math.min(seconds, this.outbreak.duration - this.elapsed);
    while (remaining > 0.0001) {
      const dt = Math.min(remaining, 0.055);
      this.step(dt);
      if ((this.status as ConvoyStatus) === 'finished') return;
      remaining -= dt;
    }
    if (this.elapsed >= this.outbreak.duration - 0.0001) {
      this.depart();
      if (!this.outbreak.encounters.size) this.status = 'finished';
    }
  }

  private depart() {
    if (!this.defense || this.defense.phase === 'departed') return;
    this.defense.depart();
    for (const person of this.people) {
      if (person.status !== 'sheltered') continue;
      this.occupy(person.cell, -1);
      person.status = 'arrived';
      this.evacuated++;
      this.waiting--;
    }
  }

  private step(seconds: number) {
    this.elapsed += seconds;
    if (!this.outbreak && this.status === 'holding') return;
    const defenders = this.defense?.active.map(soldier => [soldier.x, soldier.y] as Point);
    this.outbreak?.sense(this.people, this.elapsed, this.mask, this.flow, defenders);
    let moving = false;
    for (const person of this.people) {
      if (person.status === 'ready') {
        const time = this.elapsed - person.release;
        if (time > 0) person.status = 'moving';
        else moving = true;
      }
      if (person.status === 'holding' && ((person.panicUntil ?? 0) > this.elapsed
        || (this.outbreak && this.flow[person.cell] > 1 && this.elapsed >= (person.resumeAt ?? 0)))) person.status = 'moving';
      if (person.status !== 'moving') continue;
      this.advance(person, Math.min(seconds, this.elapsed - person.release));
      moving ||= person.status === 'moving';
    }
    this.outbreak?.tick(this.people, this.elapsed, seconds, this.mask, this.baseline, this.flow, person => {
      if (person.target >= 0 && person.target !== person.cell) this.occupy(person.target, -1);
      this.occupy(person.cell, -1);
      if (person.status === 'sheltered') this.waiting--;
      person.status = 'caught';
    }, this.defense?.fortifications);
    if (this.defense && this.outbreak) {
      const wasOverrun = this.defense.overrun;
      this.defense.tick(this.elapsed, seconds, this.mask, this.outbreak);
      if (!wasOverrun && this.defense.overrun) {
        for (const person of this.people) {
          if (person.status !== 'sheltered') continue;
          this.occupy(person.cell, -1);
          person.status = 'lost';
          this.waiting--;
          this.shelterLosses++;
        }
      }
    }
    if (!this.defense && this.outbreak && !this.outbreak.encounters.size && this.evacuated + this.outbreak.infected === this.people.length) this.status = 'finished';
    else if (!this.defense && this.evacuated === this.people.length) this.status = 'arrived';
    else if (this.defense) this.status = 'moving';
    else if (!moving && !this.outbreak?.encounters.size) this.status = 'holding';
    else this.status = 'moving';
  }
}

const speedAtRest = 0.45;
