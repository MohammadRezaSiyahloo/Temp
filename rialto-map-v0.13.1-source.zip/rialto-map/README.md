# Rialto

A browser outbreak and evacuation prototype set in Venice. Guide civilians out of Rialto as infected runners spread through the district.

## Play

Open `play.html` from the source archive in a browser. The map and fonts are bundled in the file.

**Rialto outbreak** starts with 24 civilians and three infected near the market. Dispatch the civilians to start the extraction clock. The infected immediately pursue nearby civilians on reachable ground at up to 4.75 m/s on flat streets. When two infected spot the same runner, one can keep chasing while the other flanks and tries to intercept them farther along the route. Civilians look ahead for infected, take detours when they can, and backtrack when the way ahead is too dangerous. Close or reopen a bridge to change the routes available to both groups.

Runners slow and yield when an alley or bridge approach fills. They carry their momentum through turns where there is room. Nearby survivors can pick up on the panic and glance around as they react. Infected chasing a specific survivor can check a nearby opening after losing sight of them.

The infected use shoulder bites, arm grabs, and tackles. Caught civilians fall, stay down for about three seconds, and rise before they can join the chase. The results count civilians evacuated, infected, and left behind.

Choose **Evacuation drill** for the original civilian-only route from Rialto Market to Piazza San Marco.

In **Rialto outbreak**, use **Defense budget** to recruit SWAT infantry. The scenario starts with four hired troops and a budget based on civilian and starting infected counts. **Hire max** spends the remaining credits on infantry. Each deployment pin places one soldier, and unassigned troops start at extraction. Set the round length and extraction radius before dispatch.

Infantry stop and face visible infected before firing. Use **Draw barricade** under **Defense budget** and click both sides of a street to buy a gate and concrete barricade along that span. The preview shows the price. **Undo barricade** refunds the most recent placement. Barricades and infantry share credits. Civilians and troops can pass through the gate, and infected have to breach it or go around the ends. Gate guards patrol nearby and move up when infected approach. Part of the squad patrols inside the zone as a reserve and answers gate alerts. Zombies can break through under sustained pressure. Infected can survive the first hit, and shots are less reliable at longer distances. Soldiers fall back to the transport before the round ends, with more time allowed for larger zones. Civilians wait at the pickup until the clock expires. A sustained infected presence at the center overruns the pickup and kills the waiting group. Use the 1×, 2×, and 4× controls to change simulation speed.

The default outbreak leaves 1,600 credits after the four starting troops. Barricade previews flag nearby walkable space beyond either endpoint. Toggle **Guard coverage** on the map to see assignments, reserve response, and gate integrity. After extraction, use **Replay same outbreak** to reuse the starting seed and bridge settings and compare results.

Infantry and weapon definitions live in `src/defense.ts`. Deployments reference a unit type, and each unit type references a weapon definition.

- Drag to pan. Scroll or use the map controls to zoom out to the city and lagoon.
- Use **Street view** to zoom in on a runner or the pickup point. Use **Fit route in view** to see the full evacuation route.
- Use **Fullscreen map** to expand the map. Click the same button or press **Esc** to return.
- Click a crossing on the map or in the sidebar to close or reopen it.
- Toggle **Crowd density** in the map controls to highlight civilian clusters. Darker orange marks the most crowded areas.
- In **Spawn plan**, choose **Place** for civilians or zombies and click walkable ground for each point. The first custom point replaces the presets. Click a pin while placing to remove it, and choose **Done** to finish.
- The population is split as evenly as possible across the points, with extra individuals assigned to the earliest points. **Starting zombies** sets the total for the infected.
- Choose **Random** for either population to scatter individuals across walkable ground. Reset keeps the layout and creates a new run.
- Use **Set evacuation** to move the extraction point.
- Choose a **Crowd size** from 12 to 20,000. Larger crowds start over a wider area around the pickup.
- Press **Dispatch group** to release the civilians. They react at different times, move around buildings and other runners, and count as evacuated on arrival. Civilians cut off from the exit wait for an open route.
- Use the route icon in the map controls to fit the active route in view.

The scenario is a single-player exercise. Civilians have individually assigned running speeds and distinct adult, child, and older-adult models. About two-thirds of the crowd is adult men and women, with the remaining third split between children and older adults. They accelerate from rest and slow on mapped stairs and bridge approaches. Travel time depends on each person’s route and pace.

## Develop

Use Node.js 22.18 or newer.

```sh
npm ci
npm run dev
npm test
npm run build
```

`npm run build:offline` generates a self-contained file at `offline/index.html`.

React handles the controls. PixiJS renders the map and animated civilians, with a Canvas fallback. Both renderers share the character frames in `src/civilians.ts`. The street graph provides the planning preview. Civilians use a shared navigation field across open ground with building, canal, and gate collision. Each runner steers locally, and PixiJS batches the visible characters from one sprite sheet. Scenario settings live in `data/rialto-outbreak.json` and `data/rialto-scenario.json`.

In runs with 6,000 or more agents, a slow render frame can advance at most 55 ms of simulation. This keeps the map responsive under load and can make the extraction clock run slower than real time.

## Map data

© [OpenStreetMap contributors](https://www.openstreetmap.org/copyright). The bundled data is derived from OpenStreetMap and is available under the [Open Database License](https://opendatacommons.org/licenses/odbl/1-0/). Surrounding geometry comes from [OpenFreeMap](https://openfreemap.org/) and [OpenMapTiles](https://openmaptiles.org/). Map credits appear below the game.

`data/venice.json` bundles the projected geometry and pedestrian graph for the playable district. To regenerate it, download OpenStreetMap XML for longitude 12.3195–12.3435 and latitude 45.428–45.447 in smaller bounding boxes. Use west-to-east tiles of 0.008 degrees and latitude boundaries 45.428, 45.433, 45.438, 45.443 and 45.447. Include [way 1526861508 with its nodes](https://api.openstreetmap.org/api/0.6/way/1526861508/full) to complete the Bacino San Marco polygon. Run the importer with the extracts in west-to-east, south-to-north order.

```sh
python3 scripts/import_osm.py data/venice.json extracts/*.xml
```

`data/venice-overview.json` contains surrounding terrain. To regenerate it, save the OpenFreeMap vector tiles at zoom 14 for x 8751–8755 and y 5863–5867 as `x-y.pbf`. The [TileJSON endpoint](https://tiles.openfreemap.org/planet/latest) supplies the tile URL template.

```sh
node scripts/import_overview.mjs tiles data/venice.json data/venice-overview.json
```

The scenario is fictional and controls three named Grand Canal crossings inside the playable district.
